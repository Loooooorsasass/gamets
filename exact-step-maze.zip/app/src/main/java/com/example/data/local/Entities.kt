package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_progress")
data class GameProgressEntity(
    @PrimaryKey val id: Int = 1,
    val highestCleared: Int = 0,
    val totalStars: Int = 0,
    val coins: Int = 100,
    val gems: Int = 10,
    val impossibleCleared: Int = 0,
    val superCleared: Boolean = false,
    val currentSkinId: String = "classic_blue",
    val currentMazeThemeId: String = "midnight_cyber",
    val unlockedSkins: String = "classic_blue",
    val unlockedThemes: String = "midnight_cyber",
    val isVipNoAds: Boolean = false,
    val hintCount: Int = 3,
    val skipTokens: Int = 1,
    val lastSkipAdTimestamp: Long = 0L,
    val soundEnabled: Boolean = true,
    val musicEnabled: Boolean = true,
    val hapticEnabled: Boolean = true,
    val language: String = "vi",
    val lastCloudSyncTime: Long = 0L,
    val accumulatedRewardedAdViews: Int = 0,
    val vipTier: Int = 0, // 0: Không VIP, 1: VIP 1, 2: VIP 2, 3: VIP 3
    val vipExpiresAtMillis: Long = 0L, // Timestamp hết hạn, VIP 3 = Long.MAX_VALUE
    val vip1DisableBanner: Boolean = true, // Tùy chọn VIP 1: tắt banner
    val vip1DisableInterstitial: Boolean = true // Tùy chọn VIP 1: tắt quảng cáo sau ván
) {
    /**
     * Trạng thái VIP có đang kích hoạt hay không
     */
    fun isVipActive(): Boolean {
        if (vipTier <= 0 && !isVipNoAds) return false
        if (vipTier == 3 || isVipNoAds) return true
        return System.currentTimeMillis() < vipExpiresAtMillis
    }

    /**
     * Có được phép hiển thị quảng cáo Banner ở góc dưới màn hình không
     */
    fun isBannerAdAllowed(): Boolean {
        if (vipTier == 3 || isVipNoAds) return false
        if (vipTier == 2 && isVipActive()) return false
        if (vipTier == 1 && isVipActive() && vip1DisableBanner) return false
        return true
    }

    /**
     * Có được phép hiển thị quảng cáo xen kẽ sau khi thắng ván không
     */
    fun isInterstitialAdAllowed(): Boolean {
        if (vipTier == 3 || isVipNoAds) return false
        if (vipTier == 2 && isVipActive()) return false
        if (vipTier == 1 && isVipActive() && vip1DisableInterstitial) return false
        return true
    }

    /**
     * Thời gian VIP còn lại (mili-giây)
     */
    fun remainingVipDurationMillis(): Long {
        if (vipTier == 3 || isVipNoAds) return Long.MAX_VALUE
        if (!isVipActive()) return 0L
        return maxOf(0L, vipExpiresAtMillis - System.currentTimeMillis())
    }
}

@Entity(tableName = "level_records")
data class LevelRecordEntity(
    @PrimaryKey val levelId: String,
    val stars: Int,
    val bestTimeSec: Int,
    val bestMoves: Int,
    val completedAt: Long,
    val pathHistoryJson: String = "",
    val seedStr: String = "",
    val width: Int = 0,
    val height: Int = 0
)

@Entity(tableName = "save_slot")
data class SaveSlotEntity(
    @PrimaryKey val id: Int = 1,
    val defId: String,
    val tier: String? = null,
    val w: Int,
    val h: Int,
    val seedStr: String,
    val playerX: Int,
    val playerY: Int,
    val moves: Int,
    val elapsedSec: Int,
    val visitedIndicesJson: String,
    val pathHistoryJson: String
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val currentProgress: Int,
    val maxProgress: Int,
    val isUnlocked: Boolean,
    val isClaimed: Boolean,
    val rewardCoins: Int,
    val iconName: String
)

@Entity(tableName = "daily_challenge_records")
data class DailyChallengeRecordEntity(
    @PrimaryKey val dateString: String,
    val moves: Int,
    val elapsedSec: Int,
    val stars: Int,
    val completedAt: Long
)

/**
 * Entity lưu cấu trúc logic của màn chơi mê cung (Room Database Schema)
 * Quản lý vị trí các bức tường, điểm bắt đầu của người chơi và điểm đích đến.
 */
@Entity(tableName = "maze_levels")
data class MazeLevelEntity(
    @PrimaryKey val levelId: String,
    val width: Int,
    val height: Int,
    val targetSteps: Int,
    val startX: Int,
    val startY: Int,
    val endX: Int,
    val endY: Int,
    val wallsData: String,      // Chuỗi mảng bitmask tường của từng ô (CSV: "15,7,11,...")
    val optimalPath: String,   // Tọa độ đường đi mẫu tối ưu (CSV: "x,y;x,y;...")
    val seed: Long,
    val createdAt: Long = System.currentTimeMillis()
)

