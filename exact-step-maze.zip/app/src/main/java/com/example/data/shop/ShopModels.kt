package com.example.data.shop

import androidx.compose.ui.graphics.Color
import com.example.core.i18n.AppLanguage

data class PlayerSkin(
    val id: String,
    val name: String,
    val description: String,
    val priceCoins: Int,
    val iconEmoji: String,
    val primaryColor: Color,
    val secondaryColor: Color = primaryColor,
    val glowColor: Color,
    val isVipOnly: Boolean = false,
    val avatarType: PlayerAvatarType = PlayerAvatarType.NEON_SPHERE
) {
    companion object {
        fun fromGameItemSkin(item: GameItemSkin, lang: AppLanguage = AppLanguage.VI): PlayerSkin {
            return PlayerSkin(
                id = item.id,
                name = item.getName(lang),
                description = item.getDescription(lang),
                priceCoins = item.priceCoins,
                iconEmoji = item.iconEmoji,
                primaryColor = item.primaryColor,
                secondaryColor = item.secondaryColor,
                glowColor = item.glowColor,
                isVipOnly = item.isVipOnly,
                avatarType = item.avatarType
            )
        }
    }
}

data class MazeTheme(
    val id: String,
    val name: String,
    val priceCoins: Int,
    val bgColor: Color,
    val panelColor: Color,
    val wallColor: Color,
    val pathVisitedColor: Color,
    val accentColor: Color,
    val goalColor: Color
)

object ShopCatalog {

    fun getSkins(lang: AppLanguage = AppLanguage.VI): List<PlayerSkin> {
        return GameItemAssets.ALL_SKINS.map { PlayerSkin.fromGameItemSkin(it, lang) }
    }

    val SKINS: List<PlayerSkin>
        get() = getSkins(AppLanguage.VI)

    val THEMES = listOf(
        MazeTheme(
            id = "midnight_cyber",
            name = "Đêm Cyberpunk",
            priceCoins = 0,
            bgColor = Color(0xFF0F1220),
            panelColor = Color(0xFF171B2E),
            wallColor = Color(0xFFE6E8F5),
            pathVisitedColor = Color(0x336EE7B7),
            accentColor = Color(0xFF6EE7B7),
            goalColor = Color(0xFFF97316)
        ),
        MazeTheme(
            id = "emerald_matrix",
            name = "Ma Trận Ngọc Bích",
            priceCoins = 350,
            bgColor = Color(0xFF061A14),
            panelColor = Color(0xFF0D2820),
            wallColor = Color(0xFF34D399),
            pathVisitedColor = Color(0x3310B981),
            accentColor = Color(0xFF10B981),
            goalColor = Color(0xFFFBBF24)
        ),
        MazeTheme(
            id = "sunset_neon",
            name = "Hoàng Hôn Synthwave",
            priceCoins = 450,
            bgColor = Color(0xFF1A102E),
            panelColor = Color(0xFF261842),
            wallColor = Color(0xFFF472B6),
            pathVisitedColor = Color(0x33C084FC),
            accentColor = Color(0xFFC084FC),
            goalColor = Color(0xFF38BDF8)
        ),
        MazeTheme(
            id = "obsidian_gold",
            name = "Hắc Thạch Hoàng Gia",
            priceCoins = 600,
            bgColor = Color(0xFF121214),
            panelColor = Color(0xFF1E1E24),
            wallColor = Color(0xFFF59E0B),
            pathVisitedColor = Color(0x33FBBF24),
            accentColor = Color(0xFFFBBF24),
            goalColor = Color(0xFFEF4444)
        )
    )

    fun getSkinById(id: String, lang: AppLanguage = AppLanguage.VI): PlayerSkin {
        val item = GameItemAssets.findSkin(id)
        return PlayerSkin.fromGameItemSkin(item, lang)
    }

    fun getThemeById(id: String): MazeTheme {
        return THEMES.find { it.id == id } ?: THEMES.first()
    }
}
