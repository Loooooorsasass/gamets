package com.example.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.engine.OneLineGenerator
import com.example.core.engine.OneLineMapResult
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.Strings
import com.example.ui.components.OneLineGameView
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeBgDark
import com.example.ui.theme.MazeCoin
import com.example.ui.theme.MazeStar
import com.example.ui.theme.MazeSurface1
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1
import com.example.ui.theme.MazeTextMuted
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.GameViewModel

enum class OneLineCategory(val icon: String) {
    SQUARE("⬛"),
    SPECIAL_SHAPES("🦖");

    fun getDisplayName(lang: AppLanguage): String {
        return when (this) {
            SQUARE -> Strings.categorySquare(lang)
            SPECIAL_SHAPES -> Strings.categorySpecial(lang)
        }
    }
}

data class OneLineLevelConfig(
    val id: Int,
    val rows: Int,
    val cols: Int,
    val labelVi: String,
    val labelEn: String,
    val category: OneLineCategory,
    val shapeType: String = "GRID",
    val fillRate: Float = 0.90f // Độ khó kéo max: Lấp kín 85% - 95% diện tích
) {
    val size: Int get() = maxOf(rows, cols)
    fun getLabel(lang: AppLanguage): String = if (lang == AppLanguage.VI) labelVi else labelEn
}

// 1. GIAI ĐOẠN 1: HÌNH VUÔNG TỪ 3x3 ĐẾN TỐI ĐA 15x15 (Độ khó kéo Max, 100% có nghiệm theo Hamiltonian DFS)
val SQUARE_LEVELS = listOf(
    OneLineLevelConfig(1, 3, 3, "3 × 3", "3 × 3", OneLineCategory.SQUARE, "GRID", 1.00f),
    OneLineLevelConfig(2, 4, 4, "4 × 4", "4 × 4", OneLineCategory.SQUARE, "GRID", 1.00f),
    OneLineLevelConfig(3, 5, 5, "5 × 5", "5 × 5", OneLineCategory.SQUARE, "GRID", 0.96f),
    OneLineLevelConfig(4, 6, 6, "6 × 6", "6 × 6", OneLineCategory.SQUARE, "GRID", 0.94f),
    OneLineLevelConfig(5, 7, 7, "7 × 7", "7 × 7", OneLineCategory.SQUARE, "GRID", 0.92f),
    OneLineLevelConfig(6, 8, 8, "8 × 8", "8 × 8", OneLineCategory.SQUARE, "GRID", 0.90f),
    OneLineLevelConfig(7, 9, 9, "9 × 9", "9 × 9", OneLineCategory.SQUARE, "GRID", 0.90f),
    OneLineLevelConfig(8, 10, 10, "10 × 10", "10 × 10", OneLineCategory.SQUARE, "GRID", 0.88f),
    OneLineLevelConfig(9, 11, 11, "11 × 11", "11 × 11", OneLineCategory.SQUARE, "GRID", 0.88f),
    OneLineLevelConfig(10, 12, 12, "12 × 12", "12 × 12", OneLineCategory.SQUARE, "GRID", 0.87f),
    OneLineLevelConfig(11, 13, 13, "13 × 13", "13 × 13", OneLineCategory.SQUARE, "GRID", 0.86f),
    OneLineLevelConfig(12, 14, 14, "14 × 14", "14 × 14", OneLineCategory.SQUARE, "GRID", 0.85f),
    OneLineLevelConfig(13, 15, 15, "15 × 15 (Max)", "15 × 15 (Max)", OneLineCategory.SQUARE, "GRID", 0.85f)
)

// 2. GIAI ĐOẠN 2: HÌNH ĐẶC BIỆT SAU KHI PHÁ ĐẢO HÌNH VUÔNG (Chữ nhật, Ngôi sao, Khủng long bạo chúa T-Rex, Trái tim, Vương miện, Kim cương,...)
val SPECIAL_SHAPE_LEVELS = listOf(
    OneLineLevelConfig(14, 8, 5, "Hình Chữ Nhật (Đứng)", "Rectangle (Vertical)", OneLineCategory.SPECIAL_SHAPES, "RECT_VERTICAL"),
    OneLineLevelConfig(15, 6, 10, "Hình Chữ Nhật (Ngang)", "Rectangle (Horizontal)", OneLineCategory.SPECIAL_SHAPES, "RECT_HORIZONTAL"),
    OneLineLevelConfig(16, 9, 9, "Ngôi Sao ⭐", "Star ⭐", OneLineCategory.SPECIAL_SHAPES, "STAR"),
    OneLineLevelConfig(17, 10, 10, "Khủng Long T-Rex 🦖", "T-Rex Dinosaur 🦖", OneLineCategory.SPECIAL_SHAPES, "DINOSAUR"),
    OneLineLevelConfig(18, 9, 9, "Trái Tim ❤️", "Heart ❤️", OneLineCategory.SPECIAL_SHAPES, "HEART"),
    OneLineLevelConfig(19, 9, 9, "Vương Miện Hoàng Gia 👑", "Royal Crown 👑", OneLineCategory.SPECIAL_SHAPES, "CROWN"),
    OneLineLevelConfig(20, 9, 9, "Kim Cương Lấp Lánh 💎", "Sparkling Diamond 💎", OneLineCategory.SPECIAL_SHAPES, "DIAMOND"),
    OneLineLevelConfig(21, 9, 9, "Thanh Gươm Huyền Thoại ⚔️", "Legendary Sword ⚔️", OneLineCategory.SPECIAL_SHAPES, "SWORD"),
    OneLineLevelConfig(22, 9, 9, "Ngôi Nhà Ấm Áp 🏠", "Cozy House 🏠", OneLineCategory.SPECIAL_SHAPES, "HOUSE"),
    OneLineLevelConfig(23, 9, 9, "Chữ Thập Cổ Điển ➕", "Classic Cross ➕", OneLineCategory.SPECIAL_SHAPES, "CROSS")
)

val ONE_LINE_LEVELS = SQUARE_LEVELS + SPECIAL_SHAPE_LEVELS

// Mẫu hình học đặc biệt
val SHAPE_PATTERNS = mapOf(
    "STAR" to arrayOf(
        "....*....",
        "...***...",
        "*********",
        ".*******.",
        "..*****..",
        ".*******.",
        "**.....**",
        "*.......*",
        "........."
    ),
    "DINOSAUR" to arrayOf(
        "....******",
        "....******",
        "....**....",
        "....****..",
        "***.****..",
        "*********.",
        ".********.",
        "..******..",
        "...*..*...",
        "..**..**.."
    ),
    "HEART" to arrayOf(
        ".***.***.",
        "*********",
        "*********",
        "*********",
        ".*******.",
        "..*****..",
        "...***...",
        "....*....",
        "........."
    ),
    "CROWN" to arrayOf(
        "*...*...*",
        "**..*..**",
        "*********",
        "*********",
        "*********",
        "*********",
        ".........",
        ".........",
        "........."
    ),
    "DIAMOND" to arrayOf(
        "....*....",
        "...***...",
        "..*****..",
        ".*******.",
        "*********",
        ".*******.",
        "..*****..",
        "...***...",
        "....*...."
    ),
    "SWORD" to arrayOf(
        "....*....",
        "....*....",
        "....*....",
        "....*....",
        "...***...",
        "*********",
        "....*....",
        "....*....",
        "...***..."
    ),
    "HOUSE" to arrayOf(
        "....*....",
        "...***...",
        "..*****..",
        ".*******.",
        "*********",
        ".*******.",
        ".*..*..*.",
        ".*..*..*.",
        ".*******."
    ),
    "CROSS" to arrayOf(
        "...***...",
        "...***...",
        "...***...",
        "*********",
        "*********",
        "*********",
        "...***...",
        "...***...",
        "...***..."
    )
)

@Composable
fun OneLineScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val lang = uiState.language

    // Tiến trình mở khóa: Bắt đầu từ màn 0 (3x3), vượt qua màn nào mới mở khóa màn kế tiếp
    var highestUnlockedIndex by remember { mutableIntStateOf(0) }
    var selectedLevelIndex by remember { mutableIntStateOf(0) }
    val currentLevel = ONE_LINE_LEVELS[selectedLevelIndex.coerceIn(0, ONE_LINE_LEVELS.lastIndex)]

    var oneLineViewRef by remember { mutableStateOf<OneLineGameView?>(null) }
    var currentSteps by remember { mutableIntStateOf(1) }
    var remainingCells by remember { mutableIntStateOf(0) }
    var totalCells by remember { mutableIntStateOf(0) }
    var showWinDialog by remember { mutableStateOf(false) }

    // Tính năng Hướng Dẫn: Duy nhất 1 lần Free cho mỗi màn chơi
    var isHintUsedInCurrentLevel by remember { mutableStateOf(false) }
    var isHintShowing by remember { mutableStateOf(false) }

    // Lưu trữ dữ liệu map được sinh ra bởi thuật toán OneLineGenerator
    var currentMapResult by remember { mutableStateOf<OneLineMapResult?>(null) }

    // Tab danh mục (Hình vuông vs Hình đặc biệt)
    var selectedCategory by remember { mutableStateOf(OneLineCategory.SQUARE) }

    BackHandler {
        viewModel.navigateTo(AppScreen.HOME)
    }

    fun generateLevelMap(config: OneLineLevelConfig): OneLineMapResult {
        return if (config.category == OneLineCategory.SQUARE) {
            OneLineGenerator.generateGridMap(
                rows = config.rows,
                cols = config.cols,
                seed = config.id.toLong() * 10007L + 42L,
                fillRate = config.fillRate
            )
        } else {
            val mask = SHAPE_PATTERNS[config.shapeType]
            if (mask != null) {
                OneLineGenerator.generateShapedMap(
                    rows = config.rows,
                    cols = config.cols,
                    maskPattern = mask,
                    seed = config.id.toLong() * 10007L + 88L
                )
            } else {
                // Rectangles
                OneLineGenerator.generateGridMap(
                    rows = config.rows,
                    cols = config.cols,
                    seed = config.id.toLong() * 10007L + 99L,
                    fillRate = 1.0f
                )
            }
        }
    }

    fun loadLevelIndex(index: Int) {
        if (index > highestUnlockedIndex) {
            Toast.makeText(context, Strings.completePrevLevel(lang), Toast.LENGTH_SHORT).show()
            return
        }

        selectedLevelIndex = index
        showWinDialog = false
        isHintShowing = false
        isHintUsedInCurrentLevel = false

        val lvl = ONE_LINE_LEVELS[index]
        selectedCategory = lvl.category

        val mapRes = generateLevelMap(lvl)
        currentMapResult = mapRes
        totalCells = mapRes.totalTargetCells

        oneLineViewRef?.loadLevel(mapRes.rows, mapRes.cols, mapRes.grid, mapRes.startPoint, mapRes.solutionPath)
    }

    LaunchedEffect(selectedLevelIndex) {
        val lvl = currentLevel
        val mapRes = generateLevelMap(lvl)
        currentMapResult = mapRes
        totalCells = mapRes.totalTargetCells
        isHintShowing = false
        isHintUsedInCurrentLevel = false
        oneLineViewRef?.loadLevel(mapRes.rows, mapRes.cols, mapRes.grid, mapRes.startPoint, mapRes.solutionPath)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MazeBgDark)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        // TOP APP BAR
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateTo(AppScreen.HOME) },
                modifier = Modifier.testTag("oneline_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = Strings.back(lang),
                    tint = MazeTextH1
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "${Strings.oneLineTitle(lang)} (${Strings.maxDiff(lang)})",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MazeTextH1
                )
                Text(
                    text = if (currentLevel.category == OneLineCategory.SQUARE) Strings.squareRouteSub(lang) else "${Strings.specialShapeSub(lang)}: ${currentLevel.getLabel(lang)}",
                    fontSize = 12.sp,
                    color = MazeTextMuted
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MazeSurface2,
                border = BorderStroke(1.dp, MazeAmber.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(text = "🪙", fontSize = 12.sp)
                    Text(
                        text = "${uiState.progress.coins}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MazeCoin
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // CATEGORY SWITCHER TABS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OneLineCategory.values().forEach { cat ->
                val isCatSelected = (cat == selectedCategory)
                val isUnlocked = if (cat == OneLineCategory.SPECIAL_SHAPES) {
                    highestUnlockedIndex >= SQUARE_LEVELS.size // Cần phá đảo hết 15x15 mới mở hình đặc biệt
                } else true

                Surface(
                    onClick = {
                        if (!isUnlocked) {
                            Toast.makeText(context, Strings.unlockSpecialReq(lang), Toast.LENGTH_SHORT).show()
                            return@Surface
                        }
                        selectedCategory = cat
                        if (cat == OneLineCategory.SQUARE && currentLevel.category != OneLineCategory.SQUARE) {
                            loadLevelIndex(0)
                        } else if (cat == OneLineCategory.SPECIAL_SHAPES && currentLevel.category != OneLineCategory.SPECIAL_SHAPES) {
                            loadLevelIndex(SQUARE_LEVELS.size)
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    color = if (isCatSelected) MazeAmber else MazeSurface1,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "${cat.icon} ", fontSize = 13.sp)
                        Text(
                            text = cat.getDisplayName(lang),
                            fontSize = 11.sp,
                            fontWeight = if (isCatSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (!isUnlocked) MazeTextMuted else if (isCatSelected) Color.Black else MazeTextBody,
                            maxLines = 1
                        )
                        if (!isUnlocked) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = Strings.locked(lang),
                                tint = MazeTextMuted,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // LEVEL SELECTOR PILLS WITH LOCK STATE
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val visibleLevels = ONE_LINE_LEVELS.filter { it.category == selectedCategory }
            visibleLevels.forEach { lvl ->
                val globalIdx = ONE_LINE_LEVELS.indexOf(lvl)
                val isSelected = (globalIdx == selectedLevelIndex)
                val isUnlocked = globalIdx <= highestUnlockedIndex

                Surface(
                    onClick = {
                        if (isUnlocked) {
                            loadLevelIndex(globalIdx)
                        } else {
                            Toast.makeText(context, Strings.completeLevelToUnlock(lang, globalIdx, globalIdx + 1), Toast.LENGTH_SHORT).show()
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    color = when {
                        isSelected -> MazeAmber
                        isUnlocked -> MazeSurface2
                        else -> Color(0xFF1E293B).copy(alpha = 0.5f)
                    },
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) Color.White.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.08f)
                    ),
                    modifier = Modifier.testTag("oneline_level_pill_$globalIdx")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (!isUnlocked) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = Strings.locked(lang),
                                tint = MazeTextMuted,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                        Text(
                            text = lvl.getLabel(lang),
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = when {
                                isSelected -> Color.Black
                                isUnlocked -> MazeTextBody
                                else -> MazeTextMuted
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // PROGRESS HUD & HINT BUTTON
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MazeSurface1)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "${Strings.levelNum(lang, selectedLevelIndex + 1)}/${ONE_LINE_LEVELS.size}: ${currentLevel.getLabel(lang)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MazeAmber
                )
                Text(
                    text = Strings.hamiltonianDfs(lang),
                    fontSize = 10.sp,
                    color = MazeTextMuted
                )
            }

            // Nút HƯỚNG DẪN (1 lần Free duy nhất)
            Surface(
                onClick = {
                    if (isHintShowing) {
                        isHintShowing = false
                        oneLineViewRef?.toggleHint(false)
                    } else {
                        if (!isHintUsedInCurrentLevel) {
                            isHintUsedInCurrentLevel = true
                            isHintShowing = true
                            oneLineViewRef?.toggleHint(true)
                            Toast.makeText(context, Strings.hintFreeEnabled(lang), Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, Strings.hintOncePerLevel(lang), Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                shape = RoundedCornerShape(10.dp),
                color = if (isHintShowing) Color(0xFFF59E0B) else if (!isHintUsedInCurrentLevel) Color(0xFF0D9488) else MazeSurface2,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                modifier = Modifier.testTag("oneline_hint_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lightbulb,
                        contentDescription = Strings.hint(lang),
                        tint = if (isHintShowing) Color.Black else if (!isHintUsedInCurrentLevel) Color.White else MazeTextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (isHintShowing) Strings.hideHint(lang) else if (!isHintUsedInCurrentLevel) Strings.hintFree(lang) else Strings.hintUsed(lang),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isHintShowing) Color.Black else if (!isHintUsedInCurrentLevel) Color.White else MazeTextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // MAIN ONELINE GAME VIEW CANVAS
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0F172A))
                .padding(6.dp),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { ctx ->
                    OneLineGameView(ctx).apply {
                        val mapRes = currentMapResult ?: generateLevelMap(currentLevel)
                        loadLevel(mapRes.rows, mapRes.cols, mapRes.grid, mapRes.startPoint, mapRes.solutionPath)
                        setOnGameStateListener(object : OneLineGameView.OnGameStateListener {
                            override fun onPathChanged(currentPath: MutableList<OneLineGameView.Point>?, remaining: Int) {
                                currentSteps = currentPath?.size ?: 1
                                remainingCells = remaining
                            }

                            override fun onGameWin(totalSteps: Int) {
                                currentSteps = totalSteps
                                remainingCells = 0
                                showWinDialog = true
                                viewModel.addCoins(30)
                                viewModel.triggerInterstitial(activity)

                                if (selectedLevelIndex + 1 > highestUnlockedIndex && selectedLevelIndex + 1 < ONE_LINE_LEVELS.size) {
                                    highestUnlockedIndex = selectedLevelIndex + 1
                                }
                            }

                            override fun onUndo(removedPoint: OneLineGameView.Point?) {}
                        })
                        oneLineViewRef = this
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("oneline_game_canvas")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // ACTION BUTTONS: Undo, Reset, Next Level
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Undo button
            Button(
                onClick = { oneLineViewRef?.undoStep() },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("oneline_undo_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MazeSurface2),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
            ) {
                Icon(
                    imageVector = Icons.Default.Undo,
                    contentDescription = Strings.undo(lang),
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = Strings.undo(lang),
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }

            // Reset button
            Button(
                onClick = {
                    isHintShowing = false
                    oneLineViewRef?.resetLevel()
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("oneline_reset_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MazeSurface2),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = Strings.reset(lang),
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = Strings.reset(lang),
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }

            // Next Level button
            val canGoNext = (selectedLevelIndex + 1) <= highestUnlockedIndex && (selectedLevelIndex + 1) < ONE_LINE_LEVELS.size
            Button(
                onClick = {
                    if (canGoNext) {
                        loadLevelIndex(selectedLevelIndex + 1)
                    } else {
                        Toast.makeText(context, Strings.completeCurrentLevelFirst(lang), Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .weight(1.3f)
                    .height(48.dp)
                    .testTag("oneline_next_level_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (canGoNext) MazeAmber else Color(0xFF334155)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = Strings.nextLevel(lang),
                    color = if (canGoNext) Color.Black else MazeTextMuted,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.NavigateNext,
                    contentDescription = Strings.nextLevel(lang),
                    tint = if (canGoNext) Color.Black else MazeTextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }

    // WIN DIALOG POPUP
    if (showWinDialog) {
        AlertDialog(
            onDismissRequest = { showWinDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Celebration,
                        contentDescription = Strings.winTitle(lang),
                        tint = MazeStar
                    )
                    Text(text = Strings.onelineLevelComplete(lang, selectedLevelIndex + 1), fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = Strings.onelineWinMsg(lang, currentLevel.getLabel(lang)),
                        color = MazeTextBody,
                        fontSize = 14.sp
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MazeSurface1,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = Strings.levelReward(lang), color = MazeTextMuted)
                            Text(text = "+30 🪙", fontWeight = FontWeight.Bold, color = MazeCoin)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showWinDialog = false
                        if (selectedLevelIndex + 1 < ONE_LINE_LEVELS.size) {
                            loadLevelIndex(selectedLevelIndex + 1)
                        } else {
                            Toast.makeText(context, Strings.congratsAllCleared(lang), Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber)
                ) {
                    Text(text = Strings.nextLevel(lang), color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showWinDialog = false
                        isHintShowing = false
                        oneLineViewRef?.resetLevel()
                    }
                ) {
                    Text(text = Strings.retry(lang), color = MazeTextBody)
                }
            },
            containerColor = MazeSurface2
        )
    }
}
