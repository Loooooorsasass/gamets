package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.core.engine.Maze
import com.example.core.engine.Point
import com.example.data.shop.MazeTheme
import com.example.data.shop.PlayerSkin

@Composable
fun MazeCanvas(
    maze: Maze,
    player: Point,
    visitedCells: Set<Int>,
    theme: MazeTheme,
    skin: PlayerSkin,
    vision: Int?,
    hintPath: List<Point>? = null,
    pathHistory: List<Point>? = null,
    replayTrail: List<Point>? = null,
    controlMode: GridControlMode = GridControlMode.AUTO,
    onMove: (dx: Int, dy: Int) -> Boolean = { _, _ -> true },
    onUndo: (() -> Unit)? = null,
    onWin: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(16.dp))
            .background(theme.panelColor)
    ) {
        AndroidView(
            factory = { ctx ->
                MazeGameView(ctx).apply {
                    setOnMazeMoveListener(object : MazeGameView.OnMazeMoveListener {
                        override fun onMove(dx: Int, dy: Int, newPlayer: MazeGameView.MazePoint, totalMoves: Int) {
                            onMove(dx, dy)
                        }

                        override fun onUndo(restoredPlayer: MazeGameView.MazePoint) {
                            onUndo?.invoke()
                        }

                        override fun onWallHit() {
                            // Không rung theo yêu cầu
                        }

                        override fun onGameWin(totalMoves: Int) {
                            onWin?.invoke()
                        }
                    })

                    setStepByStepMode(controlMode == GridControlMode.STEP_BY_STEP)
                    setPlayerSkinId(skin.id)

                    updateColors(
                        theme.wallColor.toArgb(),
                        theme.pathVisitedColor.toArgb(),
                        theme.accentColor.toArgb()
                    )

                    val hintConverted = hintPath?.map { MazeGameView.MazePoint(it.x, it.y) }
                    val historyConverted = pathHistory?.map { MazeGameView.MazePoint(it.x, it.y) }
                        ?: listOf(MazeGameView.MazePoint(player.x, player.y))

                    setMazeData(
                        maze.w,
                        maze.h,
                        maze.masks,
                        MazeGameView.MazePoint(maze.start.x, maze.start.y),
                        MazeGameView.MazePoint(maze.goal.x, maze.goal.y),
                        MazeGameView.MazePoint(player.x, player.y),
                        visitedCells,
                        historyConverted,
                        hintConverted,
                        vision
                    )
                }
            },
            update = { view ->
                view.setStepByStepMode(controlMode == GridControlMode.STEP_BY_STEP)
                view.setPlayerSkinId(skin.id)

                view.updateColors(
                    theme.wallColor.toArgb(),
                    theme.pathVisitedColor.toArgb(),
                    theme.accentColor.toArgb()
                )

                val hintConverted = hintPath?.map { MazeGameView.MazePoint(it.x, it.y) }
                val historyConverted = pathHistory?.map { MazeGameView.MazePoint(it.x, it.y) }
                    ?: listOf(MazeGameView.MazePoint(player.x, player.y))

                view.setMazeData(
                    maze.w,
                    maze.h,
                    maze.masks,
                    MazeGameView.MazePoint(maze.start.x, maze.start.y),
                    MazeGameView.MazePoint(maze.goal.x, maze.goal.y),
                    MazeGameView.MazePoint(player.x, player.y),
                    visitedCells,
                    historyConverted,
                    hintConverted,
                    vision
                )
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}
