package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeAmberGlow
import com.example.ui.theme.MazeDanger
import com.example.ui.theme.MazeEdgeHighlight
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1
import com.example.ui.theme.MazeTextMuted

/**
 * Nút tầng Impossible & Siêu cấp được tái thiết kế theo chuẩn Art Director:
 * - Nền Surface 2 (#334155), bo góc 12dp
 * - Bắt sáng mép trên (Inner highlight), đổ bóng xúc giác
 * - Trạng thái khóa: phủ lớp màu đen trong suốt rgba(0,0,0,0.5) với icon Ổ khóa màu trắng sắc nét ở giữa
 */
@Composable
fun TactileImpossibleTierButton(
    title: String,
    subtitle: String,
    isUnlocked: Boolean,
    isCleared: Boolean,
    isSaved: Boolean,
    isSuper: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accentColor = if (isSuper) MazeAmberGlow else MazeAmber

    Box(
        modifier = modifier
            .size(width = 110.dp, height = 96.dp)
            .shadow(
                elevation = if (isUnlocked) 4.dp else 1.dp,
                shape = RoundedCornerShape(12.dp),
                ambientColor = Color.Black.copy(alpha = 0.4f),
                spotColor = Color.Black.copy(alpha = 0.5f)
            )
            .clip(RoundedCornerShape(12.dp))
            .background(MazeSurface2)
            .drawBehind {
                drawLine(
                    color = Color(0x1AFFFFFF),
                    start = Offset(0f, 1f),
                    end = Offset(size.width, 1f),
                    strokeWidth = 2f
                )
            }
            .border(
                width = 1.dp,
                color = when {
                    isSaved -> MazeAmber
                    isCleared -> MazeAmber.copy(alpha = 0.6f)
                    isUnlocked -> accentColor.copy(alpha = 0.4f)
                    else -> MazeEdgeHighlight
                },
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(enabled = isUnlocked, onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                fontSize = if (isSuper) 13.sp else 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isUnlocked) accentColor else MazeTextMuted,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = if (isUnlocked) MazeTextBody else MazeTextMuted,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            if (isCleared) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Đã vượt",
                        tint = MazeAmber,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.size(2.dp))
                    Text(text = "ĐÃ VƯỢT", fontSize = 9.sp, color = MazeAmber, fontWeight = FontWeight.Bold)
                }
            } else if (isSaved) {
                Text(text = "ĐANG CHƠI", fontSize = 8.sp, color = MazeAmber, fontWeight = FontWeight.Bold)
            }
        }

        // Trạng thái Khóa (Locked State)
        if (!isUnlocked) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x80000000)), // rgba(0, 0, 0, 0.5)
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Đã khóa",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
