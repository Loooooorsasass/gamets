package com.example.ui.components;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * MazeGameView - Custom View điều khiển trò chơi Mê Cung bằng Kéo thả 1 nét (One-Line Drag)
 * hoặc Chế độ Vuốt từng bước (1 ô / 1 lần vuốt), chạy trên Canvas và Paint thuần của Android SDK,
 * tối ưu hóa 60/120 FPS.
 *
 * - Không khởi tạo đối tượng trong onDraw().
 * - Hiển thị Đích đến (Goal) là hình Lá cờ màu đỏ (Red Flag) sống động với cột cờ, chân đế và chóp vàng.
 * - Hỗ trợ chế độ Từng Bước (STEP_BY_STEP): Chỉ vuốt di chuyển đúng 1 ô mỗi lần chạm/vuốt.
 * - Hỗ trợ chế độ Tự Động (AUTO): Kéo lướt 1 nét mượt mà liên tục.
 * - Tự động Hoàn tác (Undo) khi kéo ngón tay lùi lại ô trước đó.
 * - ĐÃ TẮT RUNG KHI DI CHUYỂN / VA TƯỜNG (Chỉ rung khi chiến thắng).
 */
public class MazeGameView extends View {

    public static final int NORTH = 1;
    public static final int EAST = 2;
    public static final int SOUTH = 4;
    public static final int WEST = 8;

    public static class MazePoint {
        public int x;
        public int y;

        public MazePoint(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            MazePoint that = (MazePoint) o;
            return x == that.x && y == that.y;
        }

        @Override
        public int hashCode() {
            return 31 * x + y;
        }
    }

    public interface OnMazeMoveListener {
        void onMove(int dx, int dy, MazePoint newPlayer, int totalMoves);
        void onUndo(MazePoint restoredPlayer);
        void onWallHit();
        void onGameWin(int totalMoves);
    }

    private OnMazeMoveListener moveListener;

    // Maze structure
    private int mazeW = 5;
    private int mazeH = 5;
    private int[] masks = new int[0];
    private MazePoint startPoint = new MazePoint(0, 0);
    private MazePoint goalPoint = new MazePoint(4, 4);
    private MazePoint playerPos = new MazePoint(0, 0);
    private Integer visionWindow = null;

    private final Set<Integer> visitedSet = new HashSet<>();
    private final List<MazePoint> pathHistory = new ArrayList<>();
    private final List<MazePoint> hintPoints = new ArrayList<>();
    private String currentSkinId = "classic_blue";

    private boolean isDragging = false;
    private boolean isGameWon = false;
    private boolean isStepByStepMode = false;
    private boolean stepModeHasMoved = false;
    private float touchDownX = 0f;
    private float touchDownY = 0f;

    // Layout measurements
    private float cellSize = 0f;
    private float offX = 0f;
    private float offY = 0f;
    private int viewW = 5;
    private int viewH = 5;
    private int originX = 0;
    private int originY = 0;

    // Pre-allocated Paint and Draw Objects
    private Paint bgPaint;
    private Paint wallPaint;
    private Paint visitedCellPaint;
    private Paint hintPaint;

    // Red Flag (Goal) Paints
    private Paint goalGlowPaint;
    private Paint flagPolePaint;
    private Paint flagTopperPaint;
    private Paint flagClothPaint;
    private Paint flagClothShadowPaint;
    private Paint flagBasePaint;
    private Paint flagEmblemPaint;

    // Player Paints
    private Paint playerGlowPaint;
    private Paint playerBodyPaint;
    private Paint playerHighlightPaint;
    private Paint pathTrailPaint;

    private final RectF tempRect = new RectF();
    private final Path tempPath = new Path();
    private final Path flagPath = new Path();

    public MazeGameView(Context context) {
        super(context);
        init();
    }

    public MazeGameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MazeGameView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(Color.parseColor("#0F172A"));
        bgPaint.setStyle(Paint.Style.FILL);

        wallPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        wallPaint.setColor(Color.parseColor("#94A3B8"));
        wallPaint.setStyle(Paint.Style.STROKE);
        wallPaint.setStrokeCap(Paint.Cap.ROUND);

        visitedCellPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        visitedCellPaint.setColor(Color.parseColor("#14B8A6"));
        visitedCellPaint.setStyle(Paint.Style.FILL);

        pathTrailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        pathTrailPaint.setColor(Color.parseColor("#2DD4BF"));
        pathTrailPaint.setStyle(Paint.Style.STROKE);
        pathTrailPaint.setStrokeCap(Paint.Cap.ROUND);
        pathTrailPaint.setStrokeJoin(Paint.Join.ROUND);

        hintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        hintPaint.setColor(Color.parseColor("#66F59E0B"));
        hintPaint.setStyle(Paint.Style.FILL);

        // ĐÍCH ĐẾN: LÁ CỜ ĐỎ (RED FLAG)
        goalGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        goalGlowPaint.setColor(Color.parseColor("#33EF4444")); // Hào quang đỏ mờ
        goalGlowPaint.setStyle(Paint.Style.FILL);

        flagPolePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagPolePaint.setColor(Color.parseColor("#CBD5E1")); // Cột cờ màu bạc kim loại
        flagPolePaint.setStyle(Paint.Style.STROKE);
        flagPolePaint.setStrokeCap(Paint.Cap.ROUND);

        flagTopperPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagTopperPaint.setColor(Color.parseColor("#F59E0B")); // Chóp cột cờ tròn vàng
        flagTopperPaint.setStyle(Paint.Style.FILL);

        flagClothPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagClothPaint.setColor(Color.parseColor("#EF4444")); // Lá cờ màu đỏ tươi rực rỡ
        flagClothPaint.setStyle(Paint.Style.FILL);

        flagClothShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagClothShadowPaint.setColor(Color.parseColor("#DC2626")); // Đổ bóng viền cờ
        flagClothShadowPaint.setStyle(Paint.Style.STROKE);
        flagClothShadowPaint.setStrokeWidth(2f);

        flagBasePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagBasePaint.setColor(Color.parseColor("#64748B")); // Chân đế cột cờ
        flagBasePaint.setStyle(Paint.Style.FILL);

        flagEmblemPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        flagEmblemPaint.setColor(Color.WHITE); // Điểm sáng / ngôi sao trên cờ
        flagEmblemPaint.setStyle(Paint.Style.FILL);

        // NHÂN VẬT
        playerGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        playerGlowPaint.setColor(Color.parseColor("#4DFBBF24"));
        playerGlowPaint.setStyle(Paint.Style.FILL);

        playerBodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        playerBodyPaint.setColor(Color.parseColor("#F59E0B"));
        playerBodyPaint.setStyle(Paint.Style.FILL);

        playerHighlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        playerHighlightPaint.setColor(Color.WHITE);
        playerHighlightPaint.setStyle(Paint.Style.FILL);
    }

    public void setOnMazeMoveListener(OnMazeMoveListener listener) {
        this.moveListener = listener;
    }

    public void setStepByStepMode(boolean stepByStep) {
        this.isStepByStepMode = stepByStep;
        this.stepModeHasMoved = false;
    }

    public void updateColors(int wallColor, int visitedColor, int accentColor) {
        wallPaint.setColor(wallColor);
        visitedCellPaint.setColor(visitedColor);
        pathTrailPaint.setColor(accentColor);
        playerBodyPaint.setColor(accentColor);
        invalidate();
    }

    public void setPlayerSkinId(String skinId) {
        if (skinId != null && !skinId.isEmpty()) {
            this.currentSkinId = skinId;
            invalidate();
        }
    }

    public void setMazeData(
            int w,
            int h,
            int[] masksArray,
            MazePoint start,
            MazePoint goal,
            MazePoint player,
            Set<Integer> visited,
            List<MazePoint> history,
            @Nullable List<MazePoint> hint,
            @Nullable Integer vision
    ) {
        this.mazeW = w;
        this.mazeH = h;
        this.masks = (masksArray != null) ? masksArray : new int[0];
        this.startPoint = new MazePoint(start.x, start.y);
        this.goalPoint = new MazePoint(goal.x, goal.y);
        this.playerPos = new MazePoint(player.x, player.y);
        this.visionWindow = vision;
        this.isGameWon = (player.x == goal.x && player.y == goal.y && visited != null && visited.size() > 1);

        this.visitedSet.clear();
        if (visited != null) {
            this.visitedSet.addAll(visited);
        } else {
            this.visitedSet.add(player.y * mazeW + player.x);
        }

        this.pathHistory.clear();
        if (history != null && !history.isEmpty()) {
            this.pathHistory.addAll(history);
        } else {
            this.pathHistory.add(new MazePoint(player.x, player.y));
        }

        this.hintPoints.clear();
        if (hint != null) {
            this.hintPoints.addAll(hint);
        }

        invalidate();
    }

    public boolean undoStep() {
        if (isGameWon || pathHistory.size() <= 1) return false;
        pathHistory.remove(pathHistory.size() - 1);
        MazePoint prev = pathHistory.get(pathHistory.size() - 1);
        playerPos = new MazePoint(prev.x, prev.y);

        // Rebuild visited set from history
        visitedSet.clear();
        for (MazePoint p : pathHistory) {
            visitedSet.add(p.y * mazeW + p.x);
        }

        if (moveListener != null) {
            moveListener.onUndo(playerPos);
        }
        invalidate();
        return true;
    }

    public void resetLevel() {
        if (startPoint == null) return;
        playerPos = new MazePoint(startPoint.x, startPoint.y);
        pathHistory.clear();
        pathHistory.add(new MazePoint(startPoint.x, startPoint.y));
        visitedSet.clear();
        visitedSet.add(startPoint.y * mazeW + startPoint.x);
        isGameWon = false;
        isDragging = false;
        stepModeHasMoved = false;
        if (moveListener != null) {
            moveListener.onUndo(playerPos);
        }
        invalidate();
    }

    public int cellAt(int x, int y) {
        if (x < 0 || x >= mazeW || y < 0 || y >= mazeH) return 0;
        int idx = y * mazeW + x;
        if (idx < 0 || idx >= masks.length) return 0;
        return masks[idx];
    }

    // ==========================================
    // XỬ LÝ SỰ KIỆN KÉO THẢ / VUỐT TỪNG BƯỚC
    // ==========================================
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (isGameWon) return super.onTouchEvent(event);

        float touchX = event.getX();
        float touchY = event.getY();

        if (cellSize <= 0f) return super.onTouchEvent(event);

        // Chuyển đổi Pixel sang Grid (col: x, row: y)
        int localCol = (int) Math.floor((touchX - offX) / cellSize);
        int localRow = (int) Math.floor(((offY + viewH * cellSize) - touchY) / cellSize);

        int targetX = originX + localCol;
        int targetY = originY + localRow;

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchDownX = touchX;
                touchDownY = touchY;
                stepModeHasMoved = false;
                isDragging = true;
                return true;

            case MotionEvent.ACTION_MOVE:
                if (!isDragging) return true;

                // NẾU Ở CHẾ ĐỘ STEP_BY_STEP: Chỉ cho phép di chuyển tối đa 1 ô mỗi lần chạm/vuốt!
                if (isStepByStepMode && stepModeHasMoved) {
                    return true;
                }

                if (!isInsideMaze(targetX, targetY)) return true;
                if (targetX == playerPos.x && targetY == playerPos.y) return true;

                // 1. TÍNH NĂNG HOÀN TÁC (Tự động Undo khi kéo/vuốt ngược về ô trước)
                if (pathHistory.size() >= 2) {
                    MazePoint prev = pathHistory.get(pathHistory.size() - 2);
                    if (targetX == prev.x && targetY == prev.y) {
                        pathHistory.remove(pathHistory.size() - 1);
                        playerPos = new MazePoint(prev.x, prev.y);

                        visitedSet.clear();
                        for (MazePoint p : pathHistory) {
                            visitedSet.add(p.y * mazeW + p.x);
                        }

                        if (moveListener != null) {
                            moveListener.onUndo(playerPos);
                        }
                        if (isStepByStepMode) {
                            stepModeHasMoved = true;
                        }
                        invalidate();
                        return true;
                    }
                }

                // 2. DI CHUYỂN THÔNG MINH (MULTI-STEP PATH TRACKING + BÁM NGÓN TAY NHANH)
                // Kể cả khi vuốt/kéo lướt rất nhanh qua nhiều ô, vòng lặp giải từng bước sẽ dẫn nhân vật đi mượt mà
                int maxIterations = isStepByStepMode ? 1 : 15;
                int iterationCount = 0;
                boolean madeAnyMove = false;

                while ((playerPos.x != targetX || playerPos.y != targetY) && iterationCount < maxIterations) {
                    iterationCount++;

                    int diffX = targetX - playerPos.x;
                    int diffY = targetY - playerPos.y;

                    int stepX = Integer.compare(diffX, 0);
                    int stepY = Integer.compare(diffY, 0);

                    boolean stepSuccess = false;

                    // Thử theo trục có khoảng cách lớn hơn trước
                    if (Math.abs(diffX) >= Math.abs(diffY)) {
                        if (stepX != 0 && tryMoveSingleCell(stepX, 0)) {
                            stepSuccess = true;
                        } else if (stepY != 0 && tryMoveSingleCell(0, stepY)) {
                            stepSuccess = true;
                        }
                    } else {
                        if (stepY != 0 && tryMoveSingleCell(0, stepY)) {
                            stepSuccess = true;
                        } else if (stepX != 0 && tryMoveSingleCell(stepX, 0)) {
                            stepSuccess = true;
                        }
                    }

                    if (stepSuccess) {
                        madeAnyMove = true;
                        if (isStepByStepMode) {
                            stepModeHasMoved = true;
                            break;
                        }
                        if (isGameWon) {
                            break;
                        }
                    } else {
                        // Đụng tường cản, dừng vòng lặp
                        break;
                    }
                }

                if (madeAnyMove) {
                    invalidate();
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                isDragging = false;
                stepModeHasMoved = false;
                return true;
        }

        return super.onTouchEvent(event);
    }

    private boolean tryMoveSingleCell(int dx, int dy) {
        if (dx == 0 && dy == 0) return false;
        int nextX = playerPos.x + dx;
        int nextY = playerPos.y + dy;

        if (!isInsideMaze(nextX, nextY)) return false;

        int dirMask = 0;
        if (dx == 1 && dy == 0) dirMask = EAST;
        else if (dx == -1 && dy == 0) dirMask = WEST;
        else if (dx == 0 && dy == 1) dirMask = NORTH;
        else if (dx == 0 && dy == -1) dirMask = SOUTH;

        int currentMask = cellAt(playerPos.x, playerPos.y);

        if ((currentMask & dirMask) != 0) {
            playerPos = new MazePoint(nextX, nextY);
            pathHistory.add(new MazePoint(nextX, nextY));
            visitedSet.add(nextY * mazeW + nextX);

            if (moveListener != null) {
                moveListener.onMove(dx, dy, playerPos, pathHistory.size() - 1);
            }

            if (playerPos.x == goalPoint.x && playerPos.y == goalPoint.y) {
                isGameWon = true;
                isDragging = false;
                if (moveListener != null) {
                    moveListener.onGameWin(pathHistory.size() - 1);
                }
            }
            return true;
        } else {
            if (moveListener != null) {
                moveListener.onWallHit();
            }
            return false;
        }
    }

    private boolean isInsideMaze(int x, int y) {
        return x >= 0 && x < mazeW && y >= 0 && y < mazeH;
    }

    // ==========================================
    // HIỂN THỊ ĐỒ HỌA TRÊN CANVAS (ONDRAW) - 60/120 FPS
    // ==========================================
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float canvasW = getWidth();
        float canvasH = getHeight();
        if (canvasW <= 0 || canvasH <= 0 || mazeW <= 0 || mazeH <= 0) return;

        viewW = (visionWindow != null) ? Math.min(visionWindow, mazeW) : mazeW;
        viewH = (visionWindow != null) ? Math.min(visionWindow, mazeH) : mazeH;

        if (visionWindow != null) {
            originX = Math.min(Math.max(0, playerPos.x - viewW / 2), mazeW - viewW);
            originY = Math.min(Math.max(0, playerPos.y - viewH / 2), mazeH - viewH);
        } else {
            originX = 0;
            originY = 0;
        }

        cellSize = Math.min(canvasW / viewW, canvasH / viewH);
        offX = (canvasW - viewW * cellSize) / 2f;
        offY = (canvasH - viewH * cellSize) / 2f;

        float strokeWidth = Math.max(2.5f, cellSize * 0.08f);
        wallPaint.setStrokeWidth(strokeWidth);
        pathTrailPaint.setStrokeWidth(cellSize * 0.3f);
        flagPolePaint.setStrokeWidth(Math.max(2f, cellSize * 0.07f));

        // 1. Vẽ các ô đã đi qua (Visited cells)
        for (int ly = 0; ly < viewH; ly++) {
            for (int lx = 0; lx < viewW; lx++) {
                int gx = originX + lx;
                int gy = originY + ly;
                int cellIndex = gy * mazeW + gx;

                if (visitedSet.contains(cellIndex)) {
                    float sx = offX + lx * cellSize;
                    float sy = offY + (viewH - 1 - ly) * cellSize;
                    tempRect.set(sx + 1f, sy + 1f, sx + cellSize - 1f, sy + cellSize - 1f);
                    canvas.drawRoundRect(tempRect, cellSize * 0.15f, cellSize * 0.15f, visitedCellPaint);
                }
            }
        }

        // 2. Vẽ đường nối 1 nét (One-line Path Trail)
        if (pathHistory.size() > 1) {
            tempPath.reset();
            boolean started = false;
            for (MazePoint p : pathHistory) {
                if (p.x >= originX && p.x < originX + viewW && p.y >= originY && p.y < originY + viewH) {
                    float px = offX + (p.x - originX) * cellSize + cellSize / 2f;
                    float py = offY + (viewH - 1 - (p.y - originY)) * cellSize + cellSize / 2f;
                    if (!started) {
                        tempPath.moveTo(px, py);
                        started = true;
                    } else {
                        tempPath.lineTo(px, py);
                    }
                }
            }
            if (started) {
                canvas.drawPath(tempPath, pathTrailPaint);
            }
        }

        // 3. Vẽ gợi ý đường đi (Hint Path)
        if (!hintPoints.isEmpty()) {
            for (MazePoint p : hintPoints) {
                if (p.x >= originX && p.x < originX + viewW && p.y >= originY && p.y < originY + viewH) {
                    float hx = offX + (p.x - originX) * cellSize + cellSize / 2f;
                    float hy = offY + (viewH - 1 - (p.y - originY)) * cellSize + cellSize / 2f;
                    canvas.drawCircle(hx, hy, cellSize * 0.18f, hintPaint);
                }
            }
        }

        // 4. Vẽ tường mê cung (Maze Walls)
        for (int ly = 0; ly < viewH; ly++) {
            for (int lx = 0; lx < viewW; lx++) {
                int gx = originX + lx;
                int gy = originY + ly;
                int mask = cellAt(gx, gy);
                float sx = offX + lx * cellSize;
                float sy = offY + (viewH - 1 - ly) * cellSize;

                // Tường BẮC (NORTH - phía trên trên màn hình)
                if ((mask & NORTH) == 0) {
                    canvas.drawLine(sx, sy, sx + cellSize, sy, wallPaint);
                }
                // Tường NAM (SOUTH - phía dưới trên màn hình)
                if ((mask & SOUTH) == 0) {
                    canvas.drawLine(sx, sy + cellSize, sx + cellSize, sy + cellSize, wallPaint);
                }
                // Tường TÂY (WEST - bên trái)
                if ((mask & WEST) == 0) {
                    canvas.drawLine(sx, sy, sx, sy + cellSize, wallPaint);
                }
                // Tường ĐÔNG (EAST - bên phải)
                if ((mask & EAST) == 0) {
                    canvas.drawLine(sx + cellSize, sy, sx + cellSize, sy + cellSize, wallPaint);
                }
            }
        }

        // 5. VẼ ĐÍCH ĐẾN: LÁ CỜ MÀU ĐỎ (RED FLAG)
        if (goalPoint.x >= originX && goalPoint.x < originX + viewW &&
                goalPoint.y >= originY && goalPoint.y < originY + viewH) {
            float gLeft = offX + (goalPoint.x - originX) * cellSize;
            float gTop = offY + (viewH - 1 - (goalPoint.y - originY)) * cellSize;
            float gxCenter = gLeft + cellSize / 2f;
            float gyCenter = gTop + cellSize / 2f;

            // Hào quang đỏ mờ xung quanh ô đích
            canvas.drawCircle(gxCenter, gyCenter, cellSize * 0.44f, goalGlowPaint);

            // Chân đế cột cờ (Base)
            float baseLeft = gLeft + cellSize * 0.22f;
            float baseTop = gTop + cellSize * 0.78f;
            float baseRight = gLeft + cellSize * 0.50f;
            float baseBottom = gTop + cellSize * 0.86f;
            tempRect.set(baseLeft, baseTop, baseRight, baseBottom);
            canvas.drawRoundRect(tempRect, cellSize * 0.04f, cellSize * 0.04f, flagBasePaint);

            // Cột cờ (Flagpole)
            float poleX = gLeft + cellSize * 0.36f;
            float poleTopY = gTop + cellSize * 0.16f;
            float poleBottomY = gTop + cellSize * 0.82f;
            canvas.drawLine(poleX, poleTopY, poleX, poleBottomY, flagPolePaint);

            // Chóp cột cờ tròn mạ vàng (Gold Finial Topper)
            canvas.drawCircle(poleX, poleTopY, cellSize * 0.06f, flagTopperPaint);

            // Lá cờ màu đỏ (Red Flag Cloth) hình tam giác lượn sóng
            flagPath.reset();
            flagPath.moveTo(poleX + cellSize * 0.02f, poleTopY + cellSize * 0.04f);
            flagPath.lineTo(poleX + cellSize * 0.46f, poleTopY + cellSize * 0.22f); // Đỉnh cờ nhọn vươn sang phải
            flagPath.lineTo(poleX + cellSize * 0.02f, poleTopY + cellSize * 0.40f);
            flagPath.close();

            canvas.drawPath(flagPath, flagClothPaint);
            canvas.drawPath(flagPath, flagClothShadowPaint);

            // Điểm nhấn sao/huy hiệu trắng ở giữa lá cờ
            canvas.drawCircle(poleX + cellSize * 0.16f, poleTopY + cellSize * 0.22f, cellSize * 0.045f, flagEmblemPaint);
        }

        // 6. Vẽ Nhân vật (Player) theo Skin / Vật phẩm đã chọn
        if (playerPos.x >= originX && playerPos.x < originX + viewW &&
                playerPos.y >= originY && playerPos.y < originY + viewH) {
            float pxCenter = offX + (playerPos.x - originX) * cellSize + cellSize / 2f;
            float pyCenter = offY + (viewH - 1 - (playerPos.y - originY)) * cellSize + cellSize / 2f;

            com.example.data.shop.GameItemAssets.INSTANCE.drawPlayerOnCanvas(
                canvas,
                pxCenter,
                pyCenter,
                cellSize,
                currentSkinId
            );
        }
    }

    // =========================================================================
    // CẤU TRÚC DỮ LIỆU CƠ SỞ & THUẬT TOÁN TẠO MÊ CUNG THUẦN JAVA THEO CẤP ĐỘ
    // =========================================================================

    public static class Cell {
        public int x, y;
        public boolean topWall = true;
        public boolean rightWall = true;
        public boolean bottomWall = true;
        public boolean leftWall = true;
        public boolean visited = false;

        public Cell(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    public static class Edge {
        public Cell cell1, cell2;
        public Edge(Cell c1, Cell c2) {
            this.cell1 = c1;
            this.cell2 = c2;
        }
    }

    public Cell[][] initGrid(int cols, int rows) {
        Cell[][] grid = new Cell[cols][rows];
        for (int i = 0; i < cols; i++) {
            for (int j = 0; j < rows; j++) {
                grid[i][j] = new Cell(i, j);
            }
        }
        return grid;
    }

    public static void removeWalls(Cell current, Cell next) {
        int dx = current.x - next.x;
        if (dx == 1) { current.leftWall = false; next.rightWall = false; }
        else if (dx == -1) { current.rightWall = false; next.leftWall = false; }

        int dy = current.y - next.y;
        if (dy == 1) { current.bottomWall = false; next.topWall = false; }
        else if (dy == -1) { current.topWall = false; next.bottomWall = false; }
    }

    /**
     * 1. Cấp độ nhỏ (5x5 đến 20x20): Thuật toán Quay lui (Backtracking)
     */
    public static void generateBacktracking(Cell[][] grid, int cols, int rows, java.util.Random random) {
        java.util.Stack<Cell> stack = new java.util.Stack<>();
        Cell current = grid[0][0];
        current.visited = true;

        do {
            List<Cell> unvisitedNeighbors = getUnvisitedNeighbors(grid, cols, rows, current);
            if (!unvisitedNeighbors.isEmpty()) {
                Cell next = unvisitedNeighbors.get(random.nextInt(unvisitedNeighbors.size()));
                stack.push(current);
                removeWalls(current, next);
                current = next;
                current.visited = true;
            } else if (!stack.isEmpty()) {
                current = stack.pop();
            }
        } while (!stack.isEmpty());
    }

    private static List<Cell> getUnvisitedNeighbors(Cell[][] grid, int cols, int rows, Cell cell) {
        List<Cell> neighbors = new ArrayList<>();
        int x = cell.x;
        int y = cell.y;
        if (y < rows - 1 && !grid[x][y + 1].visited) neighbors.add(grid[x][y + 1]); // Top (y+1)
        if (x < cols - 1 && !grid[x + 1][y].visited) neighbors.add(grid[x + 1][y]); // Right (x+1)
        if (y > 0 && !grid[x][y - 1].visited) neighbors.add(grid[x][y - 1]); // Bottom (y-1)
        if (x > 0 && !grid[x - 1][y].visited) neighbors.add(grid[x - 1][y]); // Left (x-1)
        return neighbors;
    }

    /**
     * 2. Cấp độ trung bình (21x21 đến 50x50): Thuật toán Kruskal ngẫu nhiên
     */
    public static void generateKruskal(Cell[][] grid, int cols, int rows, java.util.Random random) {
        List<Edge> edges = new ArrayList<>();
        int[] parent = new int[cols * rows];
        for (int i = 0; i < cols * rows; i++) parent[i] = i;

        for (int x = 0; x < cols; x++) {
            for (int y = 0; y < rows; y++) {
                if (x < cols - 1) edges.add(new Edge(grid[x][y], grid[x + 1][y]));
                if (y < rows - 1) edges.add(new Edge(grid[x][y], grid[x][y + 1]));
            }
        }

        java.util.Collections.shuffle(edges, random);

        for (Edge edge : edges) {
            int id1 = edge.cell1.x + edge.cell1.y * cols;
            int id2 = edge.cell2.x + edge.cell2.y * cols;
            int root1 = findParent(parent, id1);
            int root2 = findParent(parent, id2);

            if (root1 != root2) {
                removeWalls(edge.cell1, edge.cell2);
                parent[root1] = root2;
            }
        }
    }

    private static int findParent(int[] parent, int i) {
        if (parent[i] == i) return i;
        return parent[i] = findParent(parent, parent[i]);
    }

    /**
     * 3. Cấp độ lớn (Trên 50x50): Thuật toán Wilson (Uniform Spanning Tree)
     */
    public static void generateWilson(Cell[][] grid, int cols, int rows, java.util.Random random) {
        int unvisitedCount = cols * rows;
        for (int x = 0; x < cols; x++) {
            for (int y = 0; y < rows; y++) {
                grid[x][y].visited = false;
            }
        }

        int startX = random.nextInt(cols);
        int startY = random.nextInt(rows);
        grid[startX][startY].visited = true;
        unvisitedCount--;

        int[][] walk = new int[cols][rows];

        while (unvisitedCount > 0) {
            int cx = random.nextInt(cols);
            int cy = random.nextInt(rows);
            while (grid[cx][cy].visited) {
                cx = random.nextInt(cols);
                cy = random.nextInt(rows);
            }

            int wx = cx, wy = cy;
            while (!grid[wx][wy].visited) {
                int dir = random.nextInt(4);
                if (dir == 0 && wy < rows - 1) { walk[wx][wy] = 0; wy++; } // Lên (y+1)
                else if (dir == 1 && wx < cols - 1) { walk[wx][wy] = 1; wx++; } // Phải (x+1)
                else if (dir == 2 && wy > 0) { walk[wx][wy] = 2; wy--; } // Xuống (y-1)
                else if (dir == 3 && wx > 0) { walk[wx][wy] = 3; wx--; } // Trái (x-1)
            }

            wx = cx; wy = cy;
            while (!grid[wx][wy].visited) {
                grid[wx][wy].visited = true;
                unvisitedCount--;

                int dir = walk[wx][wy];
                Cell currentCell = grid[wx][wy];
                Cell nextCell = null;

                if (dir == 0) nextCell = grid[wx][wy + 1];
                else if (dir == 1) nextCell = grid[wx + 1][wy];
                else if (dir == 2) nextCell = grid[wx][wy - 1];
                else if (dir == 3) nextCell = grid[wx - 1][wy];

                if (nextCell != null) {
                    removeWalls(currentCell, nextCell);
                    wx = nextCell.x;
                    wy = nextCell.y;
                }
            }
        }
    }

    /**
     * Thuật toán tìm vị trí Start và End khó nhất theo từng cấp độ hình học (Java)
     */
    public static MazePoint[] determineEndpoints(Cell[][] grid, int cols, int rows, java.util.Random random) {
        int maxDim = Math.max(cols, rows);

        // 1. Cấp độ nhỏ: Start ở Trung tâm, End ở Góc xa nhất
        if (maxDim <= 20) {
            MazePoint start = new MazePoint(cols / 2, rows / 2);
            int[][] dist = bfsDistances(grid, cols, rows, start);

            MazePoint[] corners = new MazePoint[] {
                new MazePoint(0, 0),
                new MazePoint(cols - 1, 0),
                new MazePoint(0, rows - 1),
                new MazePoint(cols - 1, rows - 1)
            };

            MazePoint bestEnd = corners[0];
            int maxDist = dist[corners[0].x][corners[0].y];

            for (MazePoint c : corners) {
                if (dist[c.x][c.y] > maxDist) {
                    maxDist = dist[c.x][c.y];
                    bestEnd = c;
                }
            }
            return new MazePoint[] { start, bestEnd };
        }
        // 2. Cấp độ trung bình: Start ở giữa cạnh Trái, End ở cạnh Phải đối diện
        else if (maxDim <= 50) {
            MazePoint start = new MazePoint(0, rows / 2);
            int[][] dist = bfsDistances(grid, cols, rows, start);

            MazePoint bestEnd = new MazePoint(cols - 1, rows / 2);
            int maxDist = dist[bestEnd.x][bestEnd.y];

            for (int y = 0; y < rows; y++) {
                if (dist[cols - 1][y] > maxDist) {
                    maxDist = dist[cols - 1][y];
                    bestEnd = new MazePoint(cols - 1, y);
                }
            }
            return new MazePoint[] { start, bestEnd };
        }
        // 3. Cấp độ lớn: 2-step BFS tìm khoảng cách xa nhất tuyệt đối (hoặc cặp sát vách)
        else {
            return findFarthestEndpointsDoubleBFS(grid, cols, rows);
        }
    }

    public static int[][] bfsDistances(Cell[][] grid, int cols, int rows, MazePoint start) {
        int[][] dist = new int[cols][rows];
        for (int x = 0; x < cols; x++) {
            for (int y = 0; y < rows; y++) {
                dist[x][y] = -1;
            }
        }

        java.util.Queue<MazePoint> queue = new java.util.LinkedList<>();
        dist[start.x][start.y] = 0;
        queue.add(start);

        while (!queue.isEmpty()) {
            MazePoint curr = queue.poll();
            if (curr == null) break;
            Cell c = grid[curr.x][curr.y];
            int d = dist[curr.x][curr.y];

            // Top (y + 1)
            if (!c.topWall && curr.y < rows - 1 && dist[curr.x][curr.y + 1] == -1) {
                dist[curr.x][curr.y + 1] = d + 1;
                queue.add(new MazePoint(curr.x, curr.y + 1));
            }
            // Right (x + 1)
            if (!c.rightWall && curr.x < cols - 1 && dist[curr.x + 1][curr.y] == -1) {
                dist[curr.x + 1][curr.y] = d + 1;
                queue.add(new MazePoint(curr.x + 1, curr.y));
            }
            // Bottom (y - 1)
            if (!c.bottomWall && curr.y > 0 && dist[curr.x][curr.y - 1] == -1) {
                dist[curr.x][curr.y - 1] = d + 1;
                queue.add(new MazePoint(curr.x, curr.y - 1));
            }
            // Left (x - 1)
            if (!c.leftWall && curr.x > 0 && dist[curr.x - 1][curr.y] == -1) {
                dist[curr.x - 1][curr.y] = d + 1;
                queue.add(new MazePoint(curr.x - 1, curr.y));
            }
        }
        return dist;
    }

    public static MazePoint[] findFarthestEndpointsDoubleBFS(Cell[][] grid, int cols, int rows) {
        // Bước 1: BFS từ [0][0] tìm điểm A xa nhất
        int[][] distA = bfsDistances(grid, cols, rows, new MazePoint(0, 0));
        MazePoint pointA = new MazePoint(0, 0);
        int maxDistA = 0;

        for (int x = 0; x < cols; x++) {
            for (int y = 0; y < rows; y++) {
                if (distA[x][y] > maxDistA) {
                    maxDistA = distA[x][y];
                    pointA = new MazePoint(x, y);
                }
            }
        }

        // Bước 2: BFS từ điểm A tìm điểm B xa nhất
        int[][] distB = bfsDistances(grid, cols, rows, pointA);
        MazePoint pointB = pointA;
        int maxDistB = 0;

        for (int x = 0; x < cols; x++) {
            for (int y = 0; y < rows; y++) {
                if (distB[x][y] > maxDistB) {
                    maxDistB = distB[x][y];
                    pointB = new MazePoint(x, y);
                }
            }
        }

        return new MazePoint[] { pointA, pointB };
    }
}
