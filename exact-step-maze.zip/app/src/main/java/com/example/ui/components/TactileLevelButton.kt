package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeEdgeHighlight
import com.example.ui.theme.MazeStar
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1
import com.example.ui.theme.MazeTextMuted

/**
 * Tactile Level Button với tính năng phóng to & làm nổi bật màn người chơi đang đạt được (isCurrentTarget)
 */
@Composable
fun TactileLevelButton(
    levelNumber: Int,
    size: Int,
    isUnlocked: Boolean,
    isCleared: Boolean,
    starsEarned: Int,
    reqStars: Int,
    currentStars: Int,
    isSaved: Boolean,
    isCurrentTarget: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Pulse animation cho màn đang đạt được
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_target_$levelNumber")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isCurrentTarget) 1.06f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = if (isCurrentTarget) 0.95f else 0.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    val targetWidth = if (isCurrentTarget) 96.dp else 84.dp
    val targetHeight = if (isCurrentTarget) 104.dp else 94.dp

    Box(
        modifier = modifier
            .size(width = targetWidth, height = targetHeight)
            .scale(if (isCurrentTarget) pulseScale else 1f)
            .shadow(
                elevation = if (isCurrentTarget) 10.dp else if (isUnlocked) 4.dp else 1.dp,
                shape = RoundedCornerShape(14.dp),
                ambientColor = if (isCurrentTarget) MazeAmber.copy(alpha = glowAlpha) else Color.Black.copy(alpha = 0.4f),
                spotColor = if (isCurrentTarget) MazeAmber else Color.Black.copy(alpha = 0.5f)
            )
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (isCurrentTarget) {
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF3B3222),
                            Color(0xFF221F18)
                        )
                    )
                } else {
                    Brush.verticalGradient(
                        colors = listOf(
                            MazeSurface2,
                            Color(0xFF1E293B)
                        )
                    )
                }
            )
            .drawBehind {
                // Top inner highlight line
                drawLine(
                    color = if (isCurrentTarget) Color(0x66F59E0B) else Color(0x1AFFFFFF),
                    start = Offset(0f, 1f),
                    end = Offset(this.size.width, 1f),
                    strokeWidth = if (isCurrentTarget) 3f else 2f
                )
            }
            .border(
                width = if (isCurrentTarget) 2.5.dp else 1.dp,
                color = when {
                    isCurrentTarget -> MazeAmber.copy(alpha = glowAlpha)
                    isSaved -> MazeAmber
                    isCleared -> MazeAmber.copy(alpha = 0.6f)
                    else -> MazeEdgeHighlight
                },
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(enabled = isUnlocked, onClick = onClick)
            .testTag("level_btn_$levelNumber")
    ) {
        // Nội dung chính
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Hàng trên: Huy hiệu "ĐANG TỚI" hoặc Sao đánh giá
            Row(
                modifier = Modifier.height(16.dp),
                horizontalArrangement = Arrangement.spacedBy(1.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isCurrentTarget && !isCleared) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(MazeAmber)
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "TIẾP THEO 🎯",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF0F172A)
                        )
                    }
                } else if (isUnlocked && isCleared) {
                    for (i in 1..3) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (i <= starsEarned) MazeStar else Color(0x33FFFFFF),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                } else if (isSaved) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF38BDF8).copy(alpha = 0.2f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "ĐANG CHƠI",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.size(12.dp))
                }
            }

            // Số Level cực to và đậm nằm ở giữa
            Text(
                text = "$levelNumber",
                fontSize = if (isCurrentTarget) 26.sp else 23.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isCurrentTarget) MazeAmber else if (isUnlocked) MazeTextH1 else MazeTextMuted
            )

            // Thông số kích thước 5x5 nhỏ lại nằm ở dưới cùng
            Text(
                text = "${size}×${size}",
                fontSize = 11.sp,
                fontWeight = if (isCurrentTarget) FontWeight.Bold else FontWeight.Medium,
                color = if (isCurrentTarget) Color(0xFFFDE68A) else if (isUnlocked) MazeTextBody else MazeTextMuted
            )
        }

        // Trạng thái Khóa (Locked State)
        if (!isUnlocked) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x8A000000)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Đã khóa",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(22.dp)
                    )
                    if (reqStars > 0) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$currentStars/$reqStars★",
                            color = MazeAmber,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
