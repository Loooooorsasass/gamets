package com.example.ui.components

import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.core.ads.AdConstants
import com.example.data.local.GameProgressEntity
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeSurface1
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

/**
 * Banner quảng cáo ở góc dưới màn hình.
 * - Tự động ẩn hoàn toàn nếu người chơi kích hoạt VIP 1 (tắt banner), VIP 2 hoặc VIP 3.
 * - Tích hợp AdMob AdView thật khi có ID hoặc chạy banner game mượt mà.
 */
@Composable
fun AdBannerView(
    progress: GameProgressEntity,
    onOpenVipShop: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!progress.isBannerAdAllowed()) {
        // Người chơi đã kích hoạt VIP tắt banner -> Không chiếm diện tích màn hình
        return
    }

    val context = LocalContext.current
    val isBannerConfigured = AdConstants.isBannerConfigured
    val bannerId = AdConstants.ADMOB_BANNER_ID.trim()

    var adFailedToLoad by remember { mutableStateOf(false) }

    Surface(
        color = MazeSurface1,
        shape = RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33F59E0B)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("ad_banner_container")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Thanh tiêu đề mini của Banner & Nút Tắt Quảng Cáo VIP
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF334155))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "AD",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Quảng cáo hỗ trợ game",
                        fontSize = 10.sp,
                        color = MazeTextBody
                    )
                }

                // Nút chuyển nhanh đến VIP để tắt quảng cáo
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MazeAmber.copy(alpha = 0.15f))
                        .clickable(onClick = onOpenVipShop)
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = null,
                        tint = MazeAmber,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "Tắt quảng cáo (VIP)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MazeAmber
                    )
                }
            }

            // Vùng hiển thị AdMob Banner hoặc Smart Fallback
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                contentAlignment = Alignment.Center
            ) {
                if (isBannerConfigured && !adFailedToLoad) {
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        factory = { ctx ->
                            AdView(ctx).apply {
                                setAdSize(AdSize.BANNER)
                                adUnitId = bannerId
                                layoutParams = LinearLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.WRAP_CONTENT
                                )
                                adListener = object : com.google.android.gms.ads.AdListener() {
                                    override fun onAdFailedToLoad(error: com.google.android.gms.ads.LoadAdError) {
                                        adFailedToLoad = true
                                    }
                                }
                                try {
                                    loadAd(AdRequest.Builder().build())
                                } catch (e: Exception) {
                                    adFailedToLoad = true
                                }
                            }
                        },
                        update = { adView ->
                            // View is already loaded
                        }
                    )
                } else {
                    // Fallback banner trực quan khi offline hoặc chưa cấu hình AdMob ID
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                                )
                            )
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                            .clickable(onClick = onOpenVipShop)
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "🎮 Trải nghiệm không gián đoạn",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MazeTextH1
                            )
                            Text(
                                text = "Nâng cấp VIP 1 chỉ 2000 Xu hoặc xem 30 video",
                                fontSize = 10.sp,
                                color = MazeAmber
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MazeAmber
                        ) {
                            Text(
                                text = "Xem VIP",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF0F172A),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
