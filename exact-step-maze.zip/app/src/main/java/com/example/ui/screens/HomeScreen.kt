package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.engine.MazeConfig
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.Strings
import com.example.ui.components.GlowingProgressBar
import kotlinx.coroutines.launch
import com.example.ui.components.PremiumSegmentedNav
import com.example.ui.components.TactileImpossibleTierButton
import com.example.ui.components.TactileLevelButton
import com.example.ui.theme.MazeAmber
import com.example.ui.theme.MazeAmberGlow
import com.example.ui.theme.MazeBgDark
import com.example.ui.theme.MazeCoin
import com.example.ui.theme.MazeDanger
import com.example.ui.theme.MazeEdgeHighlight
import com.example.ui.theme.MazeStar
import com.example.ui.theme.MazeSurface1
import com.example.ui.theme.MazeSurface2
import com.example.ui.theme.MazeTextBody
import com.example.ui.theme.MazeTextH1
import com.example.ui.theme.MazeTextMuted
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.GameViewModel

@Composable
fun HomeScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val progress = uiState.progress
    val records = uiState.levelRecords
    val saveSlot = uiState.saveSlot
    val lang = uiState.language

    var showHelpDialog by remember { mutableStateOf(false) }
    var displayedLevelCount by remember { mutableIntStateOf(24) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var resetCheckState by remember { mutableStateOf(false) }
    var selectedLevelDefForDialog by remember { mutableStateOf<com.example.core.engine.LevelDef?>(null) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MazeBgDark)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        // TOP BAR: Brand Title & Pill-shape Stats Badges
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f, fill = false)) {
                Text(
                    text = Strings.appTitle(lang),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MazeTextH1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = Strings.appSubtitle(lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MazeTextBody
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Stats Pill-shape Badges: VIP & Ngôi sao & Xu & Language Switcher
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // VIP Active Badge (nhấn để mở Cửa Hàng VIP)
                if (progress.isVipActive()) {
                    val vipLabel = when (progress.vipTier) {
                        3 -> "VIP 3 👑"
                        2 -> "VIP 2"
                        1 -> "VIP 1"
                        else -> "VIP"
                    }
                    Surface(
                        onClick = { viewModel.navigateTo(AppScreen.SHOP) },
                        shape = RoundedCornerShape(999.dp),
                        color = Color(0xFF1E1E2E),
                        border = BorderStroke(1.dp, Color(0xFFFFD700)),
                        modifier = Modifier.testTag("home_vip_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = "VIP Active",
                                tint = Color(0xFFFFD700),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = vipLabel,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFFFD700)
                            )
                        }
                    }
                }

                // Total Stars Pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(MazeSurface1)
                        .border(1.dp, MazeEdgeHighlight, RoundedCornerShape(999.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Stars",
                        tint = MazeStar,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${progress.totalStars}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MazeTextH1
                    )
                }

                // Coins Pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(MazeSurface1)
                        .border(1.dp, MazeEdgeHighlight, RoundedCornerShape(999.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = "Coins",
                        tint = MazeCoin,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${progress.coins}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MazeTextH1
                    )
                }

                // Language Switcher Button (VI 🇻🇳 <-> EN 🇬🇧)
                Surface(
                    onClick = { viewModel.toggleLanguage() },
                    shape = RoundedCornerShape(999.dp),
                    color = MazeSurface2,
                    border = BorderStroke(1.dp, MazeAmber.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("language_toggle_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = lang.flag, fontSize = 12.sp)
                        Text(
                            text = lang.name,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MazeAmber
                        )
                    }
                }

                // Cloud Sync
                IconButton(
                    onClick = { viewModel.openCloudSync() },
                    modifier = Modifier.size(32.dp).testTag("cloud_sync_icon_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudSync,
                        contentDescription = Strings.cloudSyncTitle(lang),
                        tint = MazeTextBody,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Help Button
                IconButton(
                    onClick = { showHelpDialog = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = Strings.helpDialogTitle(lang),
                        tint = MazeTextBody,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // NAVIGATION: Segmented Control mượt mà (Hôm nay / Xếp hạng / Cửa hàng)
        PremiumSegmentedNav(
            selectedScreen = uiState.currentScreen,
            language = lang,
            onSelectScreen = { screen -> viewModel.navigateTo(screen) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // RESUME GAME BANNER (nếu có saveSlot)
        if (saveSlot != null) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MazeSurface1),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MazeAmber.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .testTag("resume_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        val title = if (saveSlot.defId.startsWith("IMPOSSIBLE")) {
                            "${Strings.superTierTitle(lang)} (Tầng ${saveSlot.tier ?: "1"})"
                        } else {
                            "Level ${saveSlot.defId}"
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = Strings.resumeGameTitle(lang),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MazeAmber
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MazeAmber.copy(alpha = 0.2f),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            ) {
                                Text(
                                    text = title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MazeAmber,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = Strings.resumeGameSub(lang, saveSlot.moves, saveSlot.elapsedSec),
                            style = MaterialTheme.typography.bodySmall,
                            color = MazeTextBody
                        )
                    }

                    Button(
                        onClick = { viewModel.resumeFromSave() },
                        colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF0F172A)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("resume_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(Strings.resumeButton(lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // DAILY CHALLENGE HERO BANNER (Surface 1 + Accent Amber + Icon)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MazeSurface1),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MazeEdgeHighlight, RoundedCornerShape(16.dp))
                .clickable { viewModel.startDailyChallenge() }
                .testTag("daily_challenge_banner")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MazeSurface2),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = "Challenge",
                            tint = MazeAmber,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = Strings.dailyBannerTitle(lang),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MazeTextH1
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = Strings.dailyBannerSub(lang),
                            style = MaterialTheme.typography.bodySmall,
                            color = MazeTextBody
                        )
                    }
                }

                Button(
                    onClick = { viewModel.startDailyChallenge() },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF0F172A))
                ) {
                    Text(Strings.speedRace(lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // PROGRESS TOWARD IMPOSSIBLE (Surface 1 + GlowingProgressBar)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MazeSurface1)
                .border(1.dp, MazeEdgeHighlight, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = Strings.impossibleProgressTitle(lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MazeTextH1
                )
                val clearedCount = minOf(progress.highestCleared, MazeConfig.PASSES_TO_UNLOCK_IMPOSSIBLE)
                Text(
                    text = Strings.levelsProgress(lang, clearedCount, MazeConfig.PASSES_TO_UNLOCK_IMPOSSIBLE),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MazeAmber
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            val progPercent = minOf(progress.highestCleared, MazeConfig.PASSES_TO_UNLOCK_IMPOSSIBLE) / MazeConfig.PASSES_TO_UNLOCK_IMPOSSIBLE.toFloat()
            GlowingProgressBar(
                progress = progPercent,
                activeColor = MazeAmber,
                glowColor = MazeAmberGlow,
                trackColor = MazeSurface2
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // MINI-GAME CARD: ONE-LINE PUZZLE (Mở khóa sau Level 20 Mê Cung)
        val isOneLineUnlocked = progress.highestCleared >= 20
        var showOneLineLockedDialog by remember { mutableStateOf(false) }

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isOneLineUnlocked) Color(0xFF064E3B).copy(alpha = 0.4f) else MazeSurface1
            ),
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (isOneLineUnlocked) {
                        viewModel.navigateTo(AppScreen.ONELINE_GAME)
                    } else {
                        showOneLineLockedDialog = true
                    }
                }
                .border(
                    1.dp,
                    if (isOneLineUnlocked) Color(0xFF10B981).copy(alpha = 0.5f) else MazeEdgeHighlight,
                    RoundedCornerShape(16.dp)
                )
                .testTag("oneline_minigame_card")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isOneLineUnlocked) Color(0xFF047857) else MazeSurface2),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isOneLineUnlocked) "✏️" else "🔒",
                            fontSize = 22.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = Strings.oneLineCardTitle(lang),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isOneLineUnlocked) Color(0xFF34D399) else MazeTextH1
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        if (isOneLineUnlocked) {
                            Text(
                                text = Strings.oneLineUnlockedDesc(lang),
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFA7F3D0)
                            )
                        } else {
                            Text(
                                text = Strings.oneLineLockedDesc(lang, minOf(20, progress.highestCleared), 20),
                                style = MaterialTheme.typography.bodySmall,
                                color = MazeTextBody
                            )
                        }
                    }
                }

                if (isOneLineUnlocked) {
                    Button(
                        onClick = { viewModel.navigateTo(AppScreen.ONELINE_GAME) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF10B981),
                            contentColor = Color.Black
                        )
                    ) {
                        Text(Strings.play(lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MazeSurface2,
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = Strings.locked(lang),
                                tint = MazeTextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Lv.20",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MazeTextMuted
                            )
                        }
                    }
                }
            }
        }

        // Popup Dialog thông báo khóa One-Line
        if (showOneLineLockedDialog) {
            AlertDialog(
                onDismissRequest = { showOneLineLockedDialog = false },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = Strings.locked(lang),
                            tint = MazeAmber
                        )
                        Text(
                            text = Strings.oneLineLockedDialogTitle(lang),
                            fontWeight = FontWeight.Bold,
                            color = MazeTextH1,
                            fontSize = 17.sp
                        )
                    }
                },
                text = {
                    Text(
                        text = Strings.oneLineLockedDialogBody(lang, minOf(20, progress.highestCleared)),
                        color = MazeTextBody,
                        fontSize = 14.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { showOneLineLockedDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF0F172A))
                    ) {
                        Text(Strings.understood(lang), fontWeight = FontWeight.Bold)
                    }
                },
                containerColor = MazeSurface2
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // H2 (Tiêu đề Block): 18pt Semi-bold Trắng (#F8FAFC)
        val coroutineScope = rememberCoroutineScope()
        val levelLazyListState = rememberLazyListState()
        val currentTargetLevel = when {
            saveSlot != null && saveSlot.defId.toIntOrNull() != null -> saveSlot.defId.toInt()
            else -> minOf(MazeConfig.MAX_LEVEL, progress.highestCleared + 1)
        }

        // Tự động cuộn đến màn chơi hiện tại người chơi đang đạt được
        LaunchedEffect(currentTargetLevel) {
            val targetIndex = (currentTargetLevel - 1).coerceAtLeast(0)
            if (targetIndex > 0) {
                levelLazyListState.animateScrollToItem(maxOf(0, targetIndex - 1))
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = Strings.levelListTitle(lang),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MazeTextH1
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MazeAmber.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, MazeAmber.copy(alpha = 0.5f)),
                    onClick = {
                        coroutineScope.launch {
                            val targetIndex = (currentTargetLevel - 1).coerceAtLeast(0)
                            levelLazyListState.animateScrollToItem(maxOf(0, targetIndex - 1))
                        }
                    }
                ) {
                    Text(
                        text = "🎯 Màn $currentTargetLevel",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MazeAmber,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Text(
                text = "5×5 → 299×299",
                style = MaterialTheme.typography.bodySmall,
                color = MazeTextBody
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Thanh chuyển nhanh theo khoảng Màn chơi
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val tiers = listOf(
                "🎯 Đang Chơi" to currentTargetLevel,
                "1 - 20" to 1,
                "21 - 40" to 21,
                "41 - 60" to 41,
                "61 - 80" to 61,
                "81 - 100" to 81
            )
            items(tiers) { (label, jumpLevel) ->
                val isSelected = (jumpLevel == currentTargetLevel) || (jumpLevel != currentTargetLevel && currentTargetLevel in jumpLevel..(jumpLevel + 19))
                Surface(
                    onClick = {
                        coroutineScope.launch {
                            val targetIndex = (jumpLevel - 1).coerceAtLeast(0)
                            levelLazyListState.animateScrollToItem(maxOf(0, targetIndex - 1))
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) MazeAmber.copy(alpha = 0.2f) else MazeSurface2,
                    border = BorderStroke(1.dp, if (isSelected) MazeAmber else MazeEdgeHighlight)
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) MazeAmber else MazeTextBody,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // HORIZONTAL SCROLLING LEVEL MAP VỚI TỰ ĐỘNG CUỘN & PHÓNG TO MÀN ĐẠT ĐƯỢC
        val maxToShow = minOf(MazeConfig.MAX_LEVEL, maxOf(progress.highestCleared + 5, displayedLevelCount))
        val levelList = remember(maxToShow) { (1..maxToShow).toList() }

        LazyRow(
            state = levelLazyListState,
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(levelList, key = { it }) { levelNum ->
                val def = MazeConfig.generateLevelDef(levelNum)
                val isCleared = levelNum <= progress.highestCleared
                val reqStars = MazeConfig.starReqFor(levelNum)
                val isUnlocked = (levelNum <= progress.highestCleared + 1) && (reqStars == 0 || progress.totalStars >= reqStars)
                val starsEarned = records[levelNum.toString()]?.stars ?: 0
                val isSaved = saveSlot?.defId == levelNum.toString()
                val isCurrentTarget = (levelNum == currentTargetLevel)

                TactileLevelButton(
                    levelNumber = levelNum,
                    size = def.w,
                    isUnlocked = isUnlocked,
                    isCleared = isCleared,
                    starsEarned = starsEarned,
                    reqStars = reqStars,
                    currentStars = progress.totalStars,
                    isSaved = isSaved,
                    isCurrentTarget = isCurrentTarget,
                    onClick = {
                        if (isSaved) {
                            viewModel.resumeFromSave()
                        } else if (isCleared) {
                            selectedLevelDefForDialog = def
                        } else {
                            viewModel.startLevel(def)
                        }
                    }
                )
            }
        }

        if (displayedLevelCount < MazeConfig.MAX_LEVEL) {
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(
                onClick = { displayedLevelCount = minOf(MazeConfig.MAX_LEVEL, displayedLevelCount + 20) },
                modifier = Modifier.align(Alignment.CenterHorizontally),
                shape = RoundedCornerShape(12.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.linearGradient(listOf(MazeEdgeHighlight, MazeEdgeHighlight)))
            ) {
                Text(Strings.showMoreLevels(lang), fontSize = 12.sp, color = MazeTextBody)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // CHẾ ĐỘ IMPOSSIBLE (Card Surface 1)
        val isImpossibleUnlocked = progress.highestCleared >= MazeConfig.PASSES_TO_UNLOCK_IMPOSSIBLE
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MazeSurface1),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    color = if (isImpossibleUnlocked) MazeAmber.copy(alpha = 0.5f) else MazeEdgeHighlight,
                    shape = RoundedCornerShape(16.dp)
                )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = Strings.impossibleSectionTitle(lang),
                            tint = if (isImpossibleUnlocked) MazeAmber else MazeTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Strings.impossibleSectionTitle(lang),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isImpossibleUnlocked) MazeAmber else MazeTextH1
                        )
                    }

                    if (!isImpossibleUnlocked) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MazeSurface2,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Mở sau Màn 50",
                                fontSize = 11.sp,
                                color = MazeTextMuted,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (isImpossibleUnlocked) {
                        Strings.impossibleUnlockedDesc(lang)
                    } else {
                        Strings.impossibleLockedDesc(lang)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MazeTextBody
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Tier selectors
                val impScroll = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(impScroll),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    for (tier in 1..MazeConfig.IMPOSSIBLE_TIER_SIZES.size) {
                        val def = MazeConfig.impossibleDefForTier(tier)
                        val tierUnlocked = isImpossibleUnlocked && (tier <= progress.impossibleCleared + 1)
                        val tierCleared = tier <= progress.impossibleCleared
                        val isSaved = saveSlot?.defId == def.id

                        TactileImpossibleTierButton(
                            title = "${def.w}×${def.h}",
                            subtitle = Strings.stepsUnit(lang, def.target),
                            isUnlocked = tierUnlocked,
                            isCleared = tierCleared,
                            isSaved = isSaved,
                            onClick = {
                                if (isSaved) {
                                    viewModel.resumeFromSave()
                                } else if (tierCleared) {
                                    selectedLevelDefForDialog = def
                                } else {
                                    viewModel.startLevel(def)
                                }
                            }
                        )
                    }

                    // Super tier button
                    val superDef = MazeConfig.superDef()
                    val superUnlocked = isImpossibleUnlocked && progress.impossibleCleared >= MazeConfig.IMPOSSIBLE_TIER_SIZES.size
                    val superCleared = progress.superCleared
                    val isSuperSaved = saveSlot?.defId == superDef.id

                    TactileImpossibleTierButton(
                        title = Strings.superTierTitle(lang),
                        subtitle = "1000×1000 · 10k",
                        isUnlocked = superUnlocked,
                        isCleared = superCleared,
                        isSaved = isSuperSaved,
                        isSuper = true,
                        onClick = {
                            if (isSuperSaved) {
                                viewModel.resumeFromSave()
                            } else if (superCleared) {
                                selectedLevelDefForDialog = superDef
                            } else {
                                viewModel.startLevel(superDef)
                            }
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // AUDIO, HAPTIC & LANGUAGE SETTINGS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.toggleSound() }) {
                Icon(
                    imageVector = if (progress.soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = Strings.soundLabel(lang),
                    tint = if (progress.soundEnabled) MazeAmber else MazeTextBody
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            IconButton(onClick = { viewModel.toggleMusic() }) {
                Icon(
                    imageVector = if (progress.musicEnabled) Icons.Default.MusicNote else Icons.Default.MusicOff,
                    contentDescription = Strings.musicLabel(lang),
                    tint = if (progress.musicEnabled) MazeAmber else MazeTextBody
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            IconButton(onClick = { viewModel.toggleHaptics() }) {
                Icon(
                    imageVector = Icons.Default.Vibration,
                    contentDescription = Strings.hapticLabel(lang),
                    tint = if (progress.hapticEnabled) MazeAmber else MazeTextBody
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            IconButton(onClick = { viewModel.toggleLanguage() }) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = Strings.languageLabel(lang),
                    tint = MazeAmber
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Reset progress link
        TextButton(
            onClick = { showResetConfirmDialog = true },
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text(Strings.resetDataButton(lang), color = MazeTextMuted, fontSize = 11.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Reset Confirmation Dialog
    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = {
                showResetConfirmDialog = false
                resetCheckState = false
            },
            title = { Text(Strings.resetDialogTitle(lang), color = MazeDanger, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(Strings.resetDialogBody(lang))
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { resetCheckState = !resetCheckState }
                    ) {
                        Checkbox(
                            checked = resetCheckState,
                            onCheckedChange = { resetCheckState = it }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(Strings.resetCheckboxLabel(lang), fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.confirmResetAll()
                        showResetConfirmDialog = false
                        resetCheckState = false
                    },
                    enabled = resetCheckState,
                    colors = ButtonDefaults.buttonColors(containerColor = MazeDanger)
                ) {
                    Text(Strings.resetConfirmButton(lang))
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showResetConfirmDialog = false
                    resetCheckState = false
                }) {
                    Text(Strings.cancel(lang))
                }
            }
        )
    }

    // Help Dialog
    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text(Strings.helpDialogTitle(lang), fontWeight = FontWeight.Bold, color = MazeTextH1) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(Strings.helpLine1(lang), fontWeight = FontWeight.Bold, color = MazeAmber)
                    Text(Strings.helpLine2(lang))
                    Text(Strings.helpLine3(lang))
                    Text(Strings.helpLine4(lang))
                    Text(Strings.helpLine5(lang))
                    Text(Strings.helpLine6(lang))
                }
            },
            confirmButton = {
                Button(
                    onClick = { showHelpDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF0F172A))
                ) {
                    Text(Strings.understood(lang))
                }
            }
        )
    }

    // Level Action Dialog (Play Again or Replay)
    val selectedDef = selectedLevelDefForDialog
    if (selectedDef != null) {
        val record = records[selectedDef.id]
        val title = when {
            selectedDef.tier == "DAILY" -> Strings.tabDaily(lang)
            selectedDef.tier == "SUPER" -> "${Strings.superTierTitle(lang)} 1000×1000"
            selectedDef.tier != null -> "${Strings.impossibleSectionTitle(lang)} (${selectedDef.tier})"
            else -> "Level ${selectedDef.numericLevel ?: selectedDef.id}"
        }

        AlertDialog(
            onDismissRequest = { selectedLevelDefForDialog = null },
            title = {
                Text(
                    text = "🎮 $title (${selectedDef.w}×${selectedDef.h})",
                    fontWeight = FontWeight.Bold,
                    color = MazeTextH1,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (record != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(Strings.bestRecord(lang), color = MazeTextBody, fontSize = 13.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                for (i in 1..3) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = if (i <= record.stars) MazeStar else Color(0x33FFFFFF),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(Strings.timeLabel(lang), color = MazeTextBody, fontSize = 13.sp)
                            Text("${record.bestTimeSec}s", color = MazeAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(Strings.movesLabel(lang), color = MazeTextBody, fontSize = 13.sp)
                            Text("${record.bestMoves} (${Strings.targetLabel(lang, selectedDef.target)})", color = MazeTextH1, fontSize = 13.sp)
                        }
                    } else {
                        Text(
                            text = Strings.exactGoalLabel(lang, selectedDef.target),
                            color = MazeTextBody,
                            fontSize = 13.sp
                        )
                    }
                }
            },
            confirmButton = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val defToStart = selectedDef
                            selectedLevelDefForDialog = null
                            viewModel.startLevel(defToStart)
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MazeAmber, contentColor = Color(0xFF0F172A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(Strings.playAgain(lang), fontWeight = FontWeight.Bold)
                    }

                    if (record?.pathHistoryJson?.isNotEmpty() == true) {
                        OutlinedButton(
                            onClick = {
                                val defId = selectedDef.id
                                selectedLevelDefForDialog = null
                                viewModel.loadAndStartReplay(defId)
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(Strings.replayRouteBtn(lang), fontWeight = FontWeight.Bold, color = MazeTextH1)
                        }
                    }

                    TextButton(
                        onClick = { selectedLevelDefForDialog = null },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(Strings.close(lang), color = MazeTextMuted)
                    }
                }
            },
            dismissButton = null
        )
    }
}
