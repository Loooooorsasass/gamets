package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MazeAmber,
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF78350F),
    onPrimaryContainer = Color(0xFFFEF3C7),
    secondary = MazePlayer,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF0369A1),
    onSecondaryContainer = Color(0xFFE0F2FE),
    tertiary = MazeAmberGlow,
    onTertiary = Color(0xFF451A03),
    background = MazeBgDark,
    onBackground = MazeTextH1,
    surface = MazeSurface1,
    onSurface = MazeTextH1,
    surfaceVariant = MazeSurface2,
    onSurfaceVariant = MazeTextBody,
    outline = MazeEdgeHighlight,
    outlineVariant = MazeEdgeHighlight,
    error = MazeDanger,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = MazeAmber,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF3C7),
    onPrimaryContainer = Color(0xFF78350F),
    secondary = MazePlayer,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0369A1),
    tertiary = MazeAmberGlow,
    onTertiary = Color.White,
    background = MazeBgLight,
    onBackground = MazeTextLight,
    surface = MazeSurfaceLight,
    onSurface = MazeTextLight,
    surfaceVariant = MazeSurface2Light,
    onSurfaceVariant = MazeTextMuted,
    outline = Color(0x1F000000),
    outlineVariant = Color(0x0D000000),
    error = MazeDanger,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
