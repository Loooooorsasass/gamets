package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Art Director Design Tokens ("Dark Mode Premium & Tactile")
// 1. Background: Slate 900 - Xanh đen sâu, sang trọng hơn đen tuyền
val MazeBgDark = Color(0xFF0F172A)

// 2. Surface 1: Slate 800 - Dùng cho các khối Card nền ("Thử thách Hôm nay", "Chế độ Impossible")
val MazeSurface1 = Color(0xFF1E293B)

// 3. Surface 2: Slate 700 - Dùng cho các ô màn chơi (Buttons/Level boxes)
val MazeSurface2 = Color(0xFF334155)

// 4. Primary Accent: Amber/Vàng hổ phách (#F59E0B) mang lại cảm giác chiến thắng & phần thưởng
val MazeAmber = Color(0xFFF59E0B)
val MazeAmberGlow = Color(0xFFFBBF24)
val MazeAccent = MazeAmber // Đồng bộ toàn hệ thống sang màu Amber hổ phách theo Art Director brief
val MazeAccentMint = Color(0xFF6EE7B7)

// 5. Borders & Edge Highlights
val MazeEdgeHighlight = Color(0x14FFFFFF) // rgba(255, 255, 255, 0.08) - bắt sáng cạnh
val MazeEdgeHighlightBright = Color(0x2EFFFFFF) // rgba(255, 255, 255, 0.18)

// 6. Tactile Button Shadows
val MazeTactileTopHighlight = Color(0x1AFFFFFF) // Top inner highlight
val MazeTactileShadow = Color(0x59000000) // Deep drop shadow

// Text Tokens
val MazeTextH1 = Color(0xFFF8FAFC)
val MazeTextBody = Color(0xFF94A3B8)
val MazeTextMuted = Color(0xFF64748B)

// Semantic Tokens
val MazeStar = Color(0xFFF59E0B)
val MazeCoin = Color(0xFFF59E0B)
val MazeDanger = Color(0xFFEF4444)
val MazeSuccess = Color(0xFF10B981)
val MazePlayer = Color(0xFF38BDF8) // Sky blue for player dot
val MazeWallDark = Color(0xFFE2E8F0)

// Light theme equivalents (for consistency)
val MazeBgLight = Color(0xFFF8FAFC)
val MazeSurfaceLight = Color(0xFFFFFFFF)
val MazeSurface2Light = Color(0xFFE2E8F0)
val MazeTextLight = Color(0xFF0F172A)
