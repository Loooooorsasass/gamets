package com.example.ui.components;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * OneLineGameView - Custom View điều khiển trò chơi giải đố "One-line" (Fill / Vẽ một nét).
 * 
 * Đặc điểm kỹ thuật:
 * - Thuần Android SDK (Canvas và Paint), không sử dụng Game Engine.
 * - Tối ưu hóa hiệu năng: Toàn bộ Paint, Path, RectF được khởi tạo sẵn trong init(), KHÔNG cấp phát bộ nhớ trong onDraw().
 * - Xử lý sự kiện vuốt/kéo (onTouchEvent) với độ nhạy cao, tính toán khoảng cách Manhattan = 1 để di chuyển từng ô một.
 * - Hỗ trợ tính năng "Undo" tự động khi người chơi vuốt ngược lại ô liền trước.
 * - Hỗ trợ tính năng "Hướng dẫn (Hint)" hiển thị đường đi mẫu phủ kín bàn cờ với đường nét đứt neon và số thứ tự bước đi.
 * - Căn giữa lưới (Grid) hoàn hảo trên mọi kích thước màn hình.
 */
public class OneLineGameView extends View {

    // ==========================================
    // 1. CẤU TRÚC DỮ LIỆU & TRẠNG THÁI GAME
    // ==========================================

    /**
     * Lớp biểu diễn tọa độ một ô trên lưới: cột (col - trục X) và hàng (row - trục Y).
     */
    public static class Point {
        public int col;
        public int row;

        public Point(int col, int row) {
            this.col = col;
            this.row = row;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Point point = (Point) o;
            return col == point.col && row == point.row;
        }

        @Override
        public int hashCode() {
            return Objects.hash(col, row);
        }

        @Override
        public String toString() {
            return "(" + col + ", " + row + ")";
        }
    }

    public static final int CELL_EMPTY = 0;
    public static final int CELL_VISITED = 1;
    public static final int CELL_OBSTACLE = 2;

    // Kích thước mặc định của lưới (ví dụ: 5x5)
    private int numRows = 5;
    private int numCols = 5;

    // Ma trận trạng thái lưới hiện tại
    private int[][] grid;

    // Ma trận lưu cấu hình gốc của màn chơi (dùng để reset ván đấu)
    private int[][] initialGrid;

    // Danh sách lưu trữ tọa độ các điểm mà người chơi đã đi qua (tạo thành 1 nét liền mạch)
    private final List<Point> playerPath = new ArrayList<>();

    // Danh sách đường đi giải mẫu (Hint / Solution Path)
    private final List<Point> solutionPath = new ArrayList<>();
    private boolean isHintVisible = false;

    // Vị trí xuất phát ban đầu và vị trí nhân vật hiện tại
    private Point startPoint = new Point(0, 0);
    private Point currentPos = new Point(0, 0);
    private String currentSkinId = "classic_blue";

    // Cờ trạng thái: người chơi có đang nhấn giữ và kéo ngón tay hay không
    private boolean isDragging = false;

    // Tổng số ô cần phải đi qua để hoàn thành màn chơi (tổng số ô không phải vật cản)
    private int totalTargetCells = 0;

    // Trạng thái đã thắng màn chơi
    private boolean isGameWon = false;

    // ==========================================
    // 2. TÍNH TOÁN KÍCH THƯỚC & TỌA ĐỘ VẼ
    // ==========================================
    private float cellSize = 0f;          // Kích thước cạnh của mỗi ô (Pixel)
    private float cellSpacing = 6f;       // Khoảng cách giữa các ô (Pixel)
    private float cellCornerRadius = 12f; // Bo góc cho từng ô
    private float offsetX = 0f;           // Khoảng cách lề trái để căn giữa lưới vào tâm View
    private float offsetY = 0f;           // Khoảng cách lề trên để căn giữa lưới vào tâm View

    // ==========================================
    // 3. ĐỐI TƯỢNG VẼ (PAINT & GRAPHICS)
    // ==========================================
    private Paint gridBackgroundPaint;
    private Paint cellEmptyPaint;
    private Paint cellObstaclePaint;
    private Paint cellVisitedPaint;
    private Paint pathLinePaint;
    private Paint hintLinePaint;
    private Paint hintStepPaint;
    private Paint playerGlowPaint;
    private Paint playerBodyPaint;
    private Paint playerCenterPaint;
    private Paint startMarkerPaint;
    private Paint textPaint;

    // Tái sử dụng đối tượng Path và RectF trong onDraw để tránh rác bộ nhớ (GC allocation)
    private final Path drawPath = new Path();
    private final Path hintDrawPath = new Path();
    private final RectF tempCellRect = new RectF();

    // Rung phản hồi cảm ứng (Haptic feedback)
    private Vibrator vibrator;

    // Interface lắng nghe sự kiện của game
    public interface OnGameStateListener {
        void onPathChanged(List<Point> currentPath, int remainingCells);
        void onGameWin(int totalSteps);
        void onUndo(Point removedPoint);
    }

    private OnGameStateListener gameStateListener;

    // ==========================================
    // 4. CONSTRUCTORS
    // ==========================================
    public OneLineGameView(Context context) {
        super(context);
        init();
    }

    public OneLineGameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public OneLineGameView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    // ==========================================
    // 5. KHỞI TẠO CẤU HÌNH & PAINT
    // ==========================================
    private void init() {
        try {
            vibrator = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
        } catch (Exception ignored) {}

        // --- Cấu hình các Paint cho đồ họa đẹp mắt, chuẩn Material Design 3 ---

        // 1. Nền bảng lưới
        gridBackgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridBackgroundPaint.setColor(Color.parseColor("#1E293B")); // Slate dark
        gridBackgroundPaint.setStyle(Paint.Style.FILL);

        // 2. Ô trống có thể đi (Màu xám tối nhẹ)
        cellEmptyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cellEmptyPaint.setColor(Color.parseColor("#334155"));
        cellEmptyPaint.setStyle(Paint.Style.FILL);

        // 3. Ô vật cản / tường (Màu xám đậm đặc hoặc có vân cảnh báo)
        cellObstaclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cellObstaclePaint.setColor(Color.parseColor("#0F172A"));
        cellObstaclePaint.setStyle(Paint.Style.FILL);

        // 4. Ô đã đi qua (Màu xanh ngọc / Cyan phát sáng)
        cellVisitedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cellVisitedPaint.setColor(Color.parseColor("#0D9488")); // Teal 600
        cellVisitedPaint.setStyle(Paint.Style.FILL);

        // 5. Đường nét liền nối tâm các ô (One-line stroke)
        pathLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        pathLinePaint.setColor(Color.parseColor("#2DD4BF")); // Teal neon sáng
        pathLinePaint.setStyle(Paint.Style.STROKE);
        pathLinePaint.setStrokeCap(Paint.Cap.ROUND);
        pathLinePaint.setStrokeJoin(Paint.Join.ROUND);

        // 6. Đường Hướng Dẫn / Gợi Ý (Hint Line - Vàng Cam phát sáng nét đứt)
        hintLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        hintLinePaint.setColor(Color.parseColor("#F59E0B")); // Amber 500
        hintLinePaint.setStyle(Paint.Style.STROKE);
        hintLinePaint.setStrokeCap(Paint.Cap.ROUND);
        hintLinePaint.setStrokeJoin(Paint.Join.ROUND);
        hintLinePaint.setPathEffect(new DashPathEffect(new float[]{14f, 10f}, 0));

        hintStepPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        hintStepPaint.setColor(Color.parseColor("#FDE047")); // Bright yellow
        hintStepPaint.setTextAlign(Paint.Align.CENTER);
        hintStepPaint.setFakeBoldText(true);

        // 7. Quầng sáng phát quang của nhân vật (Player Glow)
        playerGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        playerGlowPaint.setColor(Color.parseColor("#4DFBBF24")); // Vàng hổ phách bán trong suốt
        playerGlowPaint.setStyle(Paint.Style.FILL);

        // 8. Thân nhân vật chính (Hình tròn vàng rực rỡ)
        playerBodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        playerBodyPaint.setColor(Color.parseColor("#F59E0B")); // Amber 500
        playerBodyPaint.setStyle(Paint.Style.FILL);

        // 9. Điểm sáng tâm nhân vật (Highlight 3D)
        playerCenterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        playerCenterPaint.setColor(Color.WHITE);
        playerCenterPaint.setStyle(Paint.Style.FILL);

        // 10. Điểm đánh dấu ô xuất phát
        startMarkerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        startMarkerPaint.setColor(Color.parseColor("#38BDF8")); // Sky blue
        startMarkerPaint.setStyle(Paint.Style.STROKE);
        startMarkerPaint.setStrokeWidth(3f);

        // 11. Chữ hiển thị
        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(24f);

        setupDefaultLevel();
    }

    private void setupDefaultLevel() {
        int[][] sampleGrid = new int[][]{
                {0, 0, 0},
                {0, 0, 0},
                {0, 0, 0}
        };
        loadLevel(3, 3, sampleGrid, new Point(0, 0));
    }

    public void loadLevel(int rows, int cols, int[][] initialLayout, Point start) {
        loadLevel(rows, cols, initialLayout, start, null);
    }

    public void loadLevel(int rows, int cols, int[][] initialLayout, Point start, @Nullable List<Point> solution) {
        this.numRows = rows;
        this.numCols = cols;
        this.startPoint = new Point(start.col, start.row);
        this.currentPos = new Point(start.col, start.row);
        this.isGameWon = false;
        this.isDragging = false;
        this.isHintVisible = false;

        this.solutionPath.clear();
        if (solution != null) {
            this.solutionPath.addAll(solution);
        }

        this.initialGrid = new int[rows][cols];
        this.grid = new int[rows][cols];
        this.totalTargetCells = 0;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int val = (initialLayout != null && r < initialLayout.length && c < initialLayout[r].length)
                        ? initialLayout[r][c] : CELL_EMPTY;
                this.initialGrid[r][c] = val;
                this.grid[r][c] = val;
                if (val != CELL_OBSTACLE) {
                    totalTargetCells++;
                }
            }
        }

        playerPath.clear();
        playerPath.add(new Point(start.col, start.row));
        this.grid[start.row][start.col] = CELL_VISITED;

        notifyPathChanged();
        invalidate();
    }

    public void resetLevel() {
        if (initialGrid == null) return;
        loadLevel(numRows, numCols, initialGrid, startPoint, solutionPath);
    }

    public boolean undoStep() {
        if (isGameWon || playerPath.size() <= 1) {
            return false;
        }

        Point removed = playerPath.remove(playerPath.size() - 1);
        grid[removed.row][removed.col] = CELL_EMPTY;

        currentPos = playerPath.get(playerPath.size() - 1);

        performHaptic(false);
        if (gameStateListener != null) {
            gameStateListener.onUndo(removed);
        }
        notifyPathChanged();
        invalidate();
        return true;
    }

    /**
     * Bật / Tắt chế độ Hướng dẫn (Hint)
     */
    public void toggleHint(boolean visible) {
        this.isHintVisible = visible;
        invalidate();
    }

    public boolean isHintVisible() {
        return isHintVisible;
    }

    public void setSolutionPath(List<Point> solution) {
        this.solutionPath.clear();
        if (solution != null) {
            this.solutionPath.addAll(solution);
        }
        invalidate();
    }

    public void setOnGameStateListener(OnGameStateListener listener) {
        this.gameStateListener = listener;
    }

    public List<Point> getPlayerPath() {
        return new ArrayList<>(playerPath);
    }

    public int[][] getGrid() {
        return grid;
    }

    public boolean isGameWon() {
        return isGameWon;
    }

    // ==========================================
    // 6. XỬ LÝ SỰ KIỆN VUỐT / CHẠM (ONTOUCHEVENT)
    // ==========================================
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (isGameWon) {
            return super.onTouchEvent(event);
        }

        float touchX = event.getX();
        float touchY = event.getY();

        int targetCol = (int) Math.floor((touchX - offsetX) / cellSize);
        int targetRow = (int) Math.floor((touchY - offsetY) / cellSize);

        switch (event.getActionMasked()) {

            case MotionEvent.ACTION_DOWN:
                if (isInsideGrid(targetCol, targetRow)) {
                    if (targetCol == currentPos.col && targetRow == currentPos.row) {
                        isDragging = true;
                    } else if (targetCol == startPoint.col && targetRow == startPoint.row && playerPath.size() <= 1) {
                        isDragging = true;
                    }
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (!isDragging) {
                    if (isInsideGrid(targetCol, targetRow) && targetCol == currentPos.col && targetRow == currentPos.row) {
                        isDragging = true;
                    } else {
                        return true;
                    }
                }

                if (!isInsideGrid(targetCol, targetRow)) {
                    return true;
                }

                if (targetCol == currentPos.col && targetRow == currentPos.row) {
                    return true;
                }

                // XỬ LÝ TỰ ĐỘNG UNDO KHI VUỐT NGƯỢC
                if (playerPath.size() >= 2) {
                    Point previousPoint = playerPath.get(playerPath.size() - 2);
                    if (targetCol == previousPoint.col && targetRow == previousPoint.row) {
                        undoStep();
                        return true;
                    }
                }

                // DI CHUYỂN BÁM THEO NGÓN TAY TỨC THÌ (MULTI-STEP CELL FILLER)
                int maxSteps = 12;
                int stepCount = 0;
                boolean pathChanged = false;

                while ((currentPos.col != targetCol || currentPos.row != targetRow) && stepCount < maxSteps) {
                    stepCount++;

                    int diffCol = targetCol - currentPos.col;
                    int diffRow = targetRow - currentPos.row;

                    int stepCol = Integer.compare(diffCol, 0);
                    int stepRow = Integer.compare(diffRow, 0);

                    boolean stepSuccess = false;

                    // Thử theo trục có độ lệch lớn hơn
                    if (Math.abs(diffCol) >= Math.abs(diffRow)) {
                        if (stepCol != 0 && tryMoveOneLine(stepCol, 0)) {
                            stepSuccess = true;
                        } else if (stepRow != 0 && tryMoveOneLine(0, stepRow)) {
                            stepSuccess = true;
                        }
                    } else {
                        if (stepRow != 0 && tryMoveOneLine(0, stepRow)) {
                            stepSuccess = true;
                        } else if (stepCol != 0 && tryMoveOneLine(stepCol, 0)) {
                            stepSuccess = true;
                        }
                    }

                    if (stepSuccess) {
                        pathChanged = true;
                        if (isGameWon) break;
                    } else {
                        break;
                    }
                }

                if (pathChanged) {
                    performHaptic(false);
                    notifyPathChanged();
                    checkWinCondition();
                    invalidate();
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                isDragging = false;
                return true;
        }

        return super.onTouchEvent(event);
    }

    private boolean tryMoveOneLine(int deltaCol, int deltaRow) {
        if (deltaCol == 0 && deltaRow == 0) return false;
        int nextCol = currentPos.col + deltaCol;
        int nextRow = currentPos.row + deltaRow;

        if (!isInsideGrid(nextCol, nextRow)) return false;

        if (grid[nextRow][nextCol] == CELL_EMPTY) {
            Point newCell = new Point(nextCol, nextRow);
            playerPath.add(newCell);
            grid[nextRow][nextCol] = CELL_VISITED;
            currentPos = newCell;
            return true;
        }
        return false;
    }

    private boolean isInsideGrid(int col, int row) {
        return col >= 0 && col < numCols && row >= 0 && row < numRows;
    }

    private void checkWinCondition() {
        if (playerPath.size() == totalTargetCells) {
            isGameWon = true;
            isDragging = false;
            performHaptic(true);
            if (gameStateListener != null) {
                gameStateListener.onGameWin(playerPath.size());
            }
        }
    }

    private void notifyPathChanged() {
        if (gameStateListener != null) {
            int remaining = Math.max(0, totalTargetCells - playerPath.size());
            gameStateListener.onPathChanged(getPlayerPath(), remaining);
        }
    }

    private void performHaptic(boolean isSuccess) {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                long duration = isSuccess ? 80 : 15;
                int amplitude = isSuccess ? VibrationEffect.DEFAULT_AMPLITUDE : 50;
                vibrator.vibrate(VibrationEffect.createOneShot(duration, amplitude));
            } else {
                vibrator.vibrate(isSuccess ? 80 : 15);
            }
        } catch (Exception ignored) {}
    }

    // ==========================================
    // 7. HIỂN THỊ ĐỒ HỌA TRÊN CANVAS (ONDRAW)
    // ==========================================
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (grid == null || numRows <= 0 || numCols <= 0) {
            return;
        }

        int viewWidth = getWidth();
        int viewHeight = getHeight();

        if (viewWidth <= 0 || viewHeight <= 0) {
            return;
        }

        /*
         * BƯỚC 1: TÍNH TOÁN KÍCH THƯỚC VÀ CĂN GIỮA LƯỚI
         */
        float availableWidth = viewWidth - getPaddingLeft() - getPaddingRight();
        float availableHeight = viewHeight - getPaddingTop() - getPaddingBottom();

        cellSize = Math.min(availableWidth / numCols, availableHeight / numRows);
        cellSpacing = (cellSize < 8f) ? 0f : Math.max(1f, cellSize * 0.08f);
        cellCornerRadius = (cellSize < 8f) ? 0f : Math.max(2f, cellSize * 0.18f);

        float totalGridWidth = cellSize * numCols;
        float totalGridHeight = cellSize * numRows;

        offsetX = getPaddingLeft() + (availableWidth - totalGridWidth) / 2f;
        offsetY = getPaddingTop() + (availableHeight - totalGridHeight) / 2f;

        pathLinePaint.setStrokeWidth(Math.max(2f, cellSize * 0.32f));
        hintLinePaint.setStrokeWidth(Math.max(2f, cellSize * 0.16f));
        hintStepPaint.setTextSize(Math.max(8f, cellSize * 0.28f));

        /*
         * BƯỚC 2: VẼ NỀN TẤT CẢ CÁC Ô TRONG LƯỚI
         */
        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                float left = offsetX + c * cellSize + cellSpacing / 2f;
                float top = offsetY + r * cellSize + cellSpacing / 2f;
                float right = left + cellSize - cellSpacing;
                float bottom = top + cellSize - cellSpacing;

                tempCellRect.set(left, top, right, bottom);

                int cellState = grid[r][c];

                if (cellState == CELL_OBSTACLE) {
                    canvas.drawRoundRect(tempCellRect, cellCornerRadius, cellCornerRadius, cellObstaclePaint);
                } else if (cellState == CELL_VISITED) {
                    canvas.drawRoundRect(tempCellRect, cellCornerRadius, cellCornerRadius, cellVisitedPaint);
                } else {
                    canvas.drawRoundRect(tempCellRect, cellCornerRadius, cellCornerRadius, cellEmptyPaint);
                }

                if (r == startPoint.row && c == startPoint.col) {
                    canvas.drawRoundRect(tempCellRect, cellCornerRadius, cellCornerRadius, startMarkerPaint);
                }
            }
        }

        /*
         * BƯỚC 2.5: VẼ HƯỚNG DẪN (HINT PATH) NẾU ĐƯỢC BẬT
         */
        if (isHintVisible && solutionPath.size() > 1) {
            hintDrawPath.reset();
            Point first = solutionPath.get(0);
            float startCenterX = offsetX + first.col * cellSize + cellSize / 2f;
            float startCenterY = offsetY + first.row * cellSize + cellSize / 2f;
            hintDrawPath.moveTo(startCenterX, startCenterY);

            for (int i = 1; i < solutionPath.size(); i++) {
                Point p = solutionPath.get(i);
                float cx = offsetX + p.col * cellSize + cellSize / 2f;
                float cy = offsetY + p.row * cellSize + cellSize / 2f;
                hintDrawPath.lineTo(cx, cy);
            }
            canvas.drawPath(hintDrawPath, hintLinePaint);

            // Vẽ số thứ tự bước đi nhỏ trên mỗi ô nếu kích thước ô đủ lớn
            if (cellSize >= 20f) {
                for (int i = 0; i < solutionPath.size(); i++) {
                    Point p = solutionPath.get(i);
                    float cx = offsetX + p.col * cellSize + cellSize / 2f;
                    float cy = offsetY + p.row * cellSize + cellSize / 2f + (cellSize * 0.10f);
                    canvas.drawText(String.valueOf(i + 1), cx, cy, hintStepPaint);
                }
            }
        }

        /*
         * BƯỚC 3: VẼ ĐƯỜNG NỐI TÂM (ONE-LINE PATH) NỐI TẤT CẢ CÁC Ô TRONG PLAYER_PATH
         */
        if (playerPath.size() > 1) {
            drawPath.reset();
            Point first = playerPath.get(0);
            float startCenterX = offsetX + first.col * cellSize + cellSize / 2f;
            float startCenterY = offsetY + first.row * cellSize + cellSize / 2f;
            drawPath.moveTo(startCenterX, startCenterY);

            for (int i = 1; i < playerPath.size(); i++) {
                Point p = playerPath.get(i);
                float cx = offsetX + p.col * cellSize + cellSize / 2f;
                float cy = offsetY + p.row * cellSize + cellSize / 2f;
                drawPath.lineTo(cx, cy);
            }

            canvas.drawPath(drawPath, pathLinePaint);
        }

        /*
         * BƯỚC 4: VẼ NHÂN VẬT TẠI VỊ TRÍ HIỆN TẠI (CURRENT_POS)
         */
        if (currentPos != null && isInsideGrid(currentPos.col, currentPos.row)) {
            float playerCenterX = offsetX + currentPos.col * cellSize + cellSize / 2f;
            float playerCenterY = offsetY + currentPos.row * cellSize + cellSize / 2f;

            float glowRadius = cellSize * 0.44f;
            canvas.drawCircle(playerCenterX, playerCenterY, glowRadius, playerGlowPaint);

            float bodyRadius = cellSize * 0.32f;
            canvas.drawCircle(playerCenterX, playerCenterY, bodyRadius, playerBodyPaint);

            float highlightRadius = cellSize * 0.09f;
            canvas.drawCircle(
                    playerCenterX - bodyRadius * 0.35f,
                    playerCenterY - bodyRadius * 0.35f,
                    highlightRadius,
                    playerCenterPaint
            );
        }
    }
}
