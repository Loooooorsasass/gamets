package com.example.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.engine.LevelDef
import com.example.core.engine.MazeConfig
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.Strings
import com.example.data.shop.ShopCatalog
import com.example.ui.components.DPad
import com.example.ui.components.MazeCanvas
import com.example.ui.theme.MazeAccent
import com.example.ui.theme.MazeDanger
import com.example.ui.theme.MazeStar
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.GameViewModel

@Composable
fun GameScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val lang = uiState.language
    val game = uiState.activeGame
    val maze = game.maze
    val levelDef = game.levelDef
    val context = LocalContext.current
    val activity = context as? Activity

    // Android Physical Back Handler
    BackHandler {
        viewModel.requestExit()
    }

    if (maze == null || levelDef == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = Strings.preparingLevel(lang),
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.navigateTo(AppScreen.HOME) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color(0xFF0F172A))
                ) {
                    Text(Strings.backToHome(lang))
                }
            }
        }
        return
    }

    val theme = ShopCatalog.getThemeById(uiState.progress.currentMazeThemeId)
    val skin = ShopCatalog.getSkinById(uiState.progress.currentSkinId)

    Box(modifier = modifier.fillMaxSize().background(theme.bgColor)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // TOP BAR: Back button & Level Title & Powerups
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.requestExit() },
                    modifier = Modifier.testTag("game_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = Strings.back(lang),
                        tint = theme.wallColor
                    )
                }

                val titleText = when {
                    levelDef.tier == "DAILY" -> "📅 ${Strings.tabDaily(lang)} — ${maze.w}×${maze.h}"
                    levelDef.isFinal -> "👑 ${if (levelDef.tier == "SUPER") Strings.superTierTitle(lang) else Strings.impossibleSectionTitle(lang)} — ${maze.w}×${maze.h}"
                    else -> "${Strings.levelNum(lang, levelDef.numericLevel ?: 1)} — ${maze.w}×${maze.h}"
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = titleText,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        color = theme.wallColor
                    )
                    Text(
                        text = Strings.reachFlagHint(lang),
                        fontSize = 12.sp,
                        color = theme.accentColor,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row {
                    IconButton(
                        onClick = { viewModel.resetCurrentLevel() },
                        modifier = Modifier.testTag("game_reset_level_top_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = Strings.reset(lang),
                            tint = theme.wallColor.copy(alpha = 0.7f)
                        )
                    }
                    IconButton(onClick = { viewModel.useHint() }) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = Strings.hint(lang),
                            tint = if (game.showHint) Color(0xFFFBBF24) else theme.wallColor.copy(alpha = 0.7f)
                        )
                    }
                    IconButton(onClick = { viewModel.toggleSound() }) {
                        Icon(
                            imageVector = if (uiState.progress.soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Sound",
                            tint = theme.wallColor.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // HUD STATS BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(theme.panelColor)
                    .border(1.dp, theme.wallColor.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                HudItem(
                    label = Strings.steps(lang),
                    value = "${game.moves}",
                    textColor = theme.accentColor
                )

                HudItem(
                    label = Strings.time(lang),
                    value = "${game.elapsedSec}s",
                    textColor = theme.wallColor
                )

                HudItem(
                    label = Strings.coordinates(lang),
                    value = MazeConfig.encodeCoord(game.player),
                    textColor = theme.wallColor.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Control Mode switcher
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = Strings.controls(lang),
                    fontSize = 12.sp,
                    color = theme.wallColor.copy(alpha = 0.7f),
                    fontWeight = FontWeight.Medium
                )

                Surface(
                    onClick = { viewModel.toggleControlMode() },
                    shape = RoundedCornerShape(16.dp),
                    color = if (game.controlMode == com.example.ui.components.GridControlMode.AUTO)
                        theme.accentColor.copy(alpha = 0.18f)
                    else
                        theme.wallColor.copy(alpha = 0.12f),
                    border = BorderStroke(
                        1.dp,
                        if (game.controlMode == com.example.ui.components.GridControlMode.AUTO)
                            theme.accentColor
                        else
                            theme.wallColor.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier.testTag("toggle_control_mode_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (game.controlMode == com.example.ui.components.GridControlMode.AUTO) Strings.controlAuto(lang) else Strings.controlStep(lang),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (game.controlMode == com.example.ui.components.GridControlMode.AUTO)
                                theme.accentColor
                            else
                                theme.wallColor
                        )
                        Text(
                            text = if (game.controlMode == com.example.ui.components.GridControlMode.AUTO) "(${Strings.controlAutoSub(lang)})" else "(${Strings.controlStepSub(lang)})",
                            fontSize = 10.sp,
                            color = theme.wallColor.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // MAZE CANVAS BOARD (DIRECT CELL DRAG-FOLLOW + SWIPE)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false),
                contentAlignment = Alignment.Center
            ) {
                MazeCanvas(
                    maze = maze,
                    player = game.player,
                    visitedCells = game.visitedCells,
                    pathHistory = game.pathHistory,
                    theme = theme,
                    skin = skin,
                    vision = levelDef.vision,
                    hintPath = if (game.showHint) maze.spine else null,
                    controlMode = game.controlMode,
                    onMove = { dx, dy -> viewModel.tryMove(dx, dy) },
                    onUndo = { viewModel.undoMove() },
                    onWin = { viewModel.handleWinDirect() },
                    modifier = Modifier.testTag("game_maze_canvas")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // D-PAD & ASSIST CONTROLS
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Quick Actions (Hint, Undo)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistButton(
                        icon = "💡",
                        label = "${Strings.hint(lang)} (${uiState.progress.hintCount})",
                        onClick = { viewModel.useHint(activity) }
                    )
                    AssistButton(
                        icon = "↩️",
                        label = "${Strings.undo(lang)}",
                        onClick = { viewModel.undoMove() }
                    )
                }

                // Center: D-Pad
                DPad(
                    onMove = { dx, dy -> viewModel.tryMove(dx, dy) },
                    modifier = Modifier.testTag("game_dpad")
                )

                // Right Quick Actions (Skip, Free Coins)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistButton(
                        icon = "⏩",
                        label = "${Strings.skip(lang)} (${uiState.progress.skipTokens})",
                        onClick = { viewModel.skipCurrentLevel(activity) }
                    )
                    AssistButton(
                        icon = "🪙",
                        label = "+50 🪙 (${Strings.watchAd(lang)})",
                        onClick = { viewModel.triggerRewardedAd(activity, "COINS") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
        }

        // EXIT CONFIRMATION MODAL (Android back flow)
        if (game.showExitDialog) {
            AlertDialog(
                onDismissRequest = { viewModel.dismissExitDialog() },
                title = { Text(text = Strings.exitTitle(lang), fontWeight = FontWeight.Bold) },
                text = {
                    Text(text = Strings.exitMessage(lang, game.moves, game.elapsedSec))
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.saveAndExit() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.testTag("save_and_exit_btn")
                    ) {
                        Text(Strings.saveAndExit(lang))
                    }
                },
                dismissButton = {
                    Row {
                        OutlinedButton(
                            onClick = { viewModel.discardAndExit() },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MazeDanger)
                        ) {
                            Text(Strings.discardAndExit(lang))
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        TextButton(onClick = { viewModel.dismissExitDialog() }) {
                            Text(Strings.cancel(lang))
                        }
                    }
                }
            )
        }

        // WIN OVERLAY MODAL
        if (game.gameOver && game.hasWon) {
            GameWinModal(
                levelDef = levelDef,
                language = lang,
                moves = game.moves,
                elapsedSec = game.elapsedSec,
                earnedStars = game.earnedStars,
                justUnlockedImpossible = game.justUnlockedImpossible,
                justUnlockedNextTier = game.justUnlockedNextTier,
                justClearedSuper = game.justClearedSuper,
                onNextLevel = {
                    if (levelDef.isFinal) {
                        val nextDef = game.nextTierDef ?: levelDef
                        viewModel.startLevel(nextDef)
                    } else if (levelDef.numericLevel != null) {
                        viewModel.startLevel(MazeConfig.generateLevelDef(levelDef.numericLevel + 1))
                    }
                },
                onReplay = { viewModel.startReplay() },
                onGoHome = { viewModel.navigateTo(AppScreen.HOME) }
            )
        }

        // LOSS OVERLAY MODAL
        if (game.gameOver && !game.hasWon) {
            GameLossModal(
                reason = uiState.toastMessage ?: Strings.lossTitle(lang),
                language = lang,
                canReview = game.pathHistory.isNotEmpty(),
                onReview = { viewModel.startReplay() },
                onRetry = { viewModel.startLevel(levelDef) },
                onAddExtraTimeAd = { viewModel.triggerRewardedAd(activity, "TIME") },
                onGoHome = { viewModel.navigateTo(AppScreen.HOME) }
            )
        }
    }
}

@Composable
private fun HudItem(
    label: String,
    value: String,
    textColor: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            fontSize = 9.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

@Composable
private fun AssistButton(
    icon: String,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = Modifier.width(104.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = icon, fontSize = 13.sp)
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun GameWinModal(
    levelDef: LevelDef,
    language: AppLanguage,
    moves: Int,
    elapsedSec: Int,
    earnedStars: Int,
    justUnlockedImpossible: Boolean,
    justUnlockedNextTier: Boolean,
    justClearedSuper: Boolean,
    onNextLevel: () -> Unit,
    onReplay: () -> Unit,
    onGoHome: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.75f))
            .clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(24.dp))
                .testTag("win_modal")
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "🎉 ${Strings.winTitle(language)}",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Stars display
                if (!levelDef.isFinal) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (i in 1..3) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = if (i <= earnedStars) MazeStar else MaterialTheme.colorScheme.outlineVariant,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                Text(
                    text = Strings.winStats(language, moves, elapsedSec),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (justUnlockedImpossible) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "👑 ${Strings.impossibleUnlocked(language)}",
                        color = MazeDanger,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                if (justClearedSuper) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "👑 ${Strings.superCleared(language)}",
                        color = Color(0xFFFFD700),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    )
                }

                if (justUnlockedNextTier) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "🔥 ${Strings.nextTierUnlocked(language)}",
                        color = MazeAccent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Actions
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onNextLevel,
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("win_next_level_btn"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = if (levelDef.isFinal) Strings.nextTier(language) else "${Strings.nextLevel(language)} (${levelDef.w + 1}×${levelDef.h + 1})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onReplay,
                        modifier = Modifier.fillMaxWidth().height(44.dp).testTag("win_replay_btn"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = Strings.replayRoute(language), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    TextButton(
                        onClick = onGoHome,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = Strings.backToHome(language), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun GameLossModal(
    reason: String,
    language: AppLanguage,
    canReview: Boolean = false,
    onReview: () -> Unit = {},
    onRetry: () -> Unit,
    onAddExtraTimeAd: () -> Unit,
    onGoHome: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.75f))
            .clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .border(2.dp, MazeDanger, RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "💔 ${Strings.lossTitle(language)}",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MazeDanger
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = reason,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (canReview) {
                        OutlinedButton(
                            onClick = onReview,
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(imageVector = Icons.Default.Replay, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(Strings.reviewPath(language), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Button(
                        onClick = onRetry,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(Strings.retry(language), fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onAddExtraTimeAd,
                        modifier = Modifier.fillMaxWidth().height(44.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(Strings.watchAdExtraTime(language))
                    }

                    TextButton(
                        onClick = onGoHome,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(Strings.backToHome(language), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
