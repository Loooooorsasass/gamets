package com.example.core.engine

import java.util.ArrayDeque
import kotlin.random.Random

/**
 * MazeBuilder - Hệ thống sinh mê cung thế hệ mới chia làm 3 cấp độ thuật toán chuyên biệt:
 *
 * 1. Cấp độ nhỏ (5x5 đến 20x20): Thuật toán Quay lui (Recursive Backtracking with Stack)
 *    - Tạo ra những "dòng sông" dài, hẹp, uốn lượn zíc-zắc sâu vào tận cùng trước khi chạm ngõ cụt.
 *    - Lời giải chiếm phần lớn diện tích mê cung, ít ngã rẽ ngắn, thách thức kiên nhẫn và định hướng.
 *
 * 2. Cấp độ trung bình (21x21 đến 50x50): Thuật toán Kruskal ngẫu nhiên (Randomized Kruskal with Disjoint Set)
 *    - Mê cung có tính phân dạng (fractal) với vô số ngõ cụt ngắn và trung bình đan xen chằng chịt.
 *    - Hệ số phân nhánh cực cao, không có đường chính nổi bật, mắt người rất khó tìm ra lối đi bằng cách nhìn lướt.
 *
 * 3. Cấp độ lớn (Trên 50x50): Thuật toán Wilson (Uniform Spanning Tree) & Thuật toán Eller (Row-by-Row O(N))
 *    - Wilson (51x51 đến 80x80): Cây bao trùm đồng nhất qua bước đi ngẫu nhiên xóa vòng lặp (Loop-Erased Random Walk),
 *      hoàn toàn không có thiên vị thị giác, hỗn loạn hoàn hảo.
 *    - Eller (>80x80): Sinh mê cung từng hàng một với bộ nhớ O(N), tối ưu tuyệt đối hiệu suất, không bao giờ tràn RAM.
 */
object MazeBuilder {

    const val WALL_TOP: Byte = 1        // Bit 0 (0000 0001) - Tường trên (y + 1)
    const val WALL_RIGHT: Byte = 2      // Bit 1 (0000 0010) - Tường phải (x + 1)
    const val WALL_BOTTOM: Byte = 4     // Bit 2 (0000 0100) - Tường dưới (y - 1)
    const val WALL_LEFT: Byte = 8       // Bit 3 (0000 1000) - Tường trái (x - 1)
    const val WALLS_ALL: Byte = 15      // 1 | 2 | 4 | 8 (0000 1111) - Khởi tạo cả 4 bức tường đều đóng

    fun randomSeed(): ULong {
        return Random.nextLong().toULong()
    }

    /**
     * Tự động điều hướng và áp dụng thuật toán tối ưu dựa trên kích thước lưới mê cung.
     */
    fun buildMaze(w: Int, h: Int, target: Int, seedBig: ULong): Maze {
        val totalCells = w * h
        val random = Random(seedBig.toLong())
        val maxDim = maxOf(w, h)

        val grid: ByteArray = when {
            maxDim <= 20 -> generateBacktracking(w, h, random)
            maxDim <= 50 -> generateKruskal(w, h, random)
            maxDim <= 80 -> generateWilson(w, h, random)
            else -> generateEller(w, h, random)
        }

        // Chuyển đổi bitmask sang chuẩn Game Mask (Bit = 1 nghĩa là hướng đi mở thông suốt)
        val masks = IntArray(totalCells)
        for (i in 0 until totalCells) {
            val cellWall = grid[i].toInt() and 0x0F
            var openMask = 0
            if ((cellWall and WALL_TOP.toInt()) == 0) openMask = openMask or NORTH
            if ((cellWall and WALL_RIGHT.toInt()) == 0) openMask = openMask or EAST
            if ((cellWall and WALL_BOTTOM.toInt()) == 0) openMask = openMask or SOUTH
            if ((cellWall and WALL_LEFT.toInt()) == 0) openMask = openMask or WEST
            masks[i] = openMask
        }

        // Xác định vị trí Start và Goal khó nhất theo từng thuật toán & Double BFS
        val (startIdx, goalIdx) = determineOptimalEndpoints(masks, w, h, maxDim, random)
        val start = Point(startIdx % w, startIdx / w)
        val goal = Point(goalIdx % w, goalIdx / w)

        // Tìm đường đi tối ưu đến Lá Cờ Đỏ
        val spine = findShortestPath(masks, w, h, startIdx, goalIdx)

        return Maze(
            w = w,
            h = h,
            masks = masks,
            start = start,
            goal = goal,
            spine = spine,
            target = spine.size - 1,
            seedStr = seedBig.toString()
        )
    }

    // =========================================================================
    // 1. CẤP ĐỘ NHỎ (5x5 ĐẾN 20x20): THUẬT TOÁN QUAY LUI (BACKTRACKING WITH STACK)
    // =========================================================================
    fun generateBacktracking(w: Int, h: Int, random: Random): ByteArray {
        val totalCells = w * h
        val grid = ByteArray(totalCells) { WALLS_ALL }
        val visited = BooleanArray(totalCells)
        val stack = IntArray(totalCells)
        var stackSize = 0

        val startX = random.nextInt(w)
        val startY = random.nextInt(h)
        val startIdx = startY * w + startX

        visited[startIdx] = true
        stack[stackSize++] = startIdx

        val neighbors = IntArray(4)
        val dirs = IntArray(4)

        while (stackSize > 0) {
            val curr = stack[stackSize - 1]
            val cx = curr % w
            val cy = curr / w

            var count = 0
            // TOP (y + 1)
            if (cy < h - 1 && !visited[(cy + 1) * w + cx]) {
                neighbors[count] = (cy + 1) * w + cx
                dirs[count] = 0
                count++
            }
            // RIGHT (x + 1)
            if (cx < w - 1 && !visited[cy * w + (cx + 1)]) {
                neighbors[count] = cy * w + (cx + 1)
                dirs[count] = 1
                count++
            }
            // BOTTOM (y - 1)
            if (cy > 0 && !visited[(cy - 1) * w + cx]) {
                neighbors[count] = (cy - 1) * w + cx
                dirs[count] = 2
                count++
            }
            // LEFT (x - 1)
            if (cx > 0 && !visited[cy * w + (cx - 1)]) {
                neighbors[count] = cy * w + (cx - 1)
                dirs[count] = 3
                count++
            }

            if (count > 0) {
                val pick = random.nextInt(count)
                val nextIdx = neighbors[pick]
                val dir = dirs[pick]

                when (dir) {
                    0 -> { // TOP
                        grid[curr] = (grid[curr].toInt() and WALL_TOP.toInt().inv()).toByte()
                        grid[nextIdx] = (grid[nextIdx].toInt() and WALL_BOTTOM.toInt().inv()).toByte()
                    }
                    1 -> { // RIGHT
                        grid[curr] = (grid[curr].toInt() and WALL_RIGHT.toInt().inv()).toByte()
                        grid[nextIdx] = (grid[nextIdx].toInt() and WALL_LEFT.toInt().inv()).toByte()
                    }
                    2 -> { // BOTTOM
                        grid[curr] = (grid[curr].toInt() and WALL_BOTTOM.toInt().inv()).toByte()
                        grid[nextIdx] = (grid[nextIdx].toInt() and WALL_TOP.toInt().inv()).toByte()
                    }
                    3 -> { // LEFT
                        grid[curr] = (grid[curr].toInt() and WALL_LEFT.toInt().inv()).toByte()
                        grid[nextIdx] = (grid[nextIdx].toInt() and WALL_RIGHT.toInt().inv()).toByte()
                    }
                }

                visited[nextIdx] = true
                stack[stackSize++] = nextIdx
            } else {
                stackSize--
            }
        }
        return grid
    }

    // =========================================================================
    // 2. CẤP ĐỘ TRUNG BÌNH (21x21 ĐẾN 50x50): KRUSKAL NGẪU NHIÊN (DISJOINT SET)
    // =========================================================================
    fun generateKruskal(w: Int, h: Int, random: Random): ByteArray {
        val totalCells = w * h
        val grid = ByteArray(totalCells) { WALLS_ALL }
        val parent = IntArray(totalCells) { it }

        fun find(i: Int): Int {
            var root = i
            while (root != parent[root]) {
                root = parent[root]
            }
            var curr = i
            while (curr != root) {
                val nxt = parent[curr]
                parent[curr] = root
                curr = nxt
            }
            return root
        }

        // Thu thập tất cả bức tường bên trong lưới
        val totalEdges = (w - 1) * h + w * (h - 1)
        val edgeFrom = IntArray(totalEdges)
        val edgeTo = IntArray(totalEdges)
        val edgeDir = IntArray(totalEdges) // 0: TOP (y -> y+1), 1: RIGHT (x -> x+1)
        var edgeCount = 0

        for (y in 0 until h) {
            for (x in 0 until w) {
                val idx = y * w + x
                if (x < w - 1) {
                    edgeFrom[edgeCount] = idx
                    edgeTo[edgeCount] = y * w + (x + 1)
                    edgeDir[edgeCount] = 1
                    edgeCount++
                }
                if (y < h - 1) {
                    edgeFrom[edgeCount] = idx
                    edgeTo[edgeCount] = (y + 1) * w + x
                    edgeDir[edgeCount] = 0
                    edgeCount++
                }
            }
        }

        // Xáo trộn ngẫu nhiên danh sách cạnh (Fisher-Yates Shuffle)
        for (i in edgeCount - 1 downTo 1) {
            val j = random.nextInt(i + 1)
            val tf = edgeFrom[i]; edgeFrom[i] = edgeFrom[j]; edgeFrom[j] = tf
            val tt = edgeTo[i]; edgeTo[i] = edgeTo[j]; edgeTo[j] = tt
            val td = edgeDir[i]; edgeDir[i] = edgeDir[j]; edgeDir[j] = td
        }

        for (i in 0 until edgeCount) {
            val id1 = edgeFrom[i]
            val id2 = edgeTo[i]
            val root1 = find(id1)
            val root2 = find(id2)

            if (root1 != root2) {
                val dir = edgeDir[i]
                if (dir == 1) { // RIGHT
                    grid[id1] = (grid[id1].toInt() and WALL_RIGHT.toInt().inv()).toByte()
                    grid[id2] = (grid[id2].toInt() and WALL_LEFT.toInt().inv()).toByte()
                } else { // TOP
                    grid[id1] = (grid[id1].toInt() and WALL_TOP.toInt().inv()).toByte()
                    grid[id2] = (grid[id2].toInt() and WALL_BOTTOM.toInt().inv()).toByte()
                }
                parent[root1] = root2
            }
        }
        return grid
    }

    // =========================================================================
    // 3. CẤP ĐỘ LỚN (51x51 ĐẾN 80x80): THUẬT TOÁN WILSON (LOOP-ERASED RANDOM WALK)
    // =========================================================================
    fun generateWilson(w: Int, h: Int, random: Random): ByteArray {
        val totalCells = w * h
        val grid = ByteArray(totalCells) { WALLS_ALL }
        val inMaze = BooleanArray(totalCells)
        val walkDir = IntArray(totalCells) { -1 }

        // Chọn 1 ô ngẫu nhiên đầu tiên để đưa vào mê cung
        val startCell = random.nextInt(totalCells)
        inMaze[startCell] = true

        val unvisitedIndices = IntArray(totalCells) { it }
        var unvisitedCount = totalCells
        // Đưa startCell về cuối và giảm kích thước
        unvisitedIndices[startCell] = unvisitedIndices[totalCells - 1]
        unvisitedCount--

        val candidateDirs = IntArray(4)
        val candidateNeighbors = IntArray(4)

        while (unvisitedCount > 0) {
            // Lấy ngẫu nhiên 1 ô chưa thuộc mê cung
            var pick = random.nextInt(unvisitedCount)
            var startWalk = unvisitedIndices[pick]
            while (inMaze[startWalk]) {
                unvisitedIndices[pick] = unvisitedIndices[unvisitedCount - 1]
                unvisitedCount--
                if (unvisitedCount == 0) break
                pick = random.nextInt(unvisitedCount)
                startWalk = unvisitedIndices[pick]
            }
            if (unvisitedCount == 0) break

            var curr = startWalk
            // Bước đi ngẫu nhiên xóa vòng lặp cho đến khi chạm vào cây mê cung đã có
            while (!inMaze[curr]) {
                val cx = curr % w
                val cy = curr / w

                var validDirCount = 0
                if (cy < h - 1) {
                    candidateDirs[validDirCount] = 0 // TOP
                    candidateNeighbors[validDirCount] = (cy + 1) * w + cx
                    validDirCount++
                }
                if (cx < w - 1) {
                    candidateDirs[validDirCount] = 1 // RIGHT
                    candidateNeighbors[validDirCount] = cy * w + (cx + 1)
                    validDirCount++
                }
                if (cy > 0) {
                    candidateDirs[validDirCount] = 2 // BOTTOM
                    candidateNeighbors[validDirCount] = (cy - 1) * w + cx
                    validDirCount++
                }
                if (cx > 0) {
                    candidateDirs[validDirCount] = 3 // LEFT
                    candidateNeighbors[validDirCount] = cy * w + (cx - 1)
                    validDirCount++
                }

                val dIndex = random.nextInt(validDirCount)
                walkDir[curr] = candidateDirs[dIndex]
                curr = candidateNeighbors[dIndex]
            }

            // Retrace và phá vỡ tường để ghép nhánh mới vào mê cung
            var trace = startWalk
            while (!inMaze[trace]) {
                inMaze[trace] = true
                val dir = walkDir[trace]
                val tcx = trace % w
                val tcy = trace / w
                var nextCell = -1

                when (dir) {
                    0 -> {
                        nextCell = (tcy + 1) * w + tcx
                        grid[trace] = (grid[trace].toInt() and WALL_TOP.toInt().inv()).toByte()
                        grid[nextCell] = (grid[nextCell].toInt() and WALL_BOTTOM.toInt().inv()).toByte()
                    }
                    1 -> {
                        nextCell = tcy * w + (tcx + 1)
                        grid[trace] = (grid[trace].toInt() and WALL_RIGHT.toInt().inv()).toByte()
                        grid[nextCell] = (grid[nextCell].toInt() and WALL_LEFT.toInt().inv()).toByte()
                    }
                    2 -> {
                        nextCell = (tcy - 1) * w + tcx
                        grid[trace] = (grid[trace].toInt() and WALL_BOTTOM.toInt().inv()).toByte()
                        grid[nextCell] = (grid[nextCell].toInt() and WALL_TOP.toInt().inv()).toByte()
                    }
                    3 -> {
                        nextCell = tcy * w + (tcx - 1)
                        grid[trace] = (grid[trace].toInt() and WALL_LEFT.toInt().inv()).toByte()
                        grid[nextCell] = (grid[nextCell].toInt() and WALL_RIGHT.toInt().inv()).toByte()
                    }
                }
                trace = nextCell
            }
        }
        return grid
    }

    // =========================================================================
    // 4. CẤP ĐỘ SIÊU KHỔNG LỒ (>80x80): THUẬT TOÁN ELLER (ROW-BY-ROW O(N))
    // =========================================================================
    fun generateEller(w: Int, h: Int, random: Random): ByteArray {
        val totalCells = w * h
        val grid = ByteArray(totalCells) { WALLS_ALL }
        val rowSets = IntArray(w)
        var nextSetId = 1

        for (y in 0 until h) {
            // 1. Gán set ID cho các ô chưa có set
            for (x in 0 until w) {
                if (rowSets[x] == 0) {
                    rowSets[x] = nextSetId++
                }
            }

            val isLastRow = (y == h - 1)

            // 2. Nối ngang các ô liền kề nếu khác set
            for (x in 0 until w - 1) {
                val currentSet = rowSets[x]
                val nextSet = rowSets[x + 1]

                if (currentSet != nextSet) {
                    val shouldMerge = isLastRow || random.nextBoolean()
                    if (shouldMerge) {
                        val currIdx = y * w + x
                        val nextIdx = y * w + (x + 1)
                        grid[currIdx] = (grid[currIdx].toInt() and WALL_RIGHT.toInt().inv()).toByte()
                        grid[nextIdx] = (grid[nextIdx].toInt() and WALL_LEFT.toInt().inv()).toByte()

                        for (k in 0 until w) {
                            if (rowSets[k] == nextSet) {
                                rowSets[k] = currentSet
                            }
                        }
                    }
                }
            }

            if (!isLastRow) {
                // 3. Nối dọc xuống hàng tiếp theo (Đảm bảo mỗi set có ít nhất 1 kết nối dọc)
                val setElements = mutableMapOf<Int, MutableList<Int>>()
                for (x in 0 until w) {
                    setElements.getOrPut(rowSets[x]) { mutableListOf() }.add(x)
                }

                val nextRowSets = IntArray(w)
                for ((_, indices) in setElements) {
                    var carvedCount = 0
                    for (x in indices) {
                        if (random.nextBoolean() || carvedCount == 0) {
                            val currIdx = y * w + x
                            val nextIdx = (y + 1) * w + x
                            grid[currIdx] = (grid[currIdx].toInt() and WALL_TOP.toInt().inv()).toByte()
                            grid[nextIdx] = (grid[nextIdx].toInt() and WALL_BOTTOM.toInt().inv()).toByte()
                            nextRowSets[x] = rowSets[x]
                            carvedCount++
                        }
                    }
                }

                for (x in 0 until w) {
                    rowSets[x] = nextRowSets[x]
                }
            }
        }
        return grid
    }

    // =========================================================================
    // GRAPH ENDPOINTS DETERMINATION (HARDEST START & END POSITIONS)
    // =========================================================================

    /**
     * Xác định vị trí Start và End khó nhất dựa trên đặc thù hình học của từng thuật toán:
     * 1. Backtracking (Small: <= 20x20): Start ở Trung tâm (Center), End ở một góc xa nhất (Corner).
     * 2. Kruskal (Medium: 21x21 đến 50x50): Start ở giữa cạnh Trái, End ở giữa cạnh Phải (cắt ngang thớ fractal).
     * 3. Wilson & Large (> 50x50): Tìm 2 ô sát cạnh nhau (cách 1 vách ngăn) có khoảng cách đường đi trong mê cung dài nhất,
     *    hoặc Double BFS Diameter để tìm 2 điểm xa nhất tuyệt đối.
     */
    private fun determineOptimalEndpoints(masks: IntArray, w: Int, h: Int, maxDim: Int, random: Random): Pair<Int, Int> {
        val totalCells = w * h

        return when {
            // 1. Thuật toán Quay lui (5x5 đến 20x20): Start ở Trung tâm, End ở Góc xa nhất
            maxDim <= 20 -> {
                val startIdx = (h / 2) * w + (w / 2)
                val dist = bfsDistances(masks, w, h, startIdx)

                // 4 góc của mê cung
                val corners = intArrayOf(
                    0,                      // Top-Left (y=0, x=0)
                    w - 1,                  // Top-Right (y=0, x=w-1)
                    (h - 1) * w,            // Bottom-Left (y=h-1, x=0)
                    (h - 1) * w + (w - 1)   // Bottom-Right (y=h-1, x=w-1)
                )

                // Tìm góc có khoảng cách đường đi từ Trung tâm lớn nhất
                var bestGoal = corners[0]
                var maxCornerDist = dist[corners[0]]
                for (c in corners) {
                    if (dist[c] > maxCornerDist) {
                        maxCornerDist = dist[c]
                        bestGoal = c
                    }
                }

                if (maxCornerDist <= 0) {
                    var maxD = -1
                    var maxIdx = 0
                    for (i in 0 until totalCells) {
                        if (dist[i] > maxD) {
                            maxD = dist[i]
                            maxIdx = i
                        }
                    }
                    bestGoal = maxIdx
                }
                Pair(startIdx, bestGoal)
            }

            // 2. Thuật toán Kruskal (21x21 đến 50x50): Giữa cạnh Trái -> Giữa cạnh Phải đối diện
            maxDim <= 50 -> {
                val startIdx = (h / 2) * w + 0 // Giữa cạnh Trái (x=0, y=h/2)
                val dist = bfsDistances(masks, w, h, startIdx)

                // Dò các ô nằm trên cạnh Phải (x = w - 1) tìm ô có đường đi xa nhất
                var bestGoal = (h / 2) * w + (w - 1)
                var maxRightDist = dist[bestGoal]
                for (y in 0 until h) {
                    val rightCell = y * w + (w - 1)
                    if (dist[rightCell] > maxRightDist) {
                        maxRightDist = dist[rightCell]
                        bestGoal = rightCell
                    }
                }
                Pair(startIdx, bestGoal)
            }

            // 3. Thuật toán Wilson & Cấp độ Lớn (>50x50): Hai ô sát cạnh nhau (cách 1 vách ngăn) có path length cực lớn
            else -> {
                val (diaStart, diaGoal) = findGraphDiameter(masks, w, h)
                val spine = findShortestPath(masks, w, h, diaStart, diaGoal)
                val diameterDist = spine.size - 1

                val startDist = bfsDistances(masks, w, h, diaStart)

                var bestAdjacentPair: Pair<Int, Int>? = null
                var maxAdjPathDist = 0

                // Quét qua các cạnh có tường ngăn kiên cố
                for (y in 0 until h) {
                    for (x in 0 until w) {
                        val curr = y * w + x
                        val m = masks[curr]

                        // Kiểm tra tường Phải (EAST)
                        if (x < w - 1 && (m and EAST) == 0) {
                            val right = y * w + (x + 1)
                            val pathD = kotlin.math.abs(startDist[curr] - startDist[right])
                            if (pathD > maxAdjPathDist && pathD >= (diameterDist * 0.4).toInt()) {
                                maxAdjPathDist = pathD
                                bestAdjacentPair = Pair(curr, right)
                            }
                        }

                        // Kiểm tra tường Trên (NORTH)
                        if (y < h - 1 && (m and NORTH) == 0) {
                            val top = (y + 1) * w + x
                            val pathD = kotlin.math.abs(startDist[curr] - startDist[top])
                            if (pathD > maxAdjPathDist && pathD >= (diameterDist * 0.4).toInt()) {
                                maxAdjPathDist = pathD
                                bestAdjacentPair = Pair(curr, top)
                            }
                        }
                    }
                }

                if (bestAdjacentPair != null && maxAdjPathDist > 15) {
                    bestAdjacentPair
                } else {
                    // Fallback to Double BFS Diameter
                    Pair(diaStart, diaGoal)
                }
            }
        }
    }

    private fun bfsDistances(masks: IntArray, w: Int, h: Int, startIdx: Int): IntArray {
        val totalCells = w * h
        val dist = IntArray(totalCells) { -1 }
        val queue = IntArray(totalCells)
        var head = 0
        var tail = 0

        dist[startIdx] = 0
        queue[tail++] = startIdx

        while (head < tail) {
            val curr = queue[head++]
            val d = dist[curr]
            val cx = curr % w
            val cy = curr / w
            val m = masks[curr]

            if (cy < h - 1 && (m and NORTH) != 0) {
                val nIdx = (cy + 1) * w + cx
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
            if (cx < w - 1 && (m and EAST) != 0) {
                val nIdx = cy * w + (cx + 1)
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
            if (cy > 0 && (m and SOUTH) != 0) {
                val nIdx = (cy - 1) * w + cx
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
            if (cx > 0 && (m and WEST) != 0) {
                val nIdx = cy * w + (cx - 1)
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
        }
        return dist
    }

    // =========================================================================
    // GRAPH DIAMETER & SHORTEST PATH SOLVER
    // =========================================================================
    private fun findGraphDiameter(masks: IntArray, w: Int, h: Int): Pair<Int, Int> {
        val totalCells = w * h
        val queue = IntArray(totalCells)
        val dist = IntArray(totalCells)

        dist.fill(-1)
        var head = 0
        var tail = 0
        queue[tail++] = 0
        dist[0] = 0

        var nodeA = 0
        var maxDistA = 0

        while (head < tail) {
            val curr = queue[head++]
            val d = dist[curr]
            if (d > maxDistA) {
                maxDistA = d
                nodeA = curr
            }
            val cx = curr % w
            val cy = curr / w
            val m = masks[curr]

            if (cy < h - 1 && (m and NORTH) != 0) {
                val nIdx = (cy + 1) * w + cx
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
            if (cx < w - 1 && (m and EAST) != 0) {
                val nIdx = cy * w + (cx + 1)
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
            if (cy > 0 && (m and SOUTH) != 0) {
                val nIdx = (cy - 1) * w + cx
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
            if (cx > 0 && (m and WEST) != 0) {
                val nIdx = cy * w + (cx - 1)
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
        }

        dist.fill(-1)
        head = 0
        tail = 0
        queue[tail++] = nodeA
        dist[nodeA] = 0

        var nodeB = nodeA
        var maxDistB = 0

        while (head < tail) {
            val curr = queue[head++]
            val d = dist[curr]
            if (d > maxDistB) {
                maxDistB = d
                nodeB = curr
            }
            val cx = curr % w
            val cy = curr / w
            val m = masks[curr]

            if (cy < h - 1 && (m and NORTH) != 0) {
                val nIdx = (cy + 1) * w + cx
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
            if (cx < w - 1 && (m and EAST) != 0) {
                val nIdx = cy * w + (cx + 1)
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
            if (cy > 0 && (m and SOUTH) != 0) {
                val nIdx = (cy - 1) * w + cx
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
            if (cx > 0 && (m and WEST) != 0) {
                val nIdx = cy * w + (cx - 1)
                if (dist[nIdx] == -1) { dist[nIdx] = d + 1; queue[tail++] = nIdx }
            }
        }

        return Pair(nodeA, nodeB)
    }

    private fun findShortestPath(masks: IntArray, w: Int, h: Int, startIdx: Int, goalIdx: Int): List<Point> {
        val totalCells = w * h
        val prev = IntArray(totalCells) { -1 }
        val visited = BooleanArray(totalCells)
        val queue = ArrayDeque<Int>()

        queue.add(startIdx)
        visited[startIdx] = true

        while (queue.isNotEmpty()) {
            val curr = queue.poll() ?: break
            if (curr == goalIdx) break

            val cx = curr % w
            val cy = curr / w
            val m = masks[curr]

            if (cy < h - 1 && (m and NORTH) != 0) {
                val nIdx = (cy + 1) * w + cx
                if (!visited[nIdx]) { visited[nIdx] = true; prev[nIdx] = curr; queue.add(nIdx) }
            }
            if (cx < w - 1 && (m and EAST) != 0) {
                val nIdx = cy * w + (cx + 1)
                if (!visited[nIdx]) { visited[nIdx] = true; prev[nIdx] = curr; queue.add(nIdx) }
            }
            if (cy > 0 && (m and SOUTH) != 0) {
                val nIdx = (cy - 1) * w + cx
                if (!visited[nIdx]) { visited[nIdx] = true; prev[nIdx] = curr; queue.add(nIdx) }
            }
            if (cx > 0 && (m and WEST) != 0) {
                val nIdx = cy * w + (cx - 1)
                if (!visited[nIdx]) { visited[nIdx] = true; prev[nIdx] = curr; queue.add(nIdx) }
            }
        }

        val path = mutableListOf<Point>()
        var curr = goalIdx
        while (curr != -1) {
            path.add(Point(curr % w, curr / w))
            if (curr == startIdx) break
            curr = prev[curr]
        }
        return path.reversed()
    }
}

object MazeSolver {
    fun computeDistances(maze: Maze): IntArray {
        val n = maze.w * maze.h
        val dist = IntArray(n) { -1 }
        val startIdx = maze.start.y * maze.w + maze.start.x
        dist[startIdx] = 0

        val queue = ArrayDeque<Int>()
        queue.add(startIdx)

        val dirs = listOf(
            Triple(0, 1, NORTH),
            Triple(1, 0, EAST),
            Triple(0, -1, SOUTH),
            Triple(-1, 0, WEST)
        )

        while (queue.isNotEmpty()) {
            val curr = queue.poll() ?: break
            val cx = curr % maze.w
            val cy = curr / maze.w
            val m = maze.masks[curr]

            for ((dx, dy, dir) in dirs) {
                if ((m and dir) != 0) {
                    val nx = cx + dx
                    val ny = cy + dy
                    val ni = ny * maze.w + nx
                    if (ni in 0 until n && dist[ni] == -1) {
                        dist[ni] = dist[curr] + 1
                        queue.add(ni)
                    }
                }
            }
        }
        return dist
    }

    fun findPathToGoal(maze: Maze): List<Point> {
        return maze.spine
    }
}
