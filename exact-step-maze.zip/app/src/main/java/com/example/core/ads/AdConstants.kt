package com.example.core.ads

import java.util.Calendar

/**
 * Hằng số cấu hình hệ thống Quảng Cáo & Gói VIP
 * 
 * Người dùng có thể điền các ID AdMob hoặc Google Play Product ID vào đây.
 * Mặc định để trống để người dùng điền sau như yêu cầu.
 */
object AdConstants {
    // =========================================================================
    // GOOGLE ADMOB TEST AD UNITS (Được chỉ định cụ thể cho môi trường thử nghiệm)
    // =========================================================================
    // App ID test chính thức của Google AdMob:
    const val ADMOB_APP_ID: String = "ca-app-pub-3940256099942544~3347511713"

    // 1. Biểu ngữ trong game (Fixed Size Banner 320x50):
    const val ADMOB_BANNER_ID: String = "ca-app-pub-3940256099942544/6300978111"

    // 2. Quảng cáo xen kẽ sau ván game (Interstitial Ad):
    const val ADMOB_INTERSTITIAL_ID: String = "ca-app-pub-3940256099942544/1033173712"

    // Thời gian giãn cách giữa 2 lần hiện quảng cáo xen kẽ sau ván: 2 phút 30 giây (150 giây)
    const val INTERSTITIAL_COOLDOWN_SECONDS: Long = 150L
    const val INTERSTITIAL_COOLDOWN_MILLIS: Long = 150L * 1000L // 2 phút 30 giây (150,000 ms)

    // 3. Quảng cáo có tặng thưởng (Rewarded Ad):
    const val ADMOB_REWARDED_ID: String = "ca-app-pub-3940256099942544/5224354917"

    // Danh sách thiết bị thử nghiệm (Android Emulator + thiết bị vật lý nếu có)
    val TEST_DEVICE_IDS: List<String> = listOf(
        com.google.android.gms.ads.AdRequest.DEVICE_ID_EMULATOR,
        "33BE2250B43518CCDA7DE426D04EE231" // Mã thiết bị thử nghiệm mẫu từ logcat
    )

    val isAdMobConfigured: Boolean
        get() = ADMOB_APP_ID.isNotBlank() || ADMOB_BANNER_ID.isNotBlank() || ADMOB_INTERSTITIAL_ID.isNotBlank() || ADMOB_REWARDED_ID.isNotBlank()

    val isBannerConfigured: Boolean
        get() = ADMOB_BANNER_ID.isNotBlank()

    val isInterstitialConfigured: Boolean
        get() = ADMOB_INTERSTITIAL_ID.isNotBlank()

    val isRewardedConfigured: Boolean
        get() = ADMOB_REWARDED_ID.isNotBlank()

    // =========================================================================
    // GOOGLE PLAY IN-APP BILLING (IAP) PRODUCT IDS
    // Để trống hoặc điền Product ID đã tạo trên Google Play Console tại đây:
    // =========================================================================
    const val PRODUCT_ID_VIP_2: String = "" // Giá ngày thường $1.25 (ví dụ: "vip_pass_tier_2_15days")
    const val PRODUCT_ID_VIP_2_DISCOUNT: String = "" // Giá khuyến mãi $0.699 (ví dụ: "vip_pass_tier_2_sale")
    const val PRODUCT_ID_VIP_3: String = "" // Giá ngày thường $4.00 (ví dụ: "vip_pass_tier_3_permanent")
    const val PRODUCT_ID_VIP_3_DISCOUNT: String = "" // Giá khuyến mãi $2.599 (ví dụ: "vip_pass_tier_3_sale")

    // =========================================================================
    // CHÍNH SÁCH GIÁ & QUYỀN LỢI CÁC GÓI VIP
    // =========================================================================

    // VIP 1:
    // 3 ngày không quảng cáo banner hoặc sau game (người chơi tùy chọn bật/tắt)
    // Giá: 2,000 Vàng HOẶC tích lũy 30 lượt xem quảng cáo thưởng
    const val VIP1_COINS_PRICE: Int = 2000
    const val VIP1_REQUIRED_AD_VIEWS: Int = 30
    const val VIP1_DURATION_DAYS: Int = 3
    const val VIP1_DURATION_MILLIS: Long = 3L * 24 * 60 * 60 * 1000L

    // VIP 2:
    // 15 ngày không có quảng cáo (trừ quảng cáo thưởng)
    // Tặng kèm: +5 gợi ý, +2 bỏ qua ván
    // Giá ngày thường: 1.25 USD
    // Giảm giá Flash Sale: 0.699 USD (vào T2, T4, T6, CN từ 9h - 12h)
    const val VIP2_REGULAR_PRICE_USD: Double = 1.25
    const val VIP2_DISCOUNT_PRICE_USD: Double = 0.699
    const val VIP2_DURATION_DAYS: Int = 15
    const val VIP2_DURATION_MILLIS: Long = 15L * 24 * 60 * 60 * 1000L
    const val VIP2_BONUS_HINTS: Int = 5
    const val VIP2_BONUS_SKIPS: Int = 2

    // VIP 3:
    // Tắt mọi loại quảng cáo tự hiện vĩnh viễn (trừ quảng cáo thưởng tự chọn)
    // Tặng kèm: +15 gợi ý, +5 bỏ qua ván
    // Giá ngày thường: 4.00 USD
    // Giảm giá Flash Sale: 2.599 USD (vào T2, T4, T6, CN từ 9h - 12h)
    const val VIP3_REGULAR_PRICE_USD: Double = 4.00
    const val VIP3_DISCOUNT_PRICE_USD: Double = 2.599
    const val VIP3_BONUS_HINTS: Int = 15
    const val VIP3_BONUS_SKIPS: Int = 5

    /**
     * Kiểm tra khung giờ giảm giá Flash Sale:
     * - Các ngày: Thứ 2 (MONDAY), Thứ 4 (WEDNESDAY), Thứ 6 (FRIDAY), Chủ Nhật (SUNDAY).
     * - Khung giờ: 3 tiếng từ 9:00 sáng đến 12:00 trưa (9 <= hour < 12).
     */
    fun isFlashSaleActive(calendar: Calendar = Calendar.getInstance()): Boolean {
        val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
        val isDiscountDay = dayOfWeek == Calendar.MONDAY ||
                dayOfWeek == Calendar.WEDNESDAY ||
                dayOfWeek == Calendar.FRIDAY ||
                dayOfWeek == Calendar.SUNDAY

        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val isDiscountHour = hour in 9..11 // từ 9:00:00 đến 11:59:59

        return isDiscountDay && isDiscountHour
    }

    /**
     * Thời gian còn lại của đợt Flash Sale hiện tại (mili-giây),
     * trả về 0 nếu hiện tại không phải giờ Flash Sale.
     */
    fun getFlashSaleRemainingMillis(calendar: Calendar = Calendar.getInstance()): Long {
        if (!isFlashSaleActive(calendar)) return 0L
        val endCal = calendar.clone() as Calendar
        endCal.set(Calendar.HOUR_OF_DAY, 12)
        endCal.set(Calendar.MINUTE, 0)
        endCal.set(Calendar.SECOND, 0)
        endCal.set(Calendar.MILLISECOND, 0)
        return maxOf(0L, endCal.timeInMillis - calendar.timeInMillis)
    }

    /**
     * Lấy giá hiển thị cho VIP 2 theo thời gian thực
     */
    fun getVip2DisplayPrice(isFlashSale: Boolean = isFlashSaleActive()): String {
        return if (isFlashSale) "$0.699" else "$1.25"
    }

    /**
     * Lấy giá hiển thị cho VIP 3 theo thời gian thực
     */
    fun getVip3DisplayPrice(isFlashSale: Boolean = isFlashSaleActive()): String {
        return if (isFlashSale) "$2.599" else "$4.00"
    }
}
