package com.example.core.engine

import com.example.ui.components.OneLineGameView.Point
import java.util.Random

/**
 * OneLineGenerator - Thuật toán sinh màn chơi One-Line dựa trên Hamiltonian Path & Randomized DFS với Bipartite Graph constraints.
 *
 * Tính chất Toán học:
 * - Đồ thị nhị phân (Bipartite Graph): Ô (r, c) có màu S = (r + c) mod 2 (0: Trắng, 1: Đen).
 * - Bước đi hợp lệ luôn chuyển đổi Trắng <-> Đen.
 * - Đảm bảo 100% có nghiệm và đáp án được lưu trong solutionPath (dùng cho tính năng Hướng Dẫn / Gợi Ý - Hint).
 */
data class OneLineMapResult(
    val rows: Int,
    val cols: Int,
    val grid: Array<IntArray>,
    val startPoint: Point,
    val endPoint: Point,
    val solutionPath: List<Point>,
    val totalTargetCells: Int
)

object OneLineGenerator {

    /**
     * Sinh màn chơi hình chữ nhật/vuông chuẩn bằng Randomized DFS với fillRate cao (độ khó max).
     */
    fun generateGridMap(
        rows: Int,
        cols: Int,
        seed: Long = System.currentTimeMillis(),
        fillRate: Float = 0.85f // Độ khó cao: lấp kín 80-95% số ô
    ): OneLineMapResult {
        val rand = Random(seed)
        val grid = Array(rows) { IntArray(cols) { 2 } } // 2 = CELL_OBSTACLE, 0 = CELL_EMPTY

        val totalCells = rows * cols
        val targetPathLength = (totalCells * fillRate).toInt().coerceIn(minOf(totalCells, 4), totalCells)

        val startR = rand.nextInt(rows)
        val startC = rand.nextInt(cols)
        val startPt = Point(startC, startR)

        grid[startR][startC] = 0
        val finalPath = mutableListOf(startPt)

        val success = dfsGenerate(grid, rows, cols, startPt, targetPathLength, finalPath, rand)
        if (!success && finalPath.size < minOf(totalCells, 4)) {
            // Fallback serpentine path nếu DFS bị kẹt
            finalPath.clear()
            for (r in 0 until rows) {
                val cRange = if (r % 2 == 0) 0 until cols else cols - 1 downTo 0
                for (c in cRange) {
                    grid[r][c] = 0
                    finalPath.add(Point(c, r))
                }
            }
        }

        val endPt = finalPath.last()
        var targetCount = 0
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (grid[r][c] == 0) targetCount++
            }
        }

        return OneLineMapResult(
            rows = rows,
            cols = cols,
            grid = grid,
            startPoint = startPt,
            endPoint = endPt,
            solutionPath = finalPath.toList(),
            totalTargetCells = targetCount
        )
    }

    /**
     * Sinh màn chơi theo khuôn hình đặc biệt (Shape Mask) và dùng DFS để tìm Hamiltonian Path phủ kín tất cả ô trong hình.
     */
    fun generateShapedMap(
        rows: Int,
        cols: Int,
        maskPattern: Array<String>,
        seed: Long = System.currentTimeMillis()
    ): OneLineMapResult {
        val rand = Random(seed)
        val shapeValid = Array(rows) { r ->
            BooleanArray(cols) { c ->
                if (r < maskPattern.size && c < maskPattern[r].length) {
                    maskPattern[r][c] == '*'
                } else false
            }
        }

        val validPoints = mutableListOf<Point>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (shapeValid[r][c]) {
                    validPoints.add(Point(c, r))
                }
            }
        }

        // Bắt đầu từ 1 điểm hợp lệ ngẫu nhiên trong hình
        val startPt = if (validPoints.isNotEmpty()) validPoints[rand.nextInt(validPoints.size)] else Point(0, 0)
        val grid = Array(rows) { IntArray(cols) { 2 } } // 2 = Obstacle
        grid[startPt.row][startPt.col] = 0
        val finalPath = mutableListOf(startPt)

        val targetPathLength = validPoints.size
        val success = dfsGenerateMask(grid, rows, cols, shapeValid, startPt, targetPathLength, finalPath, rand, 0)

        // Nếu hình không giải được 100% bằng 1 nét hoàn chỉnh từ điểm ngẫu nhiên, duyệt qua các điểm khởi đầu khác
        if (!success && validPoints.isNotEmpty()) {
            for (pt in validPoints.shuffled(rand)) {
                for (r in 0 until rows) {
                    for (c in 0 until cols) {
                        grid[r][c] = 2
                    }
                }
                grid[pt.row][pt.col] = 0
                finalPath.clear()
                finalPath.add(pt)
                if (dfsGenerateMask(grid, rows, cols, shapeValid, pt, targetPathLength, finalPath, rand, 0)) {
                    break
                }
            }
        }

        // Nếu vẫn còn ô trong shape mà DFS không đi hết được, biến các ô đó thành obstacle để đảm bảo map 100% có nghiệm
        val actualPath = finalPath.toList()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                grid[r][c] = 2
            }
        }
        for (p in actualPath) {
            grid[p.row][p.col] = 0
        }

        return OneLineMapResult(
            rows = rows,
            cols = cols,
            grid = grid,
            startPoint = actualPath.firstOrNull() ?: Point(0, 0),
            endPoint = actualPath.lastOrNull() ?: Point(0, 0),
            solutionPath = actualPath,
            totalTargetCells = actualPath.size
        )
    }

    private fun dfsGenerate(
        grid: Array<IntArray>,
        rows: Int,
        cols: Int,
        current: Point,
        targetLength: Int,
        path: MutableList<Point>,
        rand: Random
    ): Boolean {
        if (path.size >= targetLength) return true

        val neighbors = getValidNeighbors(grid, rows, cols, current)
        neighbors.shuffle(rand)

        for (next in neighbors) {
            grid[next.row][next.col] = 0
            path.add(next)

            if (dfsGenerate(grid, rows, cols, next, targetLength, path, rand)) {
                return true
            }

            // Backtrack
            grid[next.row][next.col] = 2
            path.removeAt(path.size - 1)
        }
        return false
    }

    private fun dfsGenerateMask(
        grid: Array<IntArray>,
        rows: Int,
        cols: Int,
        mask: Array<BooleanArray>,
        current: Point,
        targetLength: Int,
        path: MutableList<Point>,
        rand: Random,
        depth: Int
    ): Boolean {
        if (path.size >= targetLength) return true
        if (depth > 5000) return false // Tránh đệ quy quá sâu

        val neighbors = getValidMaskNeighbors(grid, rows, cols, mask, current)
        neighbors.shuffle(rand)

        for (next in neighbors) {
            grid[next.row][next.col] = 0
            path.add(next)

            if (dfsGenerateMask(grid, rows, cols, mask, next, targetLength, path, rand, depth + 1)) {
                return true
            }

            // Backtrack
            grid[next.row][next.col] = 2
            path.removeAt(path.size - 1)
        }
        return false
    }

    private fun getValidNeighbors(
        grid: Array<IntArray>,
        rows: Int,
        cols: Int,
        p: Point
    ): MutableList<Point> {
        val list = mutableListOf<Point>()
        val dirs = arrayOf(Point(0, 1), Point(0, -1), Point(1, 0), Point(-1, 0))
        for (d in dirs) {
            val nc = p.col + d.col
            val nr = p.row + d.row
            if (nc in 0 until cols && nr in 0 until rows && grid[nr][nc] == 2) {
                list.add(Point(nc, nr))
            }
        }
        return list
    }

    private fun getValidMaskNeighbors(
        grid: Array<IntArray>,
        rows: Int,
        cols: Int,
        mask: Array<BooleanArray>,
        p: Point
    ): MutableList<Point> {
        val list = mutableListOf<Point>()
        val dirs = arrayOf(Point(0, 1), Point(0, -1), Point(1, 0), Point(-1, 0))
        for (d in dirs) {
            val nc = p.col + d.col
            val nr = p.row + d.row
            if (nc in 0 until cols && nr in 0 until rows && mask[nr][nc] && grid[nr][nc] == 2) {
                list.add(Point(nc, nr))
            }
        }
        return list
    }
}
