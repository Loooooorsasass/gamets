package com.example.core.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * Trình quản lý Quảng Cáo AdMob (Interstitial & Rewarded & Banner)
 * Tích hợp chuẩn Google Mobile Ads SDK với các đơn vị quảng cáo Test chính thức.
 */
class AdManager(private val context: Context) {

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var isAdMobInitialized = false

    // Thời điểm lần cuối cùng hiển thị quảng cáo xen kẽ sau ván (mili-giây)
    @Volatile
    private var lastInterstitialShowTimeMillis: Long = 0L

    companion object {
        private const val TAG = "AdManager"
        @Volatile
        private var instance: AdManager? = null

        fun getInstance(context: Context): AdManager {
            return instance ?: synchronized(this) {
                instance ?: AdManager(context.applicationContext).also { instance = it }
            }
        }
    }

    init {
        try {
            // Cấu hình thiết bị thử nghiệm (Test Devices) theo đúng tài liệu AdMob
            val requestConfiguration = RequestConfiguration.Builder()
                .setTestDeviceIds(AdConstants.TEST_DEVICE_IDS)
                .build()
            MobileAds.setRequestConfiguration(requestConfiguration)

            MobileAds.initialize(context) { status ->
                isAdMobInitialized = true
                Log.d(TAG, "AdMob Initialized thành công: $status")
                loadInterstitialAd()
                loadRewardedAd()
            }
        } catch (e: Exception) {
            Log.w(TAG, "AdMob initialization warning: ${e.message}")
        }
    }

    fun isInterstitialReady(): Boolean = interstitialAd != null

    fun isRewardedReady(): Boolean = rewardedAd != null

    /**
     * Tải trước quảng cáo xen kẽ (Interstitial Ad)
     */
    fun loadInterstitialAd() {
        if (!AdConstants.isInterstitialConfigured) {
            interstitialAd = null
            return
        }

        val adUnitId = AdConstants.ADMOB_INTERSTITIAL_ID.trim()
        try {
            val adRequest = AdRequest.Builder().build()
            InterstitialAd.load(
                context,
                adUnitId,
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        interstitialAd = ad
                        Log.d(TAG, "Interstitial Ad đã tải thành công")
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        interstitialAd = null
                        Log.w(TAG, "Lỗi tải Interstitial Ad: ${loadAdError.message}")
                    }
                }
            )
        } catch (e: Exception) {
            Log.w(TAG, "Exception nạp Interstitial Ad: ${e.message}")
            interstitialAd = null
        }
    }

    /**
     * Kiểm tra xem thời gian giãn cách (Cooldown 2 phút 30 giây = 150s) đã trôi qua chưa.
     * Trả về true nếu ĐÃ HẾT COOLDOWN (đủ điều kiện hiện quảng cáo mới).
     * Trả về false nếu VẪN ĐANG TRONG COOLDOWN (thắng game sẽ KHÔNG hiện quảng cáo).
     */
    fun canShowInterstitialWithCooldown(): Boolean {
        val now = System.currentTimeMillis()
        val elapsed = now - lastInterstitialShowTimeMillis
        return elapsed >= AdConstants.INTERSTITIAL_COOLDOWN_MILLIS
    }

    /**
     * Thời gian còn lại của Cooldown (giây), trả về 0 nếu đã hết cooldown
     */
    fun getInterstitialRemainingCooldownSeconds(): Long {
        val now = System.currentTimeMillis()
        val elapsed = now - lastInterstitialShowTimeMillis
        val diff = AdConstants.INTERSTITIAL_COOLDOWN_MILLIS - elapsed
        return if (diff > 0) diff / 1000L else 0L
    }

    /**
     * Hiển thị quảng cáo xen kẽ Interstitial (khi thắng màn chơi).
     * Có áp dụng kiểm tra nghiêm ngặt: nếu trong vòng 2 phút 30 giây kể từ lần hiện trước
     * thì bỏ qua, không hiển thị quảng cáo để không làm phiền người chơi.
     * 
     * @param activity Activity đang hiển thị
     * @param onDismissed Callback khi quảng cáo đóng lại hoặc được bỏ qua
     */
    fun showInterstitialAd(activity: Activity, onDismissed: () -> Unit) {
        // Kiểm tra điều kiện cooldown 2 phút 30 giây
        if (!canShowInterstitialWithCooldown()) {
            val remainingSec = getInterstitialRemainingCooldownSeconds()
            Log.d(TAG, "Bỏ qua quảng cáo sau game: Đang trong cooldown (còn ${remainingSec}s mới đến lần tiếp theo)")
            onDismissed()
            return
        }

        val currentAd = interstitialAd
        if (currentAd != null) {
            try {
                currentAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        lastInterstitialShowTimeMillis = System.currentTimeMillis()
                        interstitialAd = null
                        loadInterstitialAd()
                        onDismissed()
                    }

                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        Log.w(TAG, "Lỗi hiển thị Interstitial Ad: ${adError.message}")
                        interstitialAd = null
                        loadInterstitialAd()
                        onDismissed()
                    }
                }
                currentAd.show(activity)
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi khi show Interstitial Ad: ${e.message}")
                interstitialAd = null
                onDismissed()
            }
        } else {
            // Nếu chưa có quảng cáo thật hoặc ID trống, tiếp tục mượt mà không chặn game
            loadInterstitialAd()
            onDismissed()
        }
    }

    /**
     * Tải trước quảng cáo nhận thưởng (Rewarded Ad)
     */
    fun loadRewardedAd() {
        if (!AdConstants.isRewardedConfigured) {
            rewardedAd = null
            return
        }

        val adUnitId = AdConstants.ADMOB_REWARDED_ID.trim()
        try {
            val adRequest = AdRequest.Builder().build()
            RewardedAd.load(
                context,
                adUnitId,
                adRequest,
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        rewardedAd = ad
                        Log.d(TAG, "Rewarded Ad đã tải thành công")
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        rewardedAd = null
                        Log.w(TAG, "Lỗi tải Rewarded Ad: ${loadAdError.message}")
                    }
                }
            )
        } catch (e: Exception) {
            Log.w(TAG, "Exception nạp Rewarded Ad: ${e.message}")
            rewardedAd = null
        }
    }

    /**
     * Hiển thị quảng cáo nhận thưởng Rewarded Ad
     * @param activity Activity hiển thị
     * @param onRewardEarned Gọi khi người chơi xem xong và nhận thưởng
     * @param onDismissed Gọi khi đóng quảng cáo
     * @return true nếu hiển thị được AdMob thật, false nếu cần fallback sang dialog mô phỏng trong app
     */
    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onDismissed: () -> Unit
    ): Boolean {
        val currentAd = rewardedAd
        if (currentAd != null) {
            try {
                var earned = false
                currentAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        rewardedAd = null
                        loadRewardedAd()
                        if (earned) {
                            onRewardEarned()
                        }
                        onDismissed()
                    }

                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        Log.w(TAG, "Lỗi hiển thị Rewarded Ad: ${adError.message}")
                        rewardedAd = null
                        loadRewardedAd()
                        onDismissed()
                    }
                }

                currentAd.show(activity) { _ ->
                    earned = true
                }
                return true
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi runtime khi show Rewarded Ad: ${e.message}")
                rewardedAd = null
                return false
            }
        } else {
            // Không có ad thật sẵn sàng -> Fallback sang Dialog tương tác trong app
            loadRewardedAd()
            return false
        }
    }
}
