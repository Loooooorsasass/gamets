package com.example.core.haptics

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View

/**
 * HapticManager: Quản lý phản hồi xúc giác (Haptic Feedback) cho trò chơi mê cung.
 * Tích hợp đầy đủ Android HapticFeedbackConstants để mang lại xúc giác chân thực,
 * chuẩn quy chuẩn hệ thống Android khi người chơi vuốt di chuyển (move) hoặc va chạm tường (wall hit).
 * Đồng thời có fallback mượt mà qua Vibrator / VibrationEffect.
 */
class HapticManager(private val context: Context) {
    var isHapticEnabled: Boolean = true

    @Suppress("DEPRECATION")
    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    /**
     * Tắt rung khi di chuyển (chỉ rung khi thắng theo yêu cầu)
     */
    fun performMoveFeedback(targetView: View? = null) {
        // Đã tắt rung trong game theo yêu cầu của người chơi
    }

    /**
     * Tắt rung khi va chạm tường (chỉ rung khi thắng)
     */
    fun performWallHitFeedback(targetView: View? = null) {
        // Đã tắt rung khi va chạm theo yêu cầu
    }

    /**
     * Thực hiện phản hồi xúc giác khi hoàn thành màn chơi (Level complete).
     * Rung nhịp điệu chúc mừng chiến thắng rực rỡ!
     */
    fun performWinFeedback(targetView: View? = null) {
        if (!isHapticEnabled) return

        if (targetView != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            targetView.performHapticFeedback(
                HapticFeedbackConstants.CONFIRM,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
        vibrateWin()
    }

    fun vibrateStep() {
        // Đã tắt rung bước đi
    }

    fun vibrateBump() {
        // Đã tắt rung va chạm
    }

    fun vibrateWin() {
        if (!isHapticEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val timings = longArrayOf(0, 70, 60, 110, 60, 180)
                val amplitudes = intArrayOf(0, 180, 0, 220, 0, 255)
                vibrator?.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(longArrayOf(0, 70, 60, 110, 60, 180), -1)
            }
        } catch (_: Exception) {}
    }
}
