package com.example.core.i18n

enum class AppLanguage(val code: String, val displayName: String, val flag: String) {
    VI("vi", "Tiếng Việt", "🇻🇳"),
    EN("en", "English", "🇬🇧"),
    BILINGUAL("bi", "Song Ngữ (VI/EN)", "🌐")
}

object Strings {
    private fun t(lang: AppLanguage, vi: String, en: String): String {
        return when (lang) {
            AppLanguage.VI -> vi
            AppLanguage.EN -> en
            AppLanguage.BILINGUAL -> "$vi / $en"
        }
    }

    // Top Bar & App Info
    fun appTitle(lang: AppLanguage) = t(lang, VietnameseTexts.APP_TITLE, "Maze Pro")
    fun appSubtitle(lang: AppLanguage) = t(lang, VietnameseTexts.APP_SUBTITLE, "Precision Step-Counting Maze")

    // Common navigation / buttons
    fun back(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_BACK, "Back")
    fun close(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_CLOSE, "Close")
    fun cancel(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_CANCEL, "Cancel")
    fun understood(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_UNDERSTOOD, "Got It")
    fun play(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_PLAY, "Play")
    fun playNow(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_PLAY_NOW, "Play Now")
    fun playAgain(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_PLAY_AGAIN, "Play Again")
    fun retry(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_RETRY, "Retry")
    fun pause(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_PAUSE, "Pause")
    fun undo(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_UNDO, "Undo")
    fun reset(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_RESET, "Reset")
    fun hint(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_HINT, "Hint")
    fun hideHint(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_HIDE_HINT, "Hide Hint")
    fun hintFree(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_FREE_HINT, "Free Hint")
    fun hintUsed(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_USED_HINT, "Used")
    fun hintFreeEnabled(lang: AppLanguage) = t(lang, VietnameseTexts.HINT_FREE_ON_MSG, "Free One-Line Path Hint activated!")
    fun hintOncePerLevel(lang: AppLanguage) = t(lang, VietnameseTexts.HINT_ONCE_PER_LEVEL_MSG, "Only 1 Free Hint allowed per level!")
    fun skip(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_SKIP, "Skip")
    fun watchAd(lang: AppLanguage) = t(lang, "Xem Ad", "Watch Ad")
    fun watchAdExtraTime(lang: AppLanguage) = t(lang, "📺 Xem Ad Nhận +30s Chơi Tiếp", "📺 Watch Ad for +30s Time")

    fun nextLevel(lang: AppLanguage, size: String = ""): String {
        val vi = if (size.isEmpty()) VietnameseTexts.BTN_NEXT_LEVEL else "${VietnameseTexts.BTN_NEXT_LEVEL} ($size)"
        val en = if (size.isEmpty()) "Next Level" else "Next Level ($size)"
        return t(lang, vi, en)
    }

    fun nextTier(lang: AppLanguage) = t(lang, "Tiếp Tục Tầng Tiếp Theo", "Continue to Next Tier")
    fun home(lang: AppLanguage) = t(lang, "Về Trang Chủ", "Home")
    fun backToHome(lang: AppLanguage) = t(lang, "Về Trang Chủ", "Back to Home")
    fun locked(lang: AppLanguage) = t(lang, VietnameseTexts.LEVEL_LOCKED, "Locked")
    fun free(lang: AppLanguage) = t(lang, "Miễn phí", "Free")
    fun reward(lang: AppLanguage) = t(lang, "Phần thưởng", "Reward")

    // Segmented Navigation tabs
    fun tabDaily(lang: AppLanguage) = t(lang, VietnameseTexts.NAV_DAILY, "Daily")
    fun tabLeaderboard(lang: AppLanguage) = t(lang, VietnameseTexts.NAV_LEADERBOARD, "Rankings")
    fun tabShop(lang: AppLanguage) = t(lang, VietnameseTexts.NAV_SHOP, "Shop")
    fun tabAchievements(lang: AppLanguage) = t(lang, VietnameseTexts.NAV_ACHIEVEMENTS, "Badges")

    // Home Screen - Resume Card
    fun resumeGameTitle(lang: AppLanguage) = t(lang, VietnameseTexts.RESUME_CARD_TITLE, "Resume Game")
    fun resumeGameSub(lang: AppLanguage, moves: Int, elapsedSec: Int): String {
        val vi = "Đã đi $moves bước · Thời gian: ${elapsedSec}s"
        val en = "$moves steps made · Time: ${elapsedSec}s"
        return t(lang, vi, en)
    }
    fun resumeButton(lang: AppLanguage) = t(lang, VietnameseTexts.BTN_RESUME, "Resume")

    // Home Screen - Daily Challenge Banner
    fun dailyBannerTitle(lang: AppLanguage) = t(lang, VietnameseTexts.DAILY_BANNER_TITLE, "Today's Maze Challenge")
    fun dailyBannerSub(lang: AppLanguage) = t(lang, VietnameseTexts.DAILY_BANNER_SUBTITLE, "Global 14×14 Maze · Earn +200 Coins")
    fun speedRace(lang: AppLanguage) = t(lang, VietnameseTexts.DAILY_BANNER_BTN, "Speed Run")

    // Home Screen - Impossible Progress Bar
    fun impossibleProgressTitle(lang: AppLanguage) = t(lang, VietnameseTexts.IMPOSSIBLE_PROGRESS_TITLE, "Progress to Unlock IMPOSSIBLE")
    fun levelsProgress(lang: AppLanguage, current: Int, total: Int): String {
        val vi = "$current / $total Màn"
        val en = "$current / $total Levels"
        return t(lang, vi, en)
    }

    // Home Screen - One-Line Mini Game Banner
    fun oneLineCardTitle(lang: AppLanguage) = t(lang, VietnameseTexts.ONELINE_CARD_TITLE, "Mini-Game: One-Line Puzzle")
    fun oneLineUnlockedDesc(lang: AppLanguage) = t(lang, VietnameseTexts.ONELINE_CARD_SUB_UNLOCKED, "Unlocked! 3×3 to 15×15 & Special Shapes")
    fun oneLineLockedDesc(lang: AppLanguage, current: Int, required: Int): String {
        val vi = "Cần qua Màn $required Mê Cung ($current/$required)"
        val en = "Requires Level $required Maze ($current/$required)"
        return t(lang, vi, en)
    }
    fun oneLineLockedDialogTitle(lang: AppLanguage) = t(lang, VietnameseTexts.ONELINE_LOCKED_DIALOG_TITLE, "One-Line Puzzle is Locked 🔒")
    fun oneLineLockedDialogBody(lang: AppLanguage, current: Int): String {
        val vi = String.format(VietnameseTexts.ONELINE_LOCKED_DIALOG_BODY, current)
        val en = "Please complete at least 20 levels in the main Maze game to unlock One-Line Puzzle!\n\nYour current progress: $current / 20 Levels."
        return t(lang, vi, en)
    }

    // Home Screen - Level List
    fun levelListTitle(lang: AppLanguage) = t(lang, VietnameseTexts.LEVEL_SELECT_TITLE, "Level Select")
    fun showMoreLevels(lang: AppLanguage) = t(lang, VietnameseTexts.LEVEL_SHOW_MORE, "Show more levels ▾")

    // Home Screen - Impossible Mode Section
    fun impossibleSectionTitle(lang: AppLanguage) = t(lang, VietnameseTexts.IMPOSSIBLE_SECTION_TITLE, "IMPOSSIBLE MODE")
    fun impossibleUnlockedDesc(lang: AppLanguage) = t(lang, VietnameseTexts.IMPOSSIBLE_UNLOCKED_DESC, "3 extreme tiers: 300×300 (900 steps) → 400×400 (1600 steps) → 500×500 (2500 steps). Pace < 0.5s/step to unlock next tier. Complete all 3 for SUPER 1000×1000.")
    fun impossibleLockedDesc(lang: AppLanguage) = t(lang, VietnameseTexts.IMPOSSIBLE_LOCKED_DESC, "Clear 50 regular levels to unlock extreme challenge mode with 10×10 fog of war and massive mazes.")
    fun superTierTitle(lang: AppLanguage) = t(lang, VietnameseTexts.SUPER_TIER_TITLE, "SUPER")
    fun stepsUnit(lang: AppLanguage, steps: Int): String {
        val vi = "$steps bước"
        val en = "$steps steps"
        return t(lang, vi, en)
    }

    // Settings & Bottom Home
    fun soundLabel(lang: AppLanguage) = t(lang, VietnameseTexts.SOUND_LABEL, "Sound")
    fun musicLabel(lang: AppLanguage) = t(lang, VietnameseTexts.MUSIC_LABEL, "Music")
    fun hapticLabel(lang: AppLanguage) = t(lang, VietnameseTexts.HAPTIC_LABEL, "Haptics")
    fun languageLabel(lang: AppLanguage) = t(lang, VietnameseTexts.LANGUAGE_LABEL, "Language")
    fun resetDataButton(lang: AppLanguage) = t(lang, "Đặt lại dữ liệu màn chơi", "Reset level progress")

    // Reset Progress Dialog
    fun resetDialogTitle(lang: AppLanguage) = t(lang, VietnameseTexts.RESET_DIALOG_TITLE, "⚠️ Reset Data?")
    fun resetDialogBody(lang: AppLanguage) = t(lang, VietnameseTexts.RESET_DIALOG_BODY, "This will reset all level progress, achievements, and records to 0. Coins and purchased items will be preserved.")
    fun resetCheckboxLabel(lang: AppLanguage) = t(lang, VietnameseTexts.RESET_CHECKBOX_LABEL, "I understand and wish to reset")
    fun resetConfirmButton(lang: AppLanguage) = t(lang, VietnameseTexts.RESET_CONFIRM_BTN, "Confirm Reset")
    fun resetToast(lang: AppLanguage) = t(lang, "Đã xóa toàn bộ tiến trình!", "All progress has been reset!")

    // Help Dialog (Home)
    fun helpDialogTitle(lang: AppLanguage) = t(lang, VietnameseTexts.HELP_DIALOG_TITLE, "Maze Game Instructions")
    fun helpLine1(lang: AppLanguage) = t(lang, VietnameseTexts.HELP_LINE_1, "• Control Modes:")
    fun helpLine2(lang: AppLanguage) = t(lang, VietnameseTexts.HELP_LINE_2, "  - ⚡ Auto: Swipe lightly for 1 cell. Swipe and hold to auto-glide until junctions or walls.")
    fun helpLine3(lang: AppLanguage) = t(lang, VietnameseTexts.HELP_LINE_3, "  - 👣 Step-by-Step: Each swipe precisely moves exactly 1 cell.")
    fun helpLine4(lang: AppLanguage) = t(lang, VietnameseTexts.HELP_LINE_4, "• Objective: Guide your character to the red flag / orange exit.")
    fun helpLine5(lang: AppLanguage) = t(lang, VietnameseTexts.HELP_LINE_5, "• Stars: Awarded based on your move speed (sec/step) vs target goal.")
    fun helpLine6(lang: AppLanguage) = t(lang, VietnameseTexts.HELP_LINE_6, "• Impossible Mode: Unlocks after Level 50, featuring 10×10 fog of war.")

    // Level Action Dialog (Level details popup)
    fun bestRecord(lang: AppLanguage) = t(lang, "Thành tích cao nhất:", "Personal Best:")
    fun timeLabel(lang: AppLanguage) = t(lang, "Thời gian:", "Time:")
    fun movesLabel(lang: AppLanguage) = t(lang, "Số bước đi:", "Moves taken:")
    fun targetLabel(lang: AppLanguage, target: Int): String {
        val vi = "mục tiêu: $target"
        val en = "target: $target"
        return t(lang, vi, en)
    }
    fun exactGoalLabel(lang: AppLanguage, target: Int): String {
        val vi = "Mục tiêu: đúng $target bước"
        val en = "Goal: exactly $target steps"
        return t(lang, vi, en)
    }
    fun replayRouteBtn(lang: AppLanguage) = t(lang, "🎬 Xem Lại Lộ Trình (Replay)", "🎬 Watch Replay")

    // In-Game Screen HUD & Elements
    fun preparingLevel(lang: AppLanguage) = t(lang, "Đang chuẩn bị màn chơi...", "Preparing level...")
    fun reachFlagHint(lang: AppLanguage) = t(lang, "🚩 Chạm Lá Cờ Đỏ để Về Đích", "🚩 Reach the Red Flag to Win")
    fun steps(lang: AppLanguage) = t(lang, VietnameseTexts.HUD_STEPS, "Steps")
    fun time(lang: AppLanguage) = t(lang, VietnameseTexts.HUD_TIME, "Time")
    fun coordinates(lang: AppLanguage) = t(lang, VietnameseTexts.HUD_COORDINATES, "Coordinates")
    fun controls(lang: AppLanguage) = t(lang, VietnameseTexts.CONTROLS_LABEL, "Controls:")
    fun controlAuto(lang: AppLanguage) = t(lang, VietnameseTexts.CONTROL_AUTO, "⚡ Auto")
    fun controlAutoSub(lang: AppLanguage) = t(lang, VietnameseTexts.CONTROL_AUTO_SUB, "Drag / Hold to Glide")
    fun controlStep(lang: AppLanguage) = t(lang, VietnameseTexts.CONTROL_STEP, "👣 Step-by-Step")
    fun controlStepSub(lang: AppLanguage) = t(lang, VietnameseTexts.CONTROL_STEP_SUB, "1 exact cell")

    // Exit Game Dialog
    fun exitTitle(lang: AppLanguage) = t(lang, VietnameseTexts.EXIT_DIALOG_TITLE, "Exit current game?")
    fun exitMessage(lang: AppLanguage, moves: Int, seconds: Int): String {
        val vi = VietnameseTexts.EXIT_DIALOG_BODY
        val en = "Made $moves moves in ${seconds}s. You can save to continue later."
        return t(lang, vi, en)
    }
    fun saveAndExit(lang: AppLanguage) = t(lang, VietnameseTexts.EXIT_DIALOG_SAVE_BTN, "Save & Exit")
    fun discardAndExit(lang: AppLanguage) = t(lang, VietnameseTexts.EXIT_DIALOG_QUIT_BTN, "Exit Without Saving")

    // Win / Loss Modals
    fun winTitle(lang: AppLanguage) = t(lang, VietnameseTexts.VICTORY_TITLE, "🎉 LEVEL CLEARED!")
    fun winStats(lang: AppLanguage, moves: Int, timeSec: Int): String {
        val vi = "$moves lượt di chuyển · ${timeSec}s hoàn thành"
        val en = "$moves moves taken · ${timeSec}s completed"
        return t(lang, vi, en)
    }
    fun impossibleUnlocked(lang: AppLanguage) = t(lang, "👑 Chúc mừng! Đã mở khóa IMPOSSIBLE!", "👑 Congratulations! IMPOSSIBLE Mode Unlocked!")
    fun superCleared(lang: AppLanguage) = t(lang, "👑 Huyền thoại! Bạn đã chinh phục SIÊU CẤP 1000×1000!", "👑 Legendary! You conquered SUPER 1000×1000!")
    fun nextTierUnlocked(lang: AppLanguage) = t(lang, "🔥 Tốc độ siêu việt! Đã mở tầng tiếp theo!", "🔥 Incredible speed! Next tier unlocked!")
    fun replayRoute(lang: AppLanguage) = t(lang, VietnameseTexts.VICTORY_REPLAY_BTN, "Watch Replay")
    fun lossTitle(lang: AppLanguage) = t(lang, "💔 CHƯA HOÀN THÀNH", "💔 LEVEL FAILED")
    fun reviewPath(lang: AppLanguage) = t(lang, "Xem Lại Quá Trình Đi", "Review Path Traveled")

    // Daily Challenge Screen
    fun dailyTitle(lang: AppLanguage) = t(lang, "📅 Thử Thách Hàng Ngày", "📅 Daily Challenge")
    fun dailyDateSub(lang: AppLanguage, date: String): String {
        val vi = "Ngày: $date · Mê cung cố định toàn cầu"
        val en = "Date: $date · Fixed Global Maze"
        return t(lang, vi, en)
    }
    fun dailyHeroTitle(lang: AppLanguage) = t(lang, "MÊ CUNG CÔNG NGHỆ 14×14", "CYBER MAZE 14×14")
    fun dailyHeroSub(lang: AppLanguage) = t(lang, "Mục tiêu: đúng 95 bước · Tầm nhìn 10×10", "Target: exactly 95 steps · Vision 10×10")
    fun dailyRewardBadge(lang: AppLanguage) = t(lang, "+200 🪙 Thưởng", "+200 🪙 Reward")
    fun dailyStartBtn(lang: AppLanguage, hasRecord: Boolean): String {
        val vi = if (hasRecord) "Chơi Lại Thử Thách" else "Bắt Đầu Thi Đấu Hôm Nay"
        val en = if (hasRecord) "Play Challenge Again" else "Start Today's Run"
        return t(lang, vi, en)
    }
    fun dailyReplayBtn(lang: AppLanguage, moves: Int, timeSec: Int): String {
        val vi = "🎬 Xem Lại Lộ Trình Hôm Nay ($moves bước · ${timeSec}s)"
        val en = "🎬 Watch Today's Replay ($moves steps · ${timeSec}s)"
        return t(lang, vi, en)
    }
    fun dailyTopSpeed(lang: AppLanguage) = t(lang, "⚡ Top Tốc Độ Hôm Nay", "⚡ Today's Speed Leaders")
    fun noDailyRecords(lang: AppLanguage) = t(lang, "🏃 Chưa có thành tích hôm nay", "🏃 No records today yet")
    fun noDailyRecordsSub(lang: AppLanguage) = t(lang, "Hãy nhấn 'Bắt Đầu Thi Đấu' để ghi dấu thành tích kỷ lục của bạn!", "Tap 'Start Today\'s Run' to set your personal best!")

    // Leaderboard Screen
    fun leaderboardTitle(lang: AppLanguage) = t(lang, VietnameseTexts.LEADERBOARD_TITLE, "🏆 Leaderboards")
    fun tabByLevel(lang: AppLanguage) = t(lang, "Theo Màn Chơi", "By Level")
    fun tabDailyChallenge(lang: AppLanguage) = t(lang, "Thử Thách Ngày", "Daily Challenge")
    fun levelNum(lang: AppLanguage, lvl: Int): String {
        val vi = String.format(VietnameseTexts.HUD_CURRENT_LEVEL, lvl)
        val en = "Level $lvl"
        return t(lang, vi, en)
    }
    fun noLeaderboardData(lang: AppLanguage, isLevel: Boolean, lvl: Int): String {
        val vi = if (isLevel) "Chưa có thành tích cho Màn $lvl" else "Chưa có thành tích hôm nay"
        val en = if (isLevel) "No records for Level $lvl" else "No records today"
        return t(lang, vi, en)
    }
    fun noLeaderboardSub(lang: AppLanguage) = t(lang, "Hãy hoàn thành màn để ghi danh kỷ lục của bạn vào bảng xếp hạng!", "Complete levels to climb the leaderboards!")

    // Shop & VIP Screen
    fun shopTitle(lang: AppLanguage) = t(lang, VietnameseTexts.SHOP_TITLE, "🛒 Shop & VIP")
    fun tabSkins(lang: AppLanguage) = t(lang, VietnameseTexts.SHOP_TAB_SKINS, "Skins")
    fun tabThemes(lang: AppLanguage) = t(lang, VietnameseTexts.SHOP_TAB_THEMES, "Themes")
    fun tabVip(lang: AppLanguage) = t(lang, VietnameseTexts.SHOP_TAB_VIP, "VIP & Coins")
    fun buyItem(lang: AppLanguage, price: Int): String {
        val vi = String.format(VietnameseTexts.SHOP_BUY_BTN, price)
        val en = "Buy ($price Coins)"
        return t(lang, vi, en)
    }
    fun equipItem(lang: AppLanguage) = t(lang, VietnameseTexts.SHOP_EQUIP_BTN, "Equip")
    fun equippedBadge(lang: AppLanguage) = t(lang, VietnameseTexts.SHOP_EQUIPPED_BADGE, "EQUIPPED")
    fun ownedBadge(lang: AppLanguage) = t(lang, VietnameseTexts.SHOP_OWNED_BADGE, "OWNED")
    fun vipOnlyBadge(lang: AppLanguage) = t(lang, "VIP", "VIP ONLY")
    fun vipCardTitle(lang: AppLanguage) = t(lang, VietnameseTexts.VIP_TITLE, "👑 Premium VIP Pass")
    fun vipCardDesc(lang: AppLanguage) = t(lang, VietnameseTexts.VIP_DESC, "• Permanent Ad-Free Experience\n• Instantly unlock VIP Royal Crown Skin\n• +1,000 Bonus Coins")
    fun vipBuyBtn(lang: AppLanguage) = t(lang, VietnameseTexts.VIP_BTN, "Unlock VIP ($2.99)")
    fun vipActive(lang: AppLanguage) = t(lang, VietnameseTexts.VIP_ACTIVE_BADGE, "★ VIP ACTIVE ★")
    fun coinPacks(lang: AppLanguage) = t(lang, "Gói Nạp Xu Thưởng", "Coin Packs")
    fun watchAdCoinBtn(lang: AppLanguage, amount: Int): String {
        val vi = "📺 Xem Video Nhận +$amount Xu"
        val en = "📺 Watch Video for +$amount Coins"
        return t(lang, vi, en)
    }

    // Achievements Screen
    fun achievementsTitle(lang: AppLanguage) = t(lang, VietnameseTexts.ACHIEVEMENTS_TITLE, "🎖️ Badges & Achievements")
    fun achievementsProgress(lang: AppLanguage, current: Int, total: Int): String {
        val vi = String.format(VietnameseTexts.ACHIEVEMENTS_PROGRESS, current, total)
        val en = "Unlocked $current of $total Badges"
        return t(lang, vi, en)
    }

    // Replay Screen
    fun replayTitle(lang: AppLanguage) = t(lang, VietnameseTexts.REPLAY_TITLE, "🎬 Level Route Replay")
    fun replaySteps(lang: AppLanguage, current: Int, total: Int): String {
        val vi = String.format(VietnameseTexts.REPLAY_STEP_COUNTER, current, total)
        val en = "Step $current / $total"
        return t(lang, vi, en)
    }

    // Cloud Sync Dialog
    fun cloudSyncTitle(lang: AppLanguage) = t(lang, "☁️ Đồng Bộ Dữ Liệu Đám Mây", "☁️ Cloud Backup & Sync")
    fun backupCloud(lang: AppLanguage) = t(lang, "Sao Lưu Lên Đám Mây", "Backup to Cloud")
    fun restoreCloud(lang: AppLanguage) = t(lang, "Khôi Phục Từ Đám Mây", "Restore from Cloud")

    // One-Line Puzzle Screen
    fun oneLineTitle(lang: AppLanguage) = t(lang, VietnameseTexts.ONELINE_TITLE, "One-Line Puzzle")
    fun oneLineSubtitle(lang: AppLanguage) = t(lang, VietnameseTexts.ONELINE_SUBTITLE, "Draw entire line without lifting finger")
    fun tabSquareGrids(lang: AppLanguage) = t(lang, VietnameseTexts.ONELINE_TAB_SQUARE, "Square (3×3 → 15×15)")
    fun tabSpecialShapes(lang: AppLanguage) = t(lang, VietnameseTexts.ONELINE_TAB_SPECIAL, "Special Shapes")
    fun oneLineCellsCount(lang: AppLanguage, visited: Int, total: Int): String {
        val vi = String.format(VietnameseTexts.ONELINE_CELLS_COUNT, visited, total)
        val en = "Visited: $visited / $total cells"
        return t(lang, vi, en)
    }

    // Cloud Sync
    fun cloudSyncSub(lang: AppLanguage) = t(lang, "Đồng bộ tiến trình chơi và vật phẩm lên đám mây", "Sync game progress and items to cloud")
    fun lastSyncLabel(lang: AppLanguage, timeStr: String = ""): String {
        val vi = if (timeStr.isEmpty()) "Đồng bộ lần cuối" else "Đồng bộ lần cuối: $timeStr"
        val en = if (timeStr.isEmpty()) "Last synced" else "Last synced: $timeStr"
        return t(lang, vi, en)
    }
    fun neverSynced(lang: AppLanguage) = t(lang, "Chưa từng đồng bộ", "Never synced")
    fun syncSuccessText(lang: AppLanguage) = t(lang, "Đã đồng bộ thành công!", "Cloud sync successful!")
    fun syncingText(lang: AppLanguage) = t(lang, "Đang đồng bộ...", "Syncing...")
    fun syncNowBtn(lang: AppLanguage) = t(lang, "Đồng Bộ Ngay", "Sync Now")

    // Ads
    fun adTitle(lang: AppLanguage) = t(lang, "📺 Xem Quảng Cáo Thưởng", "📺 Reward Video")
    fun adSecondsLeft(lang: AppLanguage, sec: Int): String {
        val vi = "Còn lại: ${sec}s"
        val en = "${sec}s remaining"
        return t(lang, vi, en)
    }
    fun adRewardFor(lang: AppLanguage, rewardType: String): String {
        val vi = "Phần thưởng: $rewardType"
        val en = "Reward: $rewardType"
        return t(lang, vi, en)
    }
    fun adFinished(lang: AppLanguage) = t(lang, "Quảng cáo hoàn tất!", "Ad complete!")
    fun adSimDesc(lang: AppLanguage) = t(lang, "Mô phỏng xem video quảng cáo nhận thưởng", "Simulated video ad player to earn rewards")
    fun claimAdRewardBtn(lang: AppLanguage) = t(lang, "Nhận Phần Thưởng", "Claim Reward")

    // Achievements
    fun achievementsCompleted(lang: AppLanguage, current: Int, total: Int): String {
        val vi = "Đã mở khóa $current / $total danh hiệu"
        val en = "Unlocked $current of $total Badges"
        return t(lang, vi, en)
    }
    fun noAchievements(lang: AppLanguage) = t(lang, "Chưa có danh hiệu nào", "No Badges Yet")
    fun noAchievementsSub(lang: AppLanguage) = t(lang, "Hãy vượt qua các thử thách để nhận huy hiệu độc quyền!", "Complete in-game challenges to earn exclusive badges!")
    fun claimed(lang: AppLanguage) = t(lang, "Đã Nhận", "Claimed")

    // OneLine Puzzle
    fun categorySquare(lang: AppLanguage) = t(lang, "Khung Vuông", "Square Grids")
    fun categorySpecial(lang: AppLanguage) = t(lang, "Hình Đặc Biệt", "Special Shapes")
    fun completePrevLevel(lang: AppLanguage) = t(lang, "Hãy hoàn thành màn trước đó để mở khóa!", "Complete the previous level to unlock!")
    fun maxDiff(lang: AppLanguage) = t(lang, "Cực Khó", "Max Diff")
    fun squareRouteSub(lang: AppLanguage) = t(lang, "Mê cung đường nối ô vuông từ 3x3 đến 15x15", "Grid path from 3x3 to 15x15")
    fun specialShapeSub(lang: AppLanguage) = t(lang, "Trái tim, Ngôi sao, Kim tự tháp, Chữ thập", "Hearts, Stars, Pyramids, Crosses")
    fun unlockSpecialReq(lang: AppLanguage) = t(lang, "Cần hoàn thành ít nhất 10 màn Khung Vuông!", "Requires 10 Square levels completed!")
    fun completeLevelToUnlock(lang: AppLanguage, lvl: Int, total: Int = 0): String {
        val vi = "Cần vượt Màn $lvl để mở khóa màn này!"
        val en = "Complete Level $lvl to unlock!"
        return t(lang, vi, en)
    }
    fun hamiltonianDfs(lang: AppLanguage) = t(lang, "Thuật toán Hamilton DFS", "Hamiltonian DFS")
    fun completeCurrentLevelFirst(lang: AppLanguage) = t(lang, "Hãy hoàn thành màn hiện tại trước!", "Complete current level first!")
    fun onelineLevelComplete(lang: AppLanguage, lvl: Int = 0): String {
        val vi = if (lvl > 0) "🎉 HOÀN THÀNH MÀN VẼ 1 NÉT $lvl!" else "🎉 HOÀN THÀNH MÀN VẼ 1 NÉT!"
        val en = if (lvl > 0) "🎉 ONE-LINE LEVEL $lvl CLEARED!" else "🎉 ONE-LINE LEVEL CLEARED!"
        return t(lang, vi, en)
    }
    fun onelineWinMsg(lang: AppLanguage, label: String = ""): String {
        val vi = if (label.isNotEmpty()) "Tuyệt vời! Bạn đã hoàn thành Màn $label!" else "Tuyệt vời! Bạn đã nối toàn bộ các ô mà không nhấc tay!"
        val en = if (label.isNotEmpty()) "Awesome! You completed Level $label!" else "Awesome! You connected all cells in a single stroke!"
        return t(lang, vi, en)
    }
    fun levelReward(lang: AppLanguage, coins: Int = 30): String {
        val vi = "Thưởng: +$coins Xu"
        val en = "Reward: +$coins Coins"
        return t(lang, vi, en)
    }
    fun congratsAllCleared(lang: AppLanguage) = t(lang, "Chúc mừng! Bạn đã chinh phục toàn bộ các màn 1 Nét!", "Congrats! You cleared all One-Line levels!")

    // Replay
    fun noReplayData(lang: AppLanguage) = t(lang, "Không có dữ liệu xem lại", "No Replay Data")
    fun noReplayDataSub(lang: AppLanguage) = t(lang, "Chơi và hoàn thành một màn để lưu lộ trình xem lại!", "Complete a level to record your step-by-step route!")
    fun replayStep(lang: AppLanguage, current: Int, total: Int): String {
        val vi = "Bước $current / $total"
        val en = "Step $current of $total"
        return t(lang, vi, en)
    }
    fun replayFromStart(lang: AppLanguage) = t(lang, "Xem Lại Từ Đầu", "Replay From Start")
    fun stepBack(lang: AppLanguage) = t(lang, "Lùi 1 Bước", "Step Back")
    fun stepForward(lang: AppLanguage) = t(lang, "Tới 1 Bước", "Step Forward")
}
