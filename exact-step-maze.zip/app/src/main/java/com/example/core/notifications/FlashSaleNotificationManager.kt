package com.example.core.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.core.time.NetworkTimeManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Trình quản lý Thông Báo Flash Sale & Quà Tặng Miễn Phí
 * Kết hợp đồng hồ Internet và kết nối mạng để nhảy thông báo đúng giờ.
 */
object FlashSaleNotificationManager {

    private const val TAG = "FlashSaleNotification"
    const val CHANNEL_ID = "flash_sale_vip_channel"
    private const val PREFS_NAME = "vip_notification_prefs"
    private const val KEY_LAST_FLASH_NOTIF_DATE = "last_flash_notif_date"
    private const val KEY_LAST_FREE_VIP_NOTIF_TIME = "last_free_vip_notif_time"

    const val NOTIF_ID_FLASH_SALE = 1001
    const val NOTIF_ID_FREE_VIP = 1002
    const val NOTIF_ID_DAILY_REWARD = 1003

    fun initNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Khuyến Mãi VIP & Quà Tặng Miễn Phí"
            val descriptionText = "Thông báo giờ vàng giảm giá gói VIP và thông báo nhận gói VIP 1 miễn phí"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableLights(true)
                enableVibration(true)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.createNotificationChannel(channel)
        }
    }

    /**
     * Kiểm tra trạng thái mạng và đồng hồ Internet để bắn thông báo Giờ Vàng Flash Sale hoặc Gói Miễn Phí
     */
    fun checkAndNotifyIfOnline(
        context: Context,
        accumulatedAdViews: Int,
        vipTier: Int
    ) {
        val timeManager = NetworkTimeManager.getInstance(context)
        if (!timeManager.isNetworkAvailable()) {
            Log.d(TAG, "Thiết bị chưa có mạng, bỏ qua kiểm tra thông báo internet.")
            return
        }

        timeManager.syncWithInternetTime { success ->
            val calendar = timeManager.getInternetCalendar()
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

            // 1. Kiểm tra Giờ Vàng Flash Sale (9h - 12h các ngày Sun, Mon, Wed, Fri)
            if (timeManager.isFlashSaleActive()) {
                val dateFormat = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
                val todayStr = dateFormat.format(Date(calendar.timeInMillis))
                val lastNotifDate = prefs.getString(KEY_LAST_FLASH_NOTIF_DATE, "")

                if (lastNotifDate != todayStr) {
                    showFlashSaleNotification(context)
                    prefs.edit().putString(KEY_LAST_FLASH_NOTIF_DATE, todayStr).apply()
                }
            }

            // 2. Kiểm tra Gói VIP 1 Miễn Phí (Đủ 30 lượt xem quảng cáo thưởng)
            if (accumulatedAdViews >= 30 && vipTier == 0) {
                val lastFreeNotifTime = prefs.getLong(KEY_LAST_FREE_VIP_NOTIF_TIME, 0L)
                val now = System.currentTimeMillis()
                // Báo cách nhau tối thiểu 12 tiếng để không làm phiền
                if (now - lastFreeNotifTime > 12 * 3600 * 1000L) {
                    showFreeVipReadyNotification(context)
                    prefs.edit().putLong(KEY_LAST_FREE_VIP_NOTIF_TIME, now).apply()
                }
            }
        }
    }

    /**
     * Bắn thông báo Giờ Vàng Flash Sale
     */
    fun showFlashSaleNotification(context: Context) {
        try {
            initNotificationChannel(context)

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("NAVIGATE_TO", "shop")
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.star_on)
                .setContentTitle("⚡ GIỜ VÀNG FLASH SALE ĐÃ BẮT ĐẦU!")
                .setContentText("VIP 2 chỉ còn $0.699, VIP 3 chỉ còn $2.599! Giảm giá sốc trong 3 giờ hôm nay!")
                .setStyle(
                    NotificationCompat.BigTextStyle().bigText(
                        "⚡ GIỜ VÀNG FLASH SALE ĐÃ BẮT ĐẦU!\n" +
                                "Gói VIP 2 (15 ngày không quảng cáo) chỉ còn $0.699 (giá gốc $1.25).\n" +
                                "Gói VIP 3 (Trọn đời không quảng cáo) chỉ còn $2.599 (giá gốc $4.00)!\n" +
                                "Khung giờ vàng từ 9:00 - 12:00. Bấm để vào Cửa Hàng nhận ưu đãi ngay!"
                    )
                )
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)

            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(NOTIF_ID_FLASH_SALE, builder.build())
            Log.i(TAG, "Đã gửi thông báo Flash Sale thành công")
        } catch (e: SecurityException) {
            Log.w(TAG, "Chưa được cấp quyền POST_NOTIFICATIONS: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi gửi thông báo Flash Sale: ${e.message}")
        }
    }

    /**
     * Bắn thông báo Gói VIP 1 Miễn Phí đã sẵn sàng kích hoạt
     */
    fun showFreeVipReadyNotification(context: Context) {
        try {
            initNotificationChannel(context)

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("NAVIGATE_TO", "shop")
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                1,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.btn_star_big_on)
                .setContentTitle("🎁 BẠN CÓ GÓI VIP 1 MIỄN PHÍ!")
                .setContentText("Đã tích lũy đủ 30 lượt xem video! Vào nhận ngay 3 ngày VIP 1 không quảng cáo.")
                .setStyle(
                    NotificationCompat.BigTextStyle().bigText(
                        "🎉 Xin chúc mừng! Bạn đã tích lũy đủ 30/30 lượt xem quảng cáo thưởng.\n" +
                                "Gói quà VIP 1 miễn phí (3 ngày không có quảng cáo) đã sẵn sàng.\n" +
                                "Bấm để kích hoạt và tùy chọn tắt quảng cáo ngay!"
                    )
                )
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)

            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(NOTIF_ID_FREE_VIP, builder.build())
            Log.i(TAG, "Đã gửi thông báo Gói VIP 1 Miễn Phí thành công")
        } catch (e: SecurityException) {
            Log.w(TAG, "Chưa được cấp quyền POST_NOTIFICATIONS: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi gửi thông báo Free VIP: ${e.message}")
        }
    }
}
