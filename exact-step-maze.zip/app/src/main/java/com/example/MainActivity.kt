package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.Strings
import com.example.core.notifications.FlashSaleAlarmReceiver
import com.example.core.notifications.FlashSaleNotificationManager
import com.example.ui.components.AdBannerView
import com.example.ui.components.CloudSyncDialog
import com.example.ui.components.RewardAdDialog
import com.example.ui.screens.AchievementsScreen
import com.example.ui.screens.DailyChallengeScreen
import com.example.ui.screens.GameScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.OneLineScreen
import com.example.ui.screens.ReplayScreen
import com.example.ui.screens.ShopScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            FlashSaleAlarmReceiver.scheduleNextAlarm(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Khởi tạo thông báo và lịch báo thức Giờ Vàng
        FlashSaleNotificationManager.initNotificationChannel(this)
        FlashSaleAlarmReceiver.scheduleNextAlarm(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (intent?.getStringExtra("NAVIGATE_TO") == "shop") {
            viewModel.navigateTo(AppScreen.SHOP)
        }

        setContent {
            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val lang = uiState.language
                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(uiState.toastMessage) {
                    val msg = uiState.toastMessage
                    if (msg != null) {
                        snackbarHostState.showSnackbar(msg)
                        viewModel.clearToast()
                    }
                }

                // Gọi quảng cáo xen kẽ Interstitial mỗi khi thắng màn (nếu được phép)
                LaunchedEffect(uiState.pendingInterstitial) {
                    if (uiState.pendingInterstitial) {
                        viewModel.triggerInterstitial(this@MainActivity)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Quảng cáo banner trong game (Màn chơi mê cung, màn nối một nét, màn chính)
                        if (uiState.currentScreen == AppScreen.PLAYING ||
                            uiState.currentScreen == AppScreen.ONELINE_GAME ||
                            uiState.currentScreen == AppScreen.HOME
                        ) {
                            AdBannerView(
                                progress = uiState.progress,
                                onOpenVipShop = { viewModel.navigateTo(AppScreen.SHOP) }
                            )
                        }
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    // Smooth animated screen transitions
                    AnimatedContent(
                        targetState = uiState.currentScreen,
                        transitionSpec = {
                            if (targetState == AppScreen.PLAYING || targetState == AppScreen.REPLAY) {
                                (slideInHorizontally(animationSpec = tween(350)) { it } + fadeIn(tween(350)))
                                    .togetherWith(slideOutHorizontally(animationSpec = tween(300)) { -it / 3 } + fadeOut(tween(300)))
                            } else {
                                (fadeIn(animationSpec = tween(300)) + slideInHorizontally(tween(300)) { -it / 4 })
                                    .togetherWith(fadeOut(animationSpec = tween(250)))
                            }
                        },
                        label = "ScreenTransition",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) { targetScreen ->
                        when (targetScreen) {
                            AppScreen.HOME -> HomeScreen(viewModel = viewModel)
                            AppScreen.PLAYING -> GameScreen(viewModel = viewModel)
                            AppScreen.REPLAY -> ReplayScreen(viewModel = viewModel)
                            AppScreen.LEADERBOARD -> LeaderboardScreen(viewModel = viewModel)
                            AppScreen.ACHIEVEMENTS -> AchievementsScreen(viewModel = viewModel)
                            AppScreen.DAILY_CHALLENGE -> DailyChallengeScreen(viewModel = viewModel)
                            AppScreen.SHOP -> ShopScreen(viewModel = viewModel)
                            AppScreen.ONELINE_GAME -> OneLineScreen(viewModel = viewModel)
                        }
                    }

                    // Reward Ad Dialog
                    val rewardPrompt = uiState.rewardAdPrompt
                    if (rewardPrompt != null) {
                        val title = when (rewardPrompt) {
                            "HINT" -> if (lang == AppLanguage.VI) "Gợi ý đường đi chính xác" else "Accurate path hint"
                            "SKIP" -> if (lang == AppLanguage.VI) "Bỏ qua màn chơi này" else "Skip this level"
                            "TIME" -> if (lang == AppLanguage.VI) "+30 giây thời gian" else "+30s extra time"
                            "COINS" -> if (lang == AppLanguage.VI) "+50 Xu thưởng" else "+50 Bonus Coins"
                            else -> Strings.reward(lang)
                        }
                        RewardAdDialog(
                            rewardTitle = title,
                            language = lang,
                            accumulatedAdViews = uiState.progress.accumulatedRewardedAdViews,
                            onRewardEarned = { viewModel.onRewardEarned(rewardPrompt) },
                            onDismiss = { viewModel.dismissRewardedAd() }
                        )
                    }

                    // Cloud Sync Dialog
                    if (uiState.showCloudSyncDialog) {
                        CloudSyncDialog(
                            lastSyncTime = uiState.progress.lastCloudSyncTime,
                            totalStars = uiState.progress.totalStars,
                            highestCleared = uiState.progress.highestCleared,
                            language = lang,
                            onSyncConfirmed = { viewModel.confirmCloudSync() },
                            onDismiss = { viewModel.closeCloudSync() }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.soundManager.resumeBgm()
        val p = viewModel.uiState.value.progress
        FlashSaleNotificationManager.checkAndNotifyIfOnline(this, p.accumulatedRewardedAdViews, p.vipTier)
    }

    override fun onPause() {
        super.onPause()
        viewModel.soundManager.pauseBgm()
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.soundManager.release()
    }
}
