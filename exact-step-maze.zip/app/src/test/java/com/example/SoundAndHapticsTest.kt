package com.example

import com.example.core.engine.Point
import com.example.ui.components.GridControlMode
import com.example.ui.components.GridGestureInputHandler
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SoundAndHapticsTest {

    @Test
    fun testControlModeToggle() {
        val testScope = TestScope()
        var moved = false
        val handler = GridGestureInputHandler(
            coroutineScope = testScope,
            onValidateAndMove = { _, _ ->
                moved = true
                true
            },
            initialControlMode = GridControlMode.AUTO
        )

        assertEquals(GridControlMode.AUTO, handler.controlMode)
        val toggled = handler.toggleControlMode()
        assertEquals(GridControlMode.STEP_BY_STEP, toggled)
        assertEquals(GridControlMode.STEP_BY_STEP, handler.controlMode)

        val toggledBack = handler.toggleControlMode()
        assertEquals(GridControlMode.AUTO, toggledBack)
    }

    @Test
    fun testMoveToCellAndDirectFollow() = runTest {
        var stepCount = 0
        val recordedDirections = mutableListOf<Pair<Int, Int>>()

        val handler = GridGestureInputHandler(
            coroutineScope = this,
            onValidateAndMove = { dx, dy ->
                stepCount += 1
                recordedDirections.add(Pair(dx, dy))
                true
            },
            initialControlMode = GridControlMode.AUTO
        )

        val success = handler.moveToCell(
            targetX = 3,
            targetY = 2,
            currentX = 2,
            currentY = 2
        )

        assertTrue(success)
        assertEquals(1, stepCount)
        assertEquals(Pair(1, 0), recordedDirections.last())
    }

    @Test
    fun testTouchInteractions() = runTest {
        var stepCount = 0
        val handler = GridGestureInputHandler(
            coroutineScope = this,
            onValidateAndMove = { _, _ ->
                stepCount += 1
                true
            },
            initialControlMode = GridControlMode.AUTO
        )

        handler.handleTouchStart(Point(2, 3), Point(2, 2))
        assertEquals(1, stepCount)

        handler.handleTouchMove(Point(3, 3), Point(2, 3))
        assertEquals(2, stepCount)

        handler.handleTouchEnd()
    }
}
