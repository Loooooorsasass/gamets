package com.example

import com.example.core.engine.MazeBuilder
import com.example.core.engine.MazeConfig
import com.example.core.engine.MazeGenerator
import com.example.ui.components.MazeGameView
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class MazeGameTest {

    @Test
    fun testMazePointEquality() {
        val p1 = MazeGameView.MazePoint(3, 4)
        val p2 = MazeGameView.MazePoint(3, 4)
        val p3 = MazeGameView.MazePoint(4, 3)

        assertEquals(p1, p2)
        assertEquals(p1.hashCode(), p2.hashCode())
        assertFalse(p1 == p3)
    }

    @Test
    fun testMazeWallBitmasks() {
        assertEquals(1, MazeGameView.NORTH)
        assertEquals(2, MazeGameView.EAST)
        assertEquals(4, MazeGameView.SOUTH)
        assertEquals(8, MazeGameView.WEST)

        // All 4 open directions
        val allOpen = MazeGameView.NORTH or MazeGameView.EAST or MazeGameView.SOUTH or MazeGameView.WEST
        assertEquals(15, allOpen)

        // Test passage checking
        assertTrue((allOpen and MazeGameView.NORTH) != 0)
        assertTrue((allOpen and MazeGameView.EAST) != 0)
        assertTrue((allOpen and MazeGameView.SOUTH) != 0)
        assertTrue((allOpen and MazeGameView.WEST) != 0)

        // Blocked north & east
        val southWestOnly = MazeGameView.SOUTH or MazeGameView.WEST
        assertFalse((southWestOnly and MazeGameView.NORTH) != 0)
        assertFalse((southWestOnly and MazeGameView.EAST) != 0)
        assertTrue((southWestOnly and MazeGameView.SOUTH) != 0)
        assertTrue((southWestOnly and MazeGameView.WEST) != 0)
    }

    @Test
    fun testManhattanDistance() {
        val current = MazeGameView.MazePoint(2, 2)
        val nextStep = MazeGameView.MazePoint(2, 3)
        val diagonal = MazeGameView.MazePoint(3, 3)

        val dist1 = Math.abs(nextStep.x - current.x) + Math.abs(nextStep.y - current.y)
        val dist2 = Math.abs(diagonal.x - current.x) + Math.abs(diagonal.y - current.y)

        assertEquals(1, dist1)
        assertEquals(2, dist2)
    }

    @Test
    fun testSmallMazeBacktracking() {
        val maze = MazeBuilder.buildMaze(12, 12, 30, 987654321UL)
        assertEquals(12, maze.w)
        assertEquals(12, maze.h)
        assertTrue(maze.spine.isNotEmpty())
        assertEquals(maze.start, maze.spine.first())
        assertEquals(maze.goal, maze.spine.last())
        assertEquals(144, maze.masks.size)
    }

    @Test
    fun testMediumMazeKruskal() {
        val maze = MazeBuilder.buildMaze(30, 30, 60, 123456789UL)
        assertEquals(30, maze.w)
        assertEquals(30, maze.h)
        assertTrue(maze.spine.isNotEmpty())
        assertEquals(maze.start, maze.spine.first())
        assertEquals(maze.goal, maze.spine.last())
        assertEquals(900, maze.masks.size)
    }

    @Test
    fun testLargeMazeWilson() {
        val maze = MazeBuilder.buildMaze(60, 60, 100, 555555555UL)
        assertEquals(60, maze.w)
        assertEquals(60, maze.h)
        assertTrue(maze.spine.isNotEmpty())
        assertEquals(maze.start, maze.spine.first())
        assertEquals(maze.goal, maze.spine.last())
        assertEquals(3600, maze.masks.size)
    }

    @Test
    fun testJavaPureAlgorithms() {
        val grid1 = Array(10) { x -> Array(10) { y -> MazeGameView.Cell(x, y) } }
        MazeGameView.generateBacktracking(grid1, 10, 10, java.util.Random(123))
        assertTrue(grid1[0][0].visited)

        val grid2 = Array(25) { x -> Array(25) { y -> MazeGameView.Cell(x, y) } }
        MazeGameView.generateKruskal(grid2, 25, 25, java.util.Random(456))

        val grid3 = Array(55) { x -> Array(55) { y -> MazeGameView.Cell(x, y) } }
        MazeGameView.generateWilson(grid3, 55, 55, java.util.Random(789))
        assertTrue(grid3[0][0].visited)

        // Test Endpoint logic
        val endpoints1 = MazeGameView.determineEndpoints(grid1, 10, 10, java.util.Random(123))
        assertEquals(5, endpoints1[0].x)
        assertEquals(5, endpoints1[0].y)

        val endpoints2 = MazeGameView.determineEndpoints(grid2, 25, 25, java.util.Random(456))
        assertEquals(0, endpoints2[0].x)
        assertEquals(12, endpoints2[0].y)
    }

    @Test
    fun testOneLineLevels() {
        assertEquals(3, com.example.ui.screens.SQUARE_LEVELS.first().size)
        assertEquals(15, com.example.ui.screens.SQUARE_LEVELS.last().size)
        assertEquals(13, com.example.ui.screens.SQUARE_LEVELS.size)
        assertTrue(com.example.ui.screens.SPECIAL_SHAPE_LEVELS.isNotEmpty())

        val p1 = com.example.ui.components.OneLineGameView.Point(1, 2)
        val p2 = com.example.ui.components.OneLineGameView.Point(1, 2)
        val p3 = com.example.ui.components.OneLineGameView.Point(2, 1)
        assertEquals(p1, p2)
        assertFalse(p1 == p3)
    }
}
