package com.example

import com.example.ui.components.OneLineGameView
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OneLineGameTest {

    @Test
    fun testPointEquality() {
        val p1 = OneLineGameView.Point(2, 3)
        val p2 = OneLineGameView.Point(2, 3)
        val p3 = OneLineGameView.Point(3, 2)

        assertEquals(p1, p2)
        assertEquals(p1.hashCode(), p2.hashCode())
        assertFalse(p1 == p3)
    }

    @Test
    fun testManhattanDistanceValidation() {
        val current = OneLineGameView.Point(1, 1)

        // 4 adjacent neighbors (Manhattan distance = 1)
        val right = OneLineGameView.Point(2, 1)
        val left = OneLineGameView.Point(0, 1)
        val down = OneLineGameView.Point(1, 2)
        val up = OneLineGameView.Point(1, 0)

        assertTrue(Math.abs(right.col - current.col) + Math.abs(right.row - current.row) == 1)
        assertTrue(Math.abs(left.col - current.col) + Math.abs(left.row - current.row) == 1)
        assertTrue(Math.abs(down.col - current.col) + Math.abs(down.row - current.row) == 1)
        assertTrue(Math.abs(up.col - current.col) + Math.abs(up.row - current.row) == 1)

        // Diagonal (Manhattan distance = 2 -> Invalid)
        val diagonal = OneLineGameView.Point(2, 2)
        assertFalse(Math.abs(diagonal.col - current.col) + Math.abs(diagonal.row - current.row) == 1)
    }
}
